"""Exact proposed recovery. Inspect is read-only except its new receipt; execute requires owner approval."""
import argparse
import importlib.util
import json
from pathlib import Path
import zipfile

PREP = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('h2a_campaign', PREP / 'campaign.py')
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)
q, supervisor, ROOT = campaign.q, campaign.supervisor, campaign.ROOT
RUN = ROOT / 'TestResults/qualification-supervisor/ff0c1234cd734ea39b501f7c7332bee7'
SOURCE = '67f1d5b0df4e3d5cea1fcd56c3d9f60129bb31c3'
BASELINE = PREP / 'recovery-inspection.json'
ORIGINALS = ('campaign.py', 'inventory.json', 'original-inputs.json', 'original-inputs.zip', 'qualified-inputs.json', 'protected.json', 'plan.json')
PROCESS_IDS = (52820, 22916, 55248, 40828)
ADB = {'pid': 40928, 'created': 134385682998835767,
       'executable': r'c:\program files\unity\hub\editor\6000.3.2f1\editor\data\playbackengines\androidplayer\sdk\platform-tools\adb.exe'}

def guards(restored=False):
    q.win.assert_no_unity()
    if supervisor.git(ROOT, 'rev-parse', 'HEAD') != SOURCE: raise ValueError('Source changed')
    for pid in PROCESS_IDS:
        if q.win.identity(pid) is not None: raise ValueError('Recorded process ID is live or reused: ' + str(pid))
    q.check_protected(PREP, campaign.SAVE)
    expected = json.loads((PREP / ('original-inputs.json' if restored else 'qualified-inputs.json')).read_text())
    if q.inventory(ROOT) != expected: raise ValueError('Input mismatch')
    result = json.loads((RUN / 'focused/result.json').read_text())
    if result['status'] != 'INCOMPLETE' or result['failure'] != 'UNCERTAIN': raise ValueError('Original verdict changed')
    current_adb = q.win.identity(ADB['pid'])
    if current_adb is not None and current_adb != ADB: raise ValueError('ADB PID reused; stop without termination')
    return {'original_campaign': q.tree(RUN), 'preparation': {name: q.sha(PREP / name) for name in ORIGINALS},
            'protected_unchanged': True, 'exact_input_count': len(expected), 'source': SOURCE,
            'recorded_processes_absent': list(PROCESS_IDS), 'adb_preserved': current_adb,
            'adb_ownership': 'Unproven: exact named Job Object no longer opens; no termination authorized or performed'}

def inspect():
    data = guards()
    active = json.loads((ROOT / 'TestResults/qualification-supervisor-reservation/active.json').read_text())
    if active.get('campaign') != str(RUN): raise ValueError('Reservation mismatch')
    data['proposed_changes'] = [str(ROOT / name) for name in q.SETTINGS] + [str(ROOT / 'TestResults/qualification-supervisor-reservation/active.json')]
    data['retention'] = 'Preserve original campaign, preparation, isolated product/save and adb process; no deletion or termination'
    data['exception'] = 'Owner approval required to restore exact archived settings and release this uncertain reservation while preserving the unproven adb survivor. Original verdict remains INCOMPLETE / UNCERTAIN.'
    q.write(BASELINE, data)
    print(json.dumps({'inspection': str(BASELINE), 'input_files': data['exact_input_count'], 'campaign_files': len(data['original_campaign'])}))

def verify_evidence(data, baseline):
    for name in ('original_campaign', 'preparation'):
        if data[name] != baseline[name]: raise ValueError('Evidence mismatch: ' + name)

def execute(approval):
    if not approval: raise ValueError('Explicit owner approval text required')
    baseline = json.loads(BASELINE.read_text())
    with supervisor.Lease(ROOT) as lease:
        data = guards(); verify_evidence(data, baseline)
        active = json.loads((ROOT / 'TestResults/qualification-supervisor-reservation/active.json').read_text())
        if active.get('campaign') != str(RUN): raise ValueError('Reservation mismatch')
        with zipfile.ZipFile(PREP / 'original-inputs.zip') as archive:
            originals = {name: archive.read(name) for name in q.SETTINGS}
        original_map = json.loads((PREP / 'original-inputs.json').read_text())
        import hashlib
        if any(hashlib.sha256(data).hexdigest() != original_map[name] for name, data in originals.items()):
            raise ValueError('Archived original mismatch')
        for name, data in originals.items(): (ROOT / name).write_bytes(data)
        data = guards(restored=True); verify_evidence(data, baseline)
        lease.release(RUN)
        q.write(PREP / 'recovery-execution.json', {'owner_approval': approval, 'passed': True, 'restored': q.SETTINGS,
            'reservation_released': str(RUN), 'evidence_preserved': True, 'adb_terminated': False})

def postflight():
    data = guards(restored=True)
    verify_evidence(data, json.loads(BASELINE.read_text()))
    active = json.loads((ROOT / 'TestResults/qualification-supervisor-reservation/active.json').read_text())
    if active.get('campaign') is not None or active.get('previous') != str(RUN): raise ValueError('Release mismatch')
    q.write(PREP / 'recovery-postflight.json', {'passed': True, **data})

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['inspect', 'execute', 'postflight'])
    p.add_argument('--owner-approval')
    args = p.parse_args()
    if args.mode == 'inspect': inspect()
    elif args.mode == 'execute': execute(args.owner_approval)
    else: postflight()

"""H2-A adapter using unchanged supervisor and H1-F4 preservation authorities."""
import argparse
import json
import re
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'Tools/Presentation'))
import qualify_h1_f4 as q
import qualification_supervisor as supervisor

PREP = Path(__file__).resolve().parent
PRODUCT = 'Dungeon Lord H2A Checkpoint1 R2 20261107'
SAVE = Path.home() / 'AppData/LocalLow/gdg3417' / PRODUCT
q.identities = lambda attempt: (PREP, PRODUCT, SAVE)
ATTEMPT = 'h2a-checkpoint1-r2'

def prepare():
    q.win.assert_no_unity()
    for path in (ROOT / 'Assets').rglob('*.meta'):
        if re.search(r'^guid: [0-9a-f]{32}\s*$', path.read_text(encoding='utf-8-sig'), re.MULTILINE) is None:
            raise ValueError('Malformed GUID before import: ' + str(path))
    if (PREP / 'inventory.json').exists() or SAVE.exists():
        raise ValueError('Require unused preparation/product/save identities')
    q.write(PREP / 'protected.json', q.protected(SAVE))
    original = q.inventory(ROOT)
    q.write(PREP / 'original-inputs.json', original)
    with zipfile.ZipFile(PREP / 'original-inputs.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name in original: archive.write(ROOT / name, name)
    path = ROOT / q.SETTINGS[0]
    measured_product = 'Dungeon Lord B3B2 Smoke H1F4 20261027 h2a-checkpoint1'
    prepared = q.qualification_player_settings(path.read_bytes(), measured_product)
    old = ('  productName: ' + measured_product + '\n').encode()
    new = ('  productName: ' + PRODUCT + '\n').encode()
    if prepared.count(old) != 1: raise ValueError('Exact product substitution required')
    isolated = prepared.replace(old, new)
    if isolated.replace(new, old) != prepared: raise ValueError('Irreversible product substitution')
    path.write_bytes(isolated)
    for name in q.SETTINGS[1:]:
        path = ROOT / name
        path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n'))
    q.write(PREP / 'qualified-inputs.json', q.inventory(ROOT))
    q.write(PREP / 'inventory.json', {'owner': 'H2-A checkpoint 1 R2', 'purpose': 'eight focused retained-execution cases',
        'retention': 'preserve', 'project': str(ROOT), 'preparation': str(PREP), 'product': PRODUCT, 'save': str(SAVE),
        'generated_project_paths': [str(ROOT / name) for name in ('Library', 'Temp', 'Logs')],
        'source_sha': supervisor.git(ROOT, 'rev-parse', 'HEAD')})

def plan():
    q.plan(ATTEMPT)
    path = PREP / 'plan.json'
    data = json.loads(path.read_text())
    data['tools'][str(Path(__file__).resolve())] = {'sha256': q.sha(__file__), 'version': 'H2-A checkpoint1 R2 explicit adapter'}
    data['tools'][str(q.CLI)]['version'] = 'Unity CLI 1.0.0-beta.17'
    for stage in data['stages']:
        stage['command'][2] = str(Path(__file__).resolve())
        if stage['role'] == 'test': stage['expected_tests'] = 8
    data['approved_substitutions'].append('Measured H1-F4 PlayerSettings preparation with exact reversible productName substitution to ' + PRODUCT + '; eight H2-A tests only. No frozen helper is modified. Prior uncertain campaign preserved; exact reservation recovery and continuation approved by owner. Existing adb is preserved without termination or ownership exemption.')
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'sealed_plan': str(path), 'expected_tests': 8}))

def run(stage):
    stage = Path(stage).resolve()
    command = [str(q.CLI), 'test', str(ROOT), '--mode', 'EditMode', '--filter',
        'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.H2ARetainedForeground',
        '--output', str(stage / 'results.xml'), '--timeout', '900', '--no-color', '--', '-logFile', str(stage / 'unity.log')]
    return q.run_child(ATTEMPT, stage, command, 'focused', 'cli-exit.json')

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['prepare', 'plan', 'preflight', 'run-test', 'restore', 'finish'])
    p.add_argument('--attempt', default=ATTEMPT)
    p.add_argument('--stage')
    args = p.parse_args()
    if args.mode == 'prepare': prepare()
    elif args.mode == 'plan': plan()
    elif args.mode == 'preflight': q.preflight(ATTEMPT, args.stage)
    elif args.mode == 'run-test': sys.exit(run(args.stage))
    elif args.mode == 'restore': q.restore(ATTEMPT, args.stage)
    elif args.mode == 'finish': q.finish(ATTEMPT, args.stage)

"""Bounded B attribution plan adapter. Reuses the existing H1-F4 input/process authorities."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'Tools/Presentation'))
import qualify_h1_f4 as q
import qualification_supervisor as supervisor

HERE = Path(__file__).resolve().parent
PREP = HERE / 'preparation'
SOURCE = '4f47c07d596765d6b7e58f50f6f6a5fcf9735f0e'
MAIN = '1a477ed94b44a3227e00af9c8c16c8600c916400'
ATTEMPT = 'option-b-admission-01'
PRODUCT = 'Dungeon Lord B Admission 20261110 01'
SAVE = Path.home() / 'AppData/LocalLow/gdg3417' / PRODUCT
FILTER = ';'.join((
    'DungeonBuilder.M0.Editor.Tests.AdmissionStartBenchmark.OneProductionAdmissionRepeatedSamples',
    'DungeonBuilder.M0.Editor.Tests.AdmissionStartReconstruction',
    'DungeonBuilder.M0.Editor.Tests.ForegroundPerformanceDiagnostics.DisabledResetBoundsAndExceptionNesting'))

q.ROOT = ROOT
q.identities = lambda attempt: (PREP, PRODUCT, SAVE)
# Same SHA-256 authority already used by the supervisor; stream large retained
# artifacts rather than materializing complete archives in Python memory.
q.sha = supervisor.digest
original_protected = q.protected

def protected(save):
    value = original_protected(save)
    owner = Path('C:/Dev/Dungeon-Lord')
    value['owner_inputs'] = q.inventory(owner)
    value['owner_testresults'] = q.tree(owner / 'TestResults')
    value['owner_builds'] = q.tree(owner / 'Builds')
    prior = Path('C:/Users/gdg34/.codex/worktrees/fgpv-main/Dungeon-Lord')
    value['fgpv_history'] = q.tree(prior / 'TestResults')
    value['fgpv_builds'] = q.tree(prior / 'Builds')
    f2 = Path('C:/Users/gdg34/.codex/worktrees/h1-f2-time-provenance/Dungeon-Lord/Builds/Development/Windows-h1-f2-headroom')
    value['qualified_f2_build'] = q.tree(f2)
    return value

q.protected = protected

def prepare():
    assert supervisor.git(ROOT, 'rev-parse', 'HEAD') == SOURCE
    assert supervisor.git(ROOT, 'rev-parse', 'origin/main') == MAIN
    assert not supervisor.git(ROOT, 'status', '--porcelain')
    q.win.assert_no_unity()
    assert not PREP.exists() and not SAVE.exists()
    owner_reservation = Path('C:/Dev/Dungeon-Lord/TestResults/qualification-supervisor-reservation/active.json')
    assert json.loads(owner_reservation.read_text())['campaign'] is None
    assert not (ROOT / 'TestResults/qualification-supervisor-reservation/active.json').exists()
    assert not (ROOT / 'Temp/qualification-supervisor/active.json').exists()
    PREP.mkdir()
    q.write(PREP / 'protected.json', protected(SAVE))
    original = q.inventory(ROOT)
    q.write(PREP / 'original-inputs.json', original)
    with zipfile.ZipFile(PREP / 'original-inputs.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name in original: archive.write(ROOT / name, name)
    path = ROOT / q.SETTINGS[0]
    measured = 'Dungeon Lord B3B2 Smoke H1F4 20261027 ' + ATTEMPT
    data = q.qualification_player_settings(path.read_bytes(), measured)
    before, after = ('  productName: '+measured+'\n').encode(), ('  productName: '+PRODUCT+'\n').encode()
    assert data.count(before) == 1
    path.write_bytes(data.replace(before, after))
    for name in q.SETTINGS[1:]:
        path = ROOT / name
        path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n'))
    q.write(PREP / 'qualified-inputs.json', q.inventory(ROOT))
    q.write(PREP / 'inventory.json', dict(source_sha=SOURCE, main_sha=MAIN, owner='Codex B diagnostic',
        purpose='One bounded admission attribution plus 19 directly applicable existing Unit/SIT cases',
        retention='Preserve all inputs, raw evidence and generated artifacts for independent review; no cleanup',
        project=str(ROOT), preparation=str(PREP), product=PRODUCT, save=str(SAVE), build=None,
        generated_project_paths=[str(ROOT/n) for n in ('Library','Temp','Logs','UserSettings')],
        generated_project_retention='Preserve for review', owner_reservation=str(owner_reservation)))
    print(json.dumps(dict(prepared=str(PREP), inputs=len(original), source=SOURCE)))

def plan():
    q.plan(ATTEMPT)
    path = PREP / 'plan.json'
    data = json.loads(path.read_text())
    for stage in data['stages']:
        stage['command'][2] = str(Path(__file__).resolve())
        if stage['role'] != 'test':
            stage['timeout_seconds'] = 1200 # complete protected history scan measured during preparation
        if stage['role'] == 'test':
            stage['expected_tests'] = 20
            stage['artifacts'].append('benchmark')
    data['tools'][str(Path(__file__).resolve())] = dict(sha256=q.sha(__file__), version='Bounded B attribution adapter 1')
    data['tools'][str(HERE/'preparation-adapter.py')] = dict(sha256=q.sha(HERE/'preparation-adapter.py'), version='Exact initial preservation preparation adapter')
    data['tools'][str(q.CLI)]['version'] = 'Unity CLI 1.0.0-beta.17; current verified 2026-11-10'
    data['approved_substitutions'].append('Diagnostic only: same production fixture, exact 137/137/10 oracle; 18 unchanged reconstruction cases and one unchanged metrics integrity case. No sustained profile, full suite, build or optimization. Short unique product identity replaces only the prepared productName.')
    # q.write deliberately refuses overwrite. q.plan just authored this owned plan;
    # retain its unmodified bytes before explicitly finalizing the adapter selection.
    (PREP/'inherited-plan.json').write_bytes(path.read_bytes())
    path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    q.write(PREP/'selection.json', dict(filter=FILTER, expected_tests=20, allowed_skips=[], source=SOURCE))
    print(json.dumps(dict(plan=str(path),filter=FILTER,expected_tests=20)))

def run(stage):
    stage = Path(stage).resolve()
    keys = ('DUNGEON_ADMISSION_BENCHMARK_ROOT','DUNGEON_ADMISSION_BENCHMARK_SOURCE','DUNGEON_FOREGROUND_DIAGNOSTIC_OUTPUT_ROOT','DUNGEON_FOREGROUND_DIAGNOSTIC_SOURCE')
    assert not any(os.environ.get(k) for k in keys)
    export = stage / 'benchmark'
    export.mkdir()
    os.environ[keys[0]] = str(export)
    os.environ[keys[1]] = SOURCE
    q.write(export/'ownership.json', dict(owner='Codex B diagnostic',retention='Preserve',source=SOURCE,
        product=PRODUCT, export_environment={k:os.environ[k] for k in keys[:2]}))
    command = [str(q.CLI),'test',str(ROOT),'--mode','EditMode','--filter',FILTER,'--output',str(stage/'results.xml'),
        '--timeout','900','--no-color','--','-logFile',str(stage/'unity.log')]
    try: return q.run_child(ATTEMPT,stage,command,'focused','cli-exit.json')
    finally:
        for k in keys[:2]: del os.environ[k]

def rebind_source():
    # No campaign has been created or launched. Preserve the first preparation
    # and plan verbatim; the normal direct workload preflight checks this exact
    # amended input map again, including all protected artifacts.
    assert not (ROOT/'TestResults/qualification-supervisor').exists()
    assert supervisor.git(ROOT,'rev-parse','HEAD') == SOURCE
    old = json.loads((PREP/'original-inputs.json').read_text())
    qualified = json.loads((PREP/'qualified-inputs.json').read_text())
    current = q.inventory(ROOT)
    changed = {n for n in current if current[n] != qualified[n]}
    expected = {'Assets/_Project/Scripts/Core/ForegroundQualificationMetrics.cs',
        'Assets/_Project/Scripts/Gameplay/RunSimulation/ActiveFloorRunSnapshot.cs',
        'Assets/_Project/Scripts/Gameplay/RunSimulation/CombatC0Geometry.cs'}
    assert set(current)==set(qualified)==set(old) and changed==expected
    for name in ('original-inputs.json','qualified-inputs.json','original-inputs.zip','inventory.json','plan.json','selection.json'):
        with (PREP/('initial-'+name)).open('xb') as stream: stream.write((PREP/name).read_bytes())
    revised = dict(old)
    for n in changed: revised[n]=current[n]
    data = {n:(ROOT/n).read_bytes() for n in current}
    with zipfile.ZipFile(PREP/'initial-original-inputs.zip') as z:
        for n in q.SETTINGS: data[n]=z.read(n)
    assert {n:hashlib.sha256(b).hexdigest() for n,b in data.items()}==revised
    with zipfile.ZipFile(PREP/'original-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
        for n,b in data.items():z.writestr(n,b)
    for name,value in (('original-inputs.json',revised),('qualified-inputs.json',current)):
        (PREP/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
    inventory=json.loads((PREP/'inventory.json').read_text())
    inventory.update(source_sha=SOURCE,initial_preparation_source='fd5b9f83d538dff48a3fc429f3d2d42ddf577d81')
    (PREP/'inventory.json').write_text(json.dumps(inventory,indent=2,sort_keys=True)+'\n')
    q.write(PREP/'source-transition.json',dict(before_source=inventory['initial_preparation_source'],after_source=SOURCE,
        before_inputs_sha256=q.sha(PREP/'initial-original-inputs.json'),after_inputs_sha256=q.sha(PREP/'original-inputs.json'),
        changed=sorted(changed),reason='Pre-execution static record-budget review: reduce seven markers to five; keep 4096 record limit unchanged',
        no_unity_or_campaign_executed=True,protected_inventory=q.sha(PREP/'protected.json')))
    plan=json.loads((PREP/'plan.json').read_text());plan['source_sha']=SOURCE
    restored_id=supervisor.signature(revised)
    for stage in plan['stages']:
        if 'after_input_identity' in stage: stage['after_input_identity']=restored_id
        if 'input_identity' in stage: stage['input_identity']=restored_id
    for p in (Path(__file__).resolve(),HERE/'plan-adapter-v1.py',PREP/'source-transition.json'):
        plan['tools'][str(p)]={'sha256':q.sha(p),'version':'Bounded B pre-execution source transition'}
    plan['approved_substitutions'].append('Five appended diagnostic boundaries at exact revised committed source; old unused plan and all initial input/archive versions retained. No fixture or oracle change; no test retry.')
    (PREP/'plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
    (PREP/'selection.json').write_text(json.dumps(dict(filter=FILTER,expected_tests=20,allowed_skips=[],source=SOURCE),indent=2)+'\n')
    print(json.dumps(dict(source=SOURCE,plan=str(PREP/'plan.json'),restored_input_identity=restored_id)))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode',choices=('prepare','plan','rebind-source','run-test','preflight','restore','finish'))
    parser.add_argument('--attempt')
    parser.add_argument('--stage')
    args = parser.parse_args()
    if args.mode == 'prepare': prepare()
    elif args.mode == 'plan': plan()
    elif args.mode == 'rebind-source': rebind_source()
    elif args.mode == 'run-test': sys.exit(run(args.stage))
    elif args.mode == 'preflight': q.preflight(ATTEMPT,args.stage)
    elif args.mode == 'restore': q.restore(ATTEMPT,args.stage)
    elif args.mode == 'finish': q.preflight(ATTEMPT,args.stage,restored=True)

"""Read the retained synthetic fixture's captured input shape outside measurement."""
import base64, hashlib, io, json, struct
from pathlib import Path

root=Path(__file__).resolve().parent
party=json.loads((root/'output.json').read_bytes())['primary']['livingDungeon']['Parties'][0]
checkpoint=base64.b64decode(''.join(party['CheckpointChunks']))
r=io.BytesIO(checkpoint)
def integer():return struct.unpack('<i',r.read(4))[0]
def long():return struct.unpack('<q',r.read(8))[0]
def blob():
    n=integer()
    return None if n==-1 else r.read(n)
def text():
    b=blob()
    return None if b is None else b.decode('utf-8')
fmt=integer();contract=text();evidence=text();wrapped=blob()
r=io.BytesIO(wrapped)
wrapped_contract=text();wrapped_format=integer();maximum=long();inner=blob()
r=io.BytesIO(inner)
version=integer();executable=text();sequence=integer();has_limit=r.read(1)==b'\1'
limit=long() if has_limit else None
timing=[long() for _ in range(5)]
snapshot_strings=[text() for _ in range(7)];tick=long();count=integer()
floors=[]
for _ in range(count):
    floor_id=text();index=integer();fingerprint=text();plan=text();spatial=text();connections=text();bound=long()
    graph=json.loads(plan);rooms=[x['Room'] for x in graph['RequiredRooms']]
    floors.append(dict(id=floor_id,index=index,plan_json_bytes=len(plan.encode()),spatial_json_bytes=len(spatial.encode()),
        connection_json_bytes=len(connections.encode()),connection_work_bound=bound,rooms=len(rooms),forks=len(graph['Forks']),
        tiles=sum(len(x['Spatial']['TraversableTiles']) for x in rooms),assignments=sum(len(x['Assignments']) for x in rooms)))
identity=lambda b:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
result=dict(checkpoint=identity(checkpoint),wrapped_start=identity(wrapped),inner_start=identity(inner),
    format=fmt,contract=contract,evidence=evidence,executable=executable,sequence=sequence,maximum_events=maximum,
    captured_limit=limit,timing=timing,tick=tick,floors=floors)
(root/'fixture-shape.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

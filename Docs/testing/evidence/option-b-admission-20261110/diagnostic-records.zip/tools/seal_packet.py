"""Collect the already-qualified bounded diagnostic into a sanitized review packet."""
import json, sys, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Tools/Presentation'))
import qualification_supervisor as supervisor
HERE=Path(__file__).resolve().parent
CAMP=ROOT/'TestResults/qualification-supervisor/90dd31ce31424724bad1eb5949120182'
SOURCE='4f47c07d596765d6b7e58f50f6f6a5fcf9735f0e'
OUT=ROOT/'Docs/testing/evidence/option-b-admission-20261110'
status=supervisor.status(CAMP)
assert status['status']=='PASSED', status
assert supervisor.git(ROOT,'rev-parse','HEAD')==SOURCE
state=supervisor.read(CAMP/'campaign.json')
assert state['source_sha']==SOURCE
assert not OUT.exists()
OUT.mkdir()
write=lambda p,v: p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n',encoding='utf-8')
write(HERE/'final-status.json',status)
processes={'supervisor':state.get('supervisor_process')}
for name,stage in state['stages'].items():
    for field in ('process','child_process'):
        if stage.get(field):processes[name+'/'+field]=stage[field]
disposition={name:dict(identity=identity,still_matches=supervisor.win.matches(identity)) for name,identity in processes.items() if identity}
write(HERE/'process-disposition.json',disposition)
ledger=[dict(path=str(path),owner=owner,purpose=purpose,retention='Preserve for independent review; no cleanup')
    for path,owner,purpose in (
        (ROOT,'Codex B diagnostic','Isolated Git worktree'),
        (HERE,'Codex B diagnostic','Preparation, exact archives, offline analysis and local evidence'),
        (CAMP,'Qualification supervisor','Sealed raw test, benchmark, command, process/Job and preservation evidence'),
        (ROOT/'TestResults/qualification-supervisor-reservation','Qualification supervisor','Persistent ownership and normal release receipts'),
        (Path.home()/'AppData/LocalLow/gdg3417/Dungeon Lord B Admission 20261110 01','Codex B diagnostic','Unused-before-launch isolated product/test output namespace'),
        (OUT,'Codex B diagnostic','Sanitized public review packet'),
        *[(ROOT/n,'Codex B diagnostic','Generated isolated Unity project artifacts') for n in ('Library','Temp','Logs','UserSettings')])]
write(HERE/'artifact-inventory.json',ledger)
original=supervisor.read(HERE/'preparation/original-inputs.json')
protected=supervisor.read(HERE/'preparation/protected.json')
xml=ET.parse(CAMP/'focused/results.xml').getroot()
files={
    'benchmark/admission.json': CAMP/'focused/benchmark/admission.json',
    'benchmark/ownership.json': CAMP/'focused/benchmark/ownership.json',
    'qualification/results.xml': CAMP/'focused/results.xml',
    'qualification/invocation.json': CAMP/'focused/invocation.json',
    'qualification/plan.json': HERE/'preparation/plan.json',
    'qualification/original-inputs.json': HERE/'preparation/original-inputs.json',
    'qualification/qualified-inputs.json': HERE/'preparation/qualified-inputs.json',
    'qualification/source-transition.json': HERE/'preparation/source-transition.json',
    'qualification/status.json': HERE/'final-status.json',
    'analysis/attribution.json': HERE/'attribution.json',
    'analysis/eligible-costs.json': HERE/'eligible-costs.json',
    'analysis/fixture-shape.json': HERE/'fixture-shape.json',
    'analysis/static-attribution.md': HERE/'static-attribution.md',
    'analysis/environment.json': HERE/'environment.json',
    'analysis/repository-preflight.json': HERE/'repository-preflight.json',
    'analysis/warning-review.json': HERE/'warning-review.json',
    'qualification/process-disposition.json': HERE/'process-disposition.json',
    'qualification/artifact-inventory.json': HERE/'artifact-inventory.json',
    'fixture/input.json': HERE/'input.json',
    'fixture/output.json': HERE/'output.json',
}
for script in ('campaign.py','preparation-adapter.py','plan-adapter-v1.py','analyze.py','eligible_costs.py','fixture_shape.py','seal_packet.py'):
    files['tools/'+script]=HERE/script
for stage in state['selected']:
    for name in ('result.json','started.json','child.json','exit.json','preservation.json','restoration.json','cli-exit.json'):
        p=CAMP/stage/name
        if p.exists(): files['qualification/'+stage+'/'+name]=p
for p in (CAMP/'focused/generated-inputs').rglob('*'):
    if p.is_file(): files['qualification/generated-inputs/'+p.name]=p
archive=OUT/'diagnostic-records.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name,path in sorted(files.items()): z.write(path,name)
write(OUT/'attribution.json',supervisor.read(HERE/'attribution.json'))
write(OUT/'eligible-costs.json',supervisor.read(HERE/'eligible-costs.json'))
governance=['AGENTS.md','docs/development/codex-development-rules.md','Docs/Cross_Spec_Glossary_of_Invariants_UPDATED.md',
    'Docs/planning/h2-checkpoint-policy-decision-gate.md','Docs/planning/living-dungeon-hybrid-persistence-proposal.md',
    'Docs/planning/h1-f4-recovery-design-gate.md','Docs/planning/living-dungeon-two-floor-foreground-contract.md',
    'Docs/testing/qualification-supervisor.md','Docs/testing/admission-start-reconstruction.md',
    'Docs/testing/foreground-performance-diagnostic-measurement.md','Docs/testing/foreground-predecessor-validation.md',
    'docs/planning/test-stage-matrix.md','docs/planning/build-promotion-policy.md','Docs/process/AI_Model_Selection_Policy.md',
    'Docs/testing/owner-uat-preparation-and-artifact-lifecycle.md']
report=dict(main_sha='1a477ed94b44a3227e00af9c8c16c8600c916400',tested_source_sha=SOURCE,
    branch='codex/option-b-admission-attribution',recommendation='STOP',optimization_implemented=False,
    model='GPT-6-based Codex; precise variant/reasoning unobservable',campaign=status,nunit=xml.attrib,
    artifact_root=str(HERE),campaign_root=str(CAMP),product='Dungeon Lord B Admission 20261110 01',
    protected_inventory_sha256=supervisor.digest(HERE/'preparation/protected.json'),
    archived_originals_sha256=supervisor.digest(HERE/'preparation/original-inputs.zip'),
    original_input_map_sha256=supervisor.digest(HERE/'preparation/original-inputs.json'),original_inputs=len(original),
    final_reservation=supervisor.read(ROOT/'TestResults/qualification-supervisor-reservation/active.json'),process_disposition=disposition,
    source_tools=state['plan']['tools'],governance_sha256={p:supervisor.digest(ROOT/p) for p in governance},
    sealed_raw_evidence={str(CAMP/s/'result.json'):supervisor.digest(CAMP/s/'result.json') for s in state['selected']},
    raw_log_sha256=supervisor.digest(CAMP/'focused/unity.log'),raw_nunit_sha256=supervisor.digest(CAMP/'focused/results.xml'),
    raw_benchmark_sha256=supervisor.digest(CAMP/'focused/benchmark/admission.json'),
    archive=dict(path='diagnostic-records.zip',sha256=supervisor.digest(archive),members={name:supervisor.digest(p) for name,p in sorted(files.items())}),
    protected_entries={k:len(v) for k,v in protected.items() if isinstance(v,dict) and k!='other_saves'},
    save_namespaces=len(protected['other_saves']),other_save_files=sum(len(v) for v in protected['other_saves'].values()),
    retention='Preserve all local/raw/public inputs, outputs, processes/receipts and historical artifacts; no cleanup performed',
    limitations=['Diagnostic only; no optimized source or speedup','Unsupported thread allocation probe',
        'No retained/native memory, allocation-site or GC-pause attribution','Remaining selected parent self includes unisolated work',
        'No full suites, sustained profiles, build, native filesystem, standalone lifecycle or gameplay UAT qualification'])
write(OUT/'report.json',report)
print(json.dumps(dict(status=status['status'],source=SOURCE,archive_sha256=supervisor.digest(archive),out=str(OUT),nunit=xml.attrib),indent=2))

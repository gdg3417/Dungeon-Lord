"""Reproduce the disjoint candidate-envelope arithmetic from offline attribution."""
import json, sys
from pathlib import Path

d=json.loads(Path(sys.argv[1]).read_text())
def selected(sample,boundary,phase,ownership=None):
    return sum(value for key,value in sample['selected_self_ms'].items()
        if key.split('|')[0]==boundary and key.split('|')[1]==phase
        and (ownership is None or key.split('|')[2]==ownership)
        and key.split('|')[3] in ('LifetimeNormal','LifetimeAlternative'))
result={}
for label,boundary,phase,ownership in (
    ('eligible_setup_materialization','CapturedPlanMaterialization','setup','prepared-hit'),
    ('eligible_setup_planning','IntraroomPlanning','setup','prepared-hit'),
    ('eligible_replay_materialization','CapturedPlanMaterialization','replay',None),
    ('eligible_replay_planning','IntraroomPlanning','replay',None)):
    result[label]=[selected(s,boundary,phase,ownership) for s in d['partitions']]
result['eligible_envelope']=[sum(v[i] for v in result.values()) for i in range(5)]
result['envelope_percent_wall']=[100*result['eligible_envelope'][i]/d['wall_enabled_ms']['values'][i] for i in range(5)]
result['outside_eligible_envelope']=[d['wall_enabled_ms']['values'][i]-result['eligible_envelope'][i] for i in range(5)]
if len(sys.argv)>2:
    with Path(sys.argv[2]).open('x') as stream: json.dump(result,stream,indent=2)
else: print(json.dumps(result,indent=2))

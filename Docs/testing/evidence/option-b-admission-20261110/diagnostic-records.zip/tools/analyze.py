"""Offline arithmetic on the existing benchmark records; no Unity execution."""
import base64
import hashlib
import json
from pathlib import Path
import statistics
import sys

path=Path(sys.argv[1]); out=Path(sys.argv[2])
report=json.loads(path.read_text(encoding='utf-8'))
frequency=report['Frequency']
samples=report['Samples']
enabled=[s for s in samples if s['Enabled']]
names=enabled[0]['Boundaries']
def stats(values):
    return dict(values=values,minimum=min(values),median=statistics.median(values),maximum=max(values),mean=statistics.mean(values))
def milliseconds(ticks): return ticks*1000/frequency
def ancestry(records,index):
    result=[]
    while index>=0:
        result.append(names[records[index]['Boundary']]);index=records[index]['Parent']
    return result
rows={name:dict(calls=[s['Calls'][i] for s in enabled], inclusive_ms=stats([milliseconds(s['InclusiveTicks'][i]) for s in enabled]),
    selected_self_ms=stats([milliseconds(s['SelfTicks'][i]) for s in enabled])) for i,name in enumerate(names)}
partitions=[]
origins=['Unspecified','Pump','Acceptance','Execution','TerminalPin','Settlement','Release','Recovery','Opportunity','PassiveTick','Closure','Admission','LifetimeNormal','LifetimeAlternative','FinalWrite','Readback','Inspection']
for sample in enabled:
    records=sample['Records']; buckets={}; calls={}; origins_cost={}; roots=0
    for i,record in enumerate(records):
        name=names[record['Boundary']]; ancestors=ancestry(records,record['Parent'])
        origin=origins[record['Origin']]
        if record['Parent']<0: roots+=record['InclusiveTicks']
        phase='setup' if 'StartRecreation' in ancestors else 'replay' if 'PrefixReplay' in ancestors else 'probe' if 'AdmissionAssurance' in ancestors else 'other'
        ownership='prepared-hit' if 'AdmissionStartReuse' in ancestors else 'prepared-cold' if 'StartPreparation' in ancestors and origin in ('LifetimeNormal','LifetimeAlternative') else 'fresh'
        key='|'.join((name,phase,ownership,origin))
        buckets[key]=buckets.get(key,0)+milliseconds(record['SelfTicks'])
        calls[key]=calls.get(key,0)+1
        origins_cost[origin]=origins_cost.get(origin,0)+milliseconds(record['SelfTicks'])
    partitions.append(dict(index=sample['Index'],selected_self_ms=buckets,calls=calls,origins_self_ms=origins_cost,
        roots_ms=milliseconds(roots),outside_roots_ms=sample['Milliseconds']-milliseconds(roots),records=len(records),
        dropped_records=sample['DroppedRecords'],dropped_scopes=sample['DroppedScopes'],active_depth=sample['ActiveDepth']))
identities={}
for label in ('Input','Output'):
    data=base64.b64decode(report[label+'Base64'])
    (out/(label.lower()+'.json')).write_bytes(data)
    identities[label]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
summary=dict(source=report['Source'],unity=report['Unity'],frequency=frequency,identities=identities,
    wall_enabled_ms=stats([s['Milliseconds'] for s in enabled]),wall_disabled_ms=stats([s['Milliseconds'] for s in samples if not s['Enabled']]),
    samples=[{k:s[k] for k in ('Index','Enabled','Milliseconds','AllocatedBytes')} for s in samples],
    allocation_probe_bytes=report['AllocationProbeBytes'],empty_scope_ms=report['EmptyScopeMilliseconds'],
    boundaries=rows,partitions=partitions)
with (out/'attribution.json').open('x',encoding='utf-8') as f: json.dump(summary,f,indent=2,sort_keys=True)
print(json.dumps({k:summary[k] for k in ('source','identities','wall_enabled_ms','wall_disabled_ms','allocation_probe_bytes','empty_scope_ms')},indent=2))

$ErrorActionPreference = 'Stop'
$campaign = 'TestResults/foreground-profiler-state-isolation-20261024-01'
$expectedSource = 'bdd6ec6258a53eceea8871e6d4b91a49d4f95ced'
if ((git rev-parse HEAD).Trim() -ne $expectedSource) { throw 'Source pin mismatch' }
$baseline = Get-Content -LiteralPath "$campaign/preservation-before.json" -Raw | ConvertFrom-Json
if ($baseline.files.Count -eq 0) { throw 'Missing preservation snapshot' }
$settingsPath = Join-Path (Get-Location) 'ProjectSettings/ProjectSettings.asset'
$backup = [IO.File]::ReadAllBytes((Join-Path (Get-Location) "$campaign/ProjectSettings.asset.before"))
if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($settingsPath)) -ne [Convert]::ToBase64String($backup)) { throw 'Settings mismatch' }
$settings = [Text.Encoding]::UTF8.GetString($backup)
if (-not $settings.Contains("  productName: Dungeon Lord`r`n")) { throw 'Unexpected product' }
$isolated = [Text.Encoding]::UTF8.GetBytes($settings.Replace("  productName: Dungeon Lord`r`n", "  productName: Dungeon Lord Profiler State Isolation 20261024 01`r`n"))
$report = "$campaign/focused-01.xml"
$log = "$campaign/focused-01.log"
if ((Test-Path -LiteralPath $report) -or (Test-Path -LiteralPath $log)) { throw 'Used output identity' }
$oldOutput = $env:DUNGEON_FOREGROUND_DIAGNOSTIC_OUTPUT_ROOT
$oldSource = $env:DUNGEON_FOREGROUND_DIAGNOSTIC_SOURCE
$testExit = $null
try {
    [IO.File]::WriteAllBytes($settingsPath, $isolated)
    $env:DUNGEON_FOREGROUND_DIAGNOSTIC_OUTPUT_ROOT = $null
    $env:DUNGEON_FOREGROUND_DIAGNOSTIC_SOURCE = $null
    [IO.File]::WriteAllBytes((Join-Path (Get-Location) "$campaign/ProjectSettings.asset.test-input"), $isolated)
    & C:/Users/gdg34/AppData/Local/Unity/bin/unity.exe test C:/Dev/Dungeon-Lord --mode EditMode --filter DungeonBuilder.M0.Editor.Tests.ForegroundPerformance --output $report --timeout 1200 --no-color -- -logFile $log
    $testExit = $LASTEXITCODE
} finally {
    [IO.File]::WriteAllBytes($settingsPath, $backup)
    $env:DUNGEON_FOREGROUND_DIAGNOSTIC_OUTPUT_ROOT = $oldOutput
    $env:DUNGEON_FOREGROUND_DIAGNOSTIC_SOURCE = $oldSource
}
@{ source = $expectedSource; exitCode = $testExit; filter = 'DungeonBuilder.M0.Editor.Tests.ForegroundPerformance'; report = $report; log = $log; product = 'Dungeon Lord Profiler State Isolation 20261024 01'; optionalOutput = 'unset'; originalSettingsRestored = [Convert]::ToBase64String([IO.File]::ReadAllBytes($settingsPath)) -eq [Convert]::ToBase64String($backup) } | ConvertTo-Json | Set-Content -LiteralPath "$campaign/command-result.json"
exit $testExit

"""H2-A adapter using unchanged supervisor and H1-F4 preservation authorities."""
import argparse
import json
import copy
import os
import re
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'Tools/Presentation'))
import qualify_h1_f4 as q
import qualification_supervisor as supervisor

PREP = Path(__file__).resolve().parent
PRODUCT = 'Dungeon Lord B3B2 Smoke H1F4 H2AC2R3'
SAVE = Path.home() / 'AppData/LocalLow/gdg3417' / PRODUCT
q.identities = lambda attempt: (PREP, PRODUCT, SAVE)
ATTEMPT = 'h2a-checkpoint2-targeted-03'
DISCOVERY = ROOT / 'TestResults/qualification-supervisor/b1d0fe38d61f4d489a79684407ed959a/inventory/inventory.json'
EDIT_FILTER = ';'.join(('DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.H2ARetainedForeground',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonB3B1',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonB3B2',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonTwoFloor',
    'DungeonBuilder.M0.Editor.Tests.ForegroundPerformanceDiagnostic',
    'DungeonBuilder.M0.EditorTools.Tests.H1F4RecoveryContract'))
PLAY_FILTER = ';'.join('DungeonBuilder.M0.Tests.PlayMode.PhaseSevenA4ProductionShellPlayModeTests.' + name for name in (
    'LivingDungeonB3B2', 'AnalysisForegroundContinuity', 'RoomContentMapReassignmentCapacity', 'RoomContentMapReassignmentCategories'))
B3_FILTER = 'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonB3B1'
LIVING_FILTER = ';'.join(p for p in EDIT_FILTER.split(';') if p != B3_FILTER)
MEMORY_FILTER = 'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.H2ARetainedForeground.RepeatedPumpsDoNotAccumulateExecutionsOrBuffersAndAbandonmentReleasesManagedGraphs'

def prepare():
    q.win.assert_no_unity()
    for path in (ROOT / 'Assets').rglob('*.meta'):
        if re.search(r'^guid: [0-9a-f]{32}\s*$', path.read_text(encoding='utf-8-sig'), re.MULTILINE) is None:
            raise ValueError('Malformed GUID before import: ' + str(path))
    if (PREP / 'inventory.json').exists() or SAVE.exists():
        raise ValueError('Require unused preparation/product/save identities')
    q.write(PREP / 'protected.json', q.protected(SAVE))
    original = q.inventory(ROOT)
    q.write(PREP / 'original-inputs.json', original)
    with zipfile.ZipFile(PREP / 'original-inputs.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name in original: archive.write(ROOT / name, name)
    path = ROOT / q.SETTINGS[0]
    measured_product = 'Dungeon Lord B3B2 Smoke H1F4 20261027 h2a-checkpoint1'
    prepared = q.qualification_player_settings(path.read_bytes(), measured_product)
    old = ('  productName: ' + measured_product + '\n').encode()
    new = ('  productName: ' + PRODUCT + '\n').encode()
    if prepared.count(old) != 1: raise ValueError('Exact product substitution required')
    isolated = prepared.replace(old, new)
    if isolated.replace(new, old) != prepared: raise ValueError('Irreversible product substitution')
    path.write_bytes(isolated)
    for name in q.SETTINGS[1:]:
        path = ROOT / name
        path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n'))
    q.write(PREP / 'qualified-inputs.json', q.inventory(ROOT))
    q.write(PREP / 'inventory.json', {'owner': 'H2-A checkpoint 2', 'purpose': 'directly affected EditMode and PlayMode regressions',
        'retention': 'preserve', 'project': str(ROOT), 'preparation': str(PREP), 'product': PRODUCT, 'save': str(SAVE),
        'generated_project_paths': [str(ROOT / name) for name in ('Library', 'Temp', 'Logs')],
        'source_sha': supervisor.git(ROOT, 'rev-parse', 'HEAD')})

def plan():
    path = PREP / 'plan.json'
    if not path.exists(): q.plan(ATTEMPT)
    data = json.loads(path.read_text())
    assert data['source_sha'] == supervisor.git(ROOT, 'rev-parse', 'HEAD')
    definitions = supervisor.git(ROOT, 'diff', '--name-only', '9fb945209fb49d0b314a9d96f57b660de78b63f3', '--',
        'Assets/_Project/Tests', 'Assets/_Project/Editor').splitlines()
    integration = 'Assets/_Project/Tests/EditMode/H2ARetainedForegroundIntegrationTests.cs'
    assert definitions == [integration], definitions
    signature = r'\[Test(?:Case)?[^]]*\]|public\s+void\s+\w+\('
    original_definition = supervisor.git(ROOT, 'show', '9fb945209fb49d0b314a9d96f57b660de78b63f3:' + integration)
    assert re.findall(signature, original_definition) == re.findall(signature, (ROOT / integration).read_text(encoding='utf-8-sig')), 'Discovery signatures changed'
    assert q.inventory(ROOT) == json.loads((PREP / 'qualified-inputs.json').read_text())
    discovered = json.loads(DISCOVERY.read_text(encoding='utf-8-sig'))
    def selected(mode, filters):
        return [c for c in discovered[mode] if any(c['Name'].startswith(p) for p in filters.split(';'))]
    edit_cases = selected('EditMode', EDIT_FILTER); play_cases = selected('PlayMode', PLAY_FILTER)
    assert len(edit_cases) == 299 and len(play_cases) == 14, (len(edit_cases), len(play_cases))
    assert len(selected('EditMode', B3_FILTER)) == 51 and len(selected('EditMode', LIVING_FILTER)) == 248
    assert len(selected('EditMode', MEMORY_FILTER)) == 1
    assert all(c['State'] == 'Runnable' for c in edit_cases + play_cases)
    q.write(PREP / 'selection.json', {'discovery_sha256': q.sha(DISCOVERY), 'discovery_source_sha': '9fb945209fb49d0b314a9d96f57b660de78b63f3',
        'unchanged_discovery_signatures_verified': True, 'source_sha': data['source_sha'], 'edit': edit_cases, 'play': play_cases,
        'additional_cold_memory_case': selected('EditMode', MEMORY_FILTER)})
    data['tools'][str(Path(__file__).resolve())] = {'sha256': q.sha(__file__), 'version': 'H2-A checkpoint2 targeted explicit adapter'}
    data['tools'][str(q.CLI)]['version'] = 'Unity CLI 1.0.0-beta.17'
    for stage in data['stages']:
        stage['command'][2] = str(Path(__file__).resolve())
    original = copy.deepcopy(data['stages'])
    def before(name, depends):
        stage = copy.deepcopy(original[0]); stage['id'] = name; stage['depends'] = depends
        stage['command'][-1] = '{campaign}/' + name; return stage
    def workload(name, mode, preflight, count):
        stage = copy.deepcopy(original[1]); stage.update(id=name, depends=[preflight], expected_tests=count, timeout_seconds=1800)
        stage['command'][3] = mode
        if name != 'focused': stage['artifacts'].append('fixture-inputs')
        return stage
    stages = [before('memory-preflight', []), workload('focused', 'run-memory', 'memory-preflight', 1),
        before('b3b1-preflight', ['focused']), workload('b3b1-regressions', 'run-b3b1', 'b3b1-preflight', 51),
        before('edit-preflight', ['b3b1-regressions']), workload('living-regressions', 'run-edit', 'edit-preflight', 248),
        before('play-preflight', ['living-regressions']), workload('scene-play', 'run-play', 'play-preflight', len(play_cases)),
        before('restore-preflight', ['living-regressions', 'scene-play']), original[3], original[4]]
    stages[-1]['depends'] = [s['id'] for s in stages[:-1]]
    data['stages'] = stages; data['selections'] = {'targeted': [s['id'] for s in stages]}
    for source in (DISCOVERY, PREP / 'selection.json'):
        data['tools'][str(source)] = {'sha256': q.sha(source), 'version': 'Exact source-pinned discovery selection'}
    data['approved_substitutions'].append('Measured H1-F4 settings preparation with exact reversible productName substitution to ' + PRODUCT + '; 299 directly affected EditMode and 14 PlayMode cases. No sustained profile is selected. Existing adb and prior campaigns remain preserved. No historical helper or process ownership rule is changed.')
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'sealed_plan': str(path), 'edit': len(edit_cases), 'play': len(play_cases)}))

def run(stage, kind='living'):
    stage = Path(stage).resolve()
    for name in ('DUNGEON_FOREGROUND_DIAGNOSTIC_OUTPUT_ROOT', 'DUNGEON_ADMISSION_BENCHMARK_ROOT'):
        if os.environ.get(name): raise ValueError('Optional exporter must be unset: ' + name)
    filters = {'living': LIVING_FILTER, 'play': PLAY_FILTER, 'b3b1': B3_FILTER, 'memory': MEMORY_FILTER}
    stages = {'living': 'living-regressions', 'play': 'scene-play', 'b3b1': 'b3b1-regressions', 'memory': 'focused'}
    command = [str(q.CLI), 'test', str(ROOT), '--mode', 'PlayMode' if kind == 'play' else 'EditMode', '--filter', filters[kind],
        '--output', str(stage / 'results.xml'), '--timeout', '1700', '--no-color', '--', '-logFile', str(stage / 'unity.log')]
    return q.run_child(ATTEMPT, stage, command, stages[kind], 'cli-exit.json')

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['prepare', 'plan', 'preflight', 'run-test', 'run-edit', 'run-play', 'run-b3b1', 'run-memory', 'restore', 'finish'])
    p.add_argument('--attempt', default=ATTEMPT)
    p.add_argument('--stage')
    args = p.parse_args()
    if args.mode == 'prepare': prepare()
    elif args.mode == 'plan': plan()
    elif args.mode == 'preflight': q.preflight(ATTEMPT, args.stage)
    elif args.mode == 'run-test': sys.exit(run(args.stage))
    elif args.mode == 'run-edit': sys.exit(run(args.stage))
    elif args.mode == 'run-play': sys.exit(run(args.stage, 'play'))
    elif args.mode == 'run-b3b1': sys.exit(run(args.stage, 'b3b1'))
    elif args.mode == 'run-memory': sys.exit(run(args.stage, 'memory'))
    elif args.mode == 'restore': q.restore(ATTEMPT, args.stage)
    elif args.mode == 'finish': q.preflight(ATTEMPT, args.stage, restored=True)

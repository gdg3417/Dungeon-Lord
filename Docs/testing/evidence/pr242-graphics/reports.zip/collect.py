"""Collect new evidence only. Original B3A/incident records are never rewritten."""
from pathlib import Path
import hashlib, json, subprocess, sys, zipfile, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Tools/Presentation'))
import qualify_pr242_graphics as q
OUT=Path(__file__).resolve().parent
DEST=ROOT/'Docs/testing/evidence/pr242-graphics'
REVIEWED='0635337a1918032b925685534e8b8309f520170e'
QUALIFIED='b5502291e9da3d229bbcc3d152f8bd56954d84eb'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,value):
    with path.open('x',encoding='utf-8') as stream: json.dump(value,stream,indent=2)
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()

def collect():
    names=['qualification.json','qualification.md','reports.zip','matrix-screenshots.zip','changed-files.md']
    for name in names: q.unused(DEST/name)
    baseline=read(OUT/'baseline.json'); q.verify(baseline['protected']); q.verify_authored_scope()
    attempts=[]
    for folder in sorted(OUT.iterdir()):
        if not folder.is_dir() or not (folder/'prepared.json').exists(): continue
        if not (folder/'restored.json').is_file(): raise ValueError('Attempt not restored: '+str(folder))
        q.verify(read(folder/'artifact-index.json'))
        plan=read(folder/'prepared.json'); command=read(folder/'command.json')
        item=dict(attempt=folder.name,stage=plan['stage'],sourceCommit=plan['commit'],command=command,
                  restored=read(folder/'restored.json'),preparedManifestSha256=q.sha(folder/'prepared.json'),
                  log=dict(path=str(folder/'editor.log'),sha256=q.sha(folder/'editor.log'),rawRetainedLocally=True))
        if (folder/'results.xml').exists():
            run=ET.parse(folder/'results.xml').getroot()
            item['tests']={key:run.get(key) for key in ['total','passed','failed','skipped','result','start-time','end-time','duration']}
            item['failures']=[dict(name=c.get('fullname'),message=c.findtext('failure/message'),stack=c.findtext('failure/stack-trace'))
                              for c in run.iter('test-case') if c.get('result')=='Failed']
            item['diagnostics']=[dict(name=c.get('fullname'),output=c.findtext('output')) for c in run.iter('test-case')
                                 if c.get('name') in ['RoomContentMouseTouchPreviewAndResumeKeepCanonicalIsolated',
                                                     'TransactionalRoomConstructionLayoutsLocalizationAndResume','RoomContentInputAndResume']]
        attempts.append(item)
    required=['focused-04','ui-edit-02','ui-play-02','build-03']
    for name in required:
        item=next(a for a in attempts if a['attempt']==name)
        if item['command']['exitCode']!=0: raise ValueError('Required check non-green: '+name)
        if 'tests' in item and (item['tests']['failed']!='0' or int(item['tests']['passed'])==0): raise ValueError('Tests did not pass: '+name)
    ui_commit=next(a['sourceCommit'] for a in attempts if a['attempt']=='focused-04')
    for a in attempts:
        if a['attempt'] in required and git('diff','--name-only',ui_commit,a['sourceCommit'],'--',*q.inputs.INPUT_ROOTS):
            raise ValueError('Required checks did not qualify identical committed Unity inputs')
    build=q.destinations('build-03')['build']; package=read(build/'build-report.json')
    if package['buildResult']!='Succeeded' or package['errorCount']!=0 or not package['developmentBuild']: raise ValueError('Build failed')
    artwork=(build/'packed-dungeon-art.txt').read_text(encoding='utf-8-sig').splitlines()
    if len(artwork)!=52: raise ValueError('Production artwork missing')
    dll=(build/'Dungeon Lord_Data/Managed/Assembly-CSharp.dll').read_bytes()
    excluded=[b'SyntheticForegroundQualification',b'SettleSyntheticTerminal',b'LivingDungeonTerminalSettlement']
    if any(name in dll for name in excluded): raise ValueError('B3A capability leaked into player')
    if b'PlaceDevelopmentAction' not in dll: raise ValueError('Corrected production UI code missing from player')
    data=build/'Dungeon Lord_Data'
    namespace=q.destinations('build-03')['namespace']
    product=q.destinations('build-03')['product']
    if namespace.encode() not in (data/'sharedassets0.assets').read_bytes(): raise ValueError('Isolated save namespace not packaged')
    if product.encode() not in (data/'globalgamemanagers').read_bytes(): raise ValueError('Isolated product identity not packaged')
    old=read(ROOT/'TestResults/living-dungeon-b3a-20261017/baseline.json')
    q.verify(old['protected'])
    historical=read(ROOT/'TestResults/living-dungeon-b3a-20261017/historical-evidence-before.json')
    mismatches=[r for r in historical if not Path(r['path']).is_file() or q.sha(Path(r['path']))!=r['sha256']]
    if len(mismatches)!=5: raise ValueError('Unexpected original incident preservation state')
    accepted=read(ROOT/'TestResults/living-dungeon-b3a-20261017/missing-original-screenshots.json')
    if {(r['path'],r['sha256']) for r in mismatches}!={(r['path'],r['sha256']) for r in accepted}:
        raise ValueError('Historical mismatches differ from the five accepted originals')
    original_records=[]
    for name in ['qualification.md','qualification-reports.zip','report-summary.json','source-applicability.json',
                 'qualification-status.json','safety-closeout.md','safety-closeout.json','safety-closeout-reports.zip']:
        path='Docs/testing/evidence/living-dungeon-b3a/'+name
        clean=git('hash-object','--path',path,path); original=git('rev-parse',REVIEWED+':'+path)
        if clean!=original: raise ValueError('Historical evidence changed: '+path)
        original_records.append(dict(path=path,sha256=q.sha(ROOT/path),reviewedGitBlobUnchanged=True))
    protected_paths=['Assets/_Project/Scripts/Gameplay','Assets/_Project/Scripts/Services','Assets/_Project/Scripts/Core',
        'Assets/_Project/Tests/EditMode/LivingDungeonPhaseB3ATests.cs',
        'Assets/_Project/Tests/PlayMode/LivingDungeonPhaseB3APlayModeTests.cs',
        'Assets/_Project/Editor/DungeonSpatial/Tests/LivingDungeonPhaseB3AEditModeFixtures.cs']
    if git('diff','--name-only',QUALIFIED,'HEAD','--',*protected_paths): raise ValueError('B3A protected source changed')
    screenshots=sorted((OUT/'focused-04/screens').rglob('*.png'))
    with zipfile.ZipFile(DEST/'matrix-screenshots.zip','x',zipfile.ZIP_DEFLATED) as archive:
        for path in screenshots: archive.write(path,path.relative_to(OUT/'focused-04/screens').as_posix())
    with zipfile.ZipFile(DEST/'reports.zip','x',zipfile.ZIP_DEFLATED) as archive:
        archive.write(OUT/'baseline.json','baseline.json'); archive.write(Path(__file__),'collect.py')
        for folder in sorted(OUT.iterdir()):
            if not folder.is_dir(): continue
            for name in ['results.xml','prepared.json','command.json','restored.json','artifact-index.json']:
                path=folder/name
                if path.is_file(): archive.write(path,folder.name+'/'+name)
        archive.writestr('raw-log-hashes.json',json.dumps([a['log'] for a in attempts],indent=2))
        archive.writestr('historical-records-unchanged.json',json.dumps(original_records,indent=2))
    status=dict(automationPassed=True,ownerUATReviewed=False,independentReviewComplete=False,prRemainsDraft=True,
        reviewedHead=REVIEWED,qualifiedB3ACommit=QUALIFIED,qualifiedUISourceCommit=ui_commit,
        attempts=attempts,build=dict(report=package,artwork=len(artwork),qualificationCapabilityAbsent=True,correctedUICodePresent=True,
            isolatedProduct=product,isolatedSaveNamespace=namespace,identitiesPacked=True,
            playerExeSha256=q.sha(build/'Dungeon Lord.exe'),managedAssemblySha256=q.sha(data/'Managed/Assembly-CSharp.dll'),
            output=str(build),files=sum(p.is_file() for p in build.rglob('*')),bytes=sum(p.stat().st_size for p in build.rglob('*') if p.is_file())),
        preservation=dict(freshProtected=len(baseline['protected']),freshUnchanged=len(baseline['protected']),
            originalSavePlayerFiles=len(old['protected']),originalSavePlayerUnchanged=len(old['protected']),
            originalHistoricalFiles=len(historical),originalHistoricalMatching=len(historical)-len(mismatches),
            acceptedMissingOriginals=mismatches,originalRecords=original_records,
            ownerException='Accepted permanent loss; not restored and original audit not relabeled as successful.'),
        b3aProtectedRuntimeTestsUnchanged=True,screenshots=len(screenshots),
        archives=[dict(path=name,sha256=q.sha(DEST/name)) for name in ['reports.zip','matrix-screenshots.zip']])
    write(DEST/'qualification.json',status)
    changed=git('diff','--name-only',REVIEWED,'HEAD').splitlines()
    changed=sorted(set(changed+[('Docs/testing/evidence/pr242-graphics/'+n) for n in names+['manual-uat.md']]))
    with (DEST/'changed-files.md').open('x',encoding='utf-8') as stream:
        stream.write('# Exact graphical correction files since reviewed head\n\n'+ '\n'.join('- `'+n+'`' for n in changed)+'\n')
    rows=[]
    for a in attempts:
        tests=a.get('tests',{})
        rows.append('| '+a['attempt']+' | '+a['sourceCommit'][:8]+' | '+str(tests.get('passed','—'))+' | '+str(tests.get('failed','—'))+' | '+str(tests.get('skipped','—'))+' | '+str(a['command']['exitCode'])+' |')
    text='''# PR #242 graphical correction qualification

Status: automated correction qualified; independent ChatGPT review and owner UI qualification remain pending. PR remains Draft and must not merge. Actual model GPT-6.1 Sol High, explicitly escalated from Medium for fresh preservation isolation and input/layout frame correctness. No fallback, delegation, new branch, project copy or Editor installation.

Reviewed head: `'''+REVIEWED+'''`. Final tested UI source: `'''+status['qualifiedUISourceCommit']+'''`. B3A runtime/test baseline: `'''+QUALIFIED+'''`. Subsequent evidence documentation does not change the qualified Unity inputs. See [exact changed files](changed-files.md), [machine-readable results](qualification.json), [archived reports](reports.zip) and [matrix captures](matrix-screenshots.zip).

The old failure occurs after touch, not mouse. Actual measurements prove the successful mouse preview changes the viewport from `(0,360,1920,473)` to `(0,433,1920,400)` with unchanged camera center/orthographic size. The cached touch pixel resolves to `(-0.50,4.17)` instead of intended cell `(0,4)`. The test now waits for existing viewport stability and reprojects the intended cell, checks camera/viewport round-trip and interception, observes touch ID 1/current device in the player Dynamic update, and asserts the actual preview cell. All original mouse/touch, draft, confirmation and resume assertions remain. No production input dispatch changed.

Attempts 01/02 exposed an overly strict new diagnostic: an EditMode coroutine reads the Editor input buffer, where touch ID was 0. The player-update observer records ID 1 at the intended screen point; the diagnostic was corrected to observe the same buffer as the controller. Both failed reports are retained. Attempt 02 additionally showed that a 14-pixel expanded details strip was not readable despite passing the old assertion; the correction was extended and the test strengthened to require a complete measured text line.

Construction-only responsive chrome is compacted without reducing Large text: decorative landscape HUD icons/vertical spacing are removed; the map gets a proportional minimum; optional Development Tools moves into the existing Display popover during landscape construction, leaving required draft actions in place. The action returns outside construction. Normal/content/floor/replay presentation retains its established path. At 1280×720/Large with 600 safe-panel height, the collapsed viewport increases from 122 to 195; expanded viewport is 156 with 39 pixels of readable scrolling detail. The unchanged requirement is greater than 150. Twelve resolution/text combinations and both details states pass; Japanese/expanded localization, required action reachability and save/resume/discard remain asserted. A PlayMode wrapper runs the construction matrix through the actual scene.

Final review added the actual Development Tools round trip to every landscape matrix case and closes Display on that transition, preventing a popover remaining over the development view. The first passing packet/source (b211993d) is retained locally under `provisional-b211-packet`, with all original report/capture bytes preserved. Focused, EditMode, PlayMode and build checks were repeated against the final correction using new attempts. The frozen initial plan is retained as history; its narrow initial candidate was extended only by the minimal UI host routing and PlayMode wrapper necessary to retain readable expanded information.

| Attempt | Source SHA | Passed | Failed | Skipped | CLI exit |
| --- | --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Every run used the existing Unity 6000.3.2f1/CLI workflow, sequentially. Exact commands/filters and NUnit timestamps are archived. The broad UI filters are recorded rather than described as a full EditMode/PlayMode suite. The passing focused source is the same as the broad UI/build source. No old failure report was edited or assertion weakened. Licensing-client diagnostic noise in failed attempts did not replace their actual NUnit verdicts.

Fresh campaign `TestResults/pr242-graphics-20261018` uses separate per-attempt Unity product/save identities, config/static fixture namespaces, GUID-qualified shared screenshot names, direct capture paths, report/log/build destinations and exact source manifests. Read-only preflight validates baseline/script/commit, every prepared input/backup/transformation and protected file before each launch. A disposable guard check passed and an inactive preflight rejected without launching Unity. Every attempt restores exact authored inputs and the five original local Unity overrides, archives known generated overrides and indexes outputs for preservation checks before later attempts. No unexpected source change is accepted. Raw Editor logs/source backups remain local; public evidence contains report output and raw-log hashes, not licensing logs.

All '''+str(len(baseline['protected']))+''' fresh protected files remain unchanged, including XML/logs and previous builds/results. All '''+str(len(old['protected']))+''' original protected save/player files match. Original historical evidence remains '''+str(len(historical)-len(mismatches))+'/'+str(len(historical))+'''; the five original missing screenshot hashes and incident are preserved, with the owner's accepted permanent-loss exception explicitly recorded. This does not claim restoration or retroactively successful original preservation. Historical B3A reports/status/incident records remain unchanged. B3A Gameplay/Services/Core and its EditMode/PlayMode/bridge fixtures have an empty diff against the qualified commit; strict input hashes verify other unchanged authorities. No settlement, scheduling, schema, checkpoint, history, C2, mana, Heat or recovery logic changed.

Build attempt 01 correctly rejected the temporary product name through the existing exact project-identity guard (CLI 6); no player was produced. Build attempts 02/03 retain all strict identity conditions and temporarily substitute only the expected product-name constant to the same reviewed isolation alias. Attempt 03 qualifies the final UI revision. This is an explicit qualification input, not a committed production guard change. Company/application ID/template checks remain intact. The original utility and settings are restored byte-for-byte. Only tooling/evidence changed between qualification-profile commits; all required final checks use identical committed Unity inputs, verified during collection.

The Windows Development build succeeded with 0 errors. Its report/warnings, 52 packed artwork assets, package inventory and excluded qualification capabilities are recorded in qualification.json. The packaged product/save identity and corrected UI code are checked in the actual player. It is an isolated qualification player, not a release-identity build. It has not established owner-confirmed usability. Follow [the sequential Editor and standalone owner procedure](manual-uat.md); report unavailable touch hardware and any untested scenario. Independent review and owner evidence remain the blockers to Ready/merge.
'''
    with (DEST/'qualification.md').open('x',encoding='utf-8') as stream: stream.write(text)
    print(json.dumps(dict(automationPassed=True,attempts=len(attempts),tests=[(a['attempt'],a.get('tests')) for a in attempts],changedFiles=len(changed))))
if __name__=='__main__': collect()

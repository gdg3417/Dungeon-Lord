$ErrorActionPreference = 'Stop'
$campaign = 'C:/Dev/Dungeon-Lord/TestResults/phase7-analysis-recovery-20261022-r2'
$edit = Get-Content "$campaign/02-full-edit-exit.json" -Raw | ConvertFrom-Json
[xml]$xml = Get-Content "$campaign/02-full-edit.xml" -Raw
if ($edit.exitCode -ne 0 -or $xml.'test-run'.failed -ne '0') { throw 'Complete EditMode gate is not passing' }
if (Test-Path "$campaign/03-full-play.xml") { throw 'Preserve existing report' }
$started = [DateTime]::UtcNow.ToString('o')
Set-Location -LiteralPath 'C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-p249r2-play'
& 'C:/Users/gdg34/AppData/Local/Unity/bin/unity.exe' test C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-p249r2-play --mode PlayMode --output "$campaign/03-full-play.xml" --timeout 10800 --format json --no-color -- -logFile "$campaign/03-full-play.log" > "$campaign/03-full-play-command.json"
$code = $LASTEXITCODE
@{source='c870c5dc92aee87e854af350aa0a73653d045ff2';stage='play';startedUtc=$started;finishedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$code;timeoutSeconds=10800;selection='complete PlayMode; no filter or exclusions'} | ConvertTo-Json | Set-Content "$campaign/03-full-play-exit.json"
exit $code

from pathlib import Path
import json,subprocess,sys
import campaign as c
root=c.project('edit')/'TestResults'; output=c.OUT/'profiles'; output.mkdir(exist_ok=False)
sources=[(p,'bare-production') for p in root.glob('foreground-profile-*.json')]
sources += [(p,'one-active-floor' if 'owner-inactive' in p.name else 'two-active-floors') for p in (root/'living-dungeon-two-floor-20261020').glob('*.profile.json')]
assert len(sources)==3
rows=[]; tool=c.ROOT/'Tools/Presentation/summarize_two_floor_profile.py'
for source,kind in sources:
    data=json.loads(source.read_text(encoding='utf-8-sig')); assert data['Passed'] and data['CompletedRuns']==68 and data['Product']==c.PRODUCT
    dest=output/(kind+'.json')
    subprocess.run([sys.executable,str(tool),str(source),str(dest)],check=True,stdout=subprocess.DEVNULL,timeout=120)
    summary=json.loads(dest.read_text())
    rows.append(dict(kind=kind,source_commit=c.SOURCE,raw=str(source),raw_sha256=c.sha(source),summary=str(dest),summary_sha256=c.sha(dest),tool_sha256=c.sha(tool),completed_runs=data['CompletedRuns'],passed=data['Passed'],workload=summary['workload'],allocations=dict(thread=summary['threadAllocationCounterAvailable'],frame=summary['frameAllocationCounterAvailable'])))
c.write('profile-applicability.json',rows)
print(json.dumps(rows,indent=2))

from pathlib import Path
import json,datetime
import campaign as c
history=c.read('historical-before.json'); changes=[]
for i,row in enumerate(history):
    p=Path(row['path']); h=c.sha(p) if p.is_file() else None
    if h!=row['sha256']: changes.append(dict(path=str(p),before=row['sha256'],after=h))
    if i and i%10000==0: print('Historical preservation checked:',i,flush=True)
protected=c.read('protected-before.json'); personal=[]
for row in protected:
    p=Path(row['path']); h=c.sha(p) if p.is_file() else None
    if h!=row['sha256']: personal.append(dict(path=str(p),before=row['sha256'],after=h))
c.write('preservation-check-before-ui-completion.json',dict(historical_checked=len(history),historical_changes=changes,protected_checked=len(protected),protected_changes=personal,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),current_gui_product_excluded='New isolated P249R2 product; no live canonical files read'))
assert not changes and not personal
print(json.dumps(dict(historical_unchanged=len(history),original_persistent_unchanged=len(protected))))

from pathlib import Path
import shutil,json,hashlib
import campaign as c
closed=[]
for stage in ['focused','edit','play','nativefs']:
    target=c.project(stage); before=c.compare(stage); assert not before['failures']
    prepared=c.read(stage+'-inputs-prepared.json'); originals={r['path']:r['source_sha256'] for r in prepared['files']}
    archived=[]
    for name in c.q.source_inventory(c.ROOT):
        source=c.ROOT/name; dest=target/name
        assert c.sha(source)==originals[name]
        if source.read_bytes()!=dest.read_bytes():
            saved=c.OUT/'source-input-closure'/stage/name; c.q.no_redirect(saved); assert not saved.exists()
            saved.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(dest,saved); assert c.sha(saved)==c.sha(dest)
            archived.append(dict(path=name,qualified_sha256=c.sha(saved),original_sha256=originals[name]))
            shutil.copyfile(source,dest)
    names=c.q.source_inventory(c.ROOT); actual=c.q.target_inventory(target)
    assert set(names)==actual and all(c.sha(c.ROOT/n)==c.sha(target/n) for n in names)
    closed.append(dict(stage=stage,input_count=len(names),original_bytes_restored=True,archived_qualified_inputs=archived))
c.write('completed-source-inputs-restored.json',dict(source=c.SOURCE,closed=closed,native_project='Still qualified by six declared transformations while visible UI qualification remains open; no live canonical file read'))
print(json.dumps(dict(closed_stages=[r['stage'] for r in closed],original_inputs_each=1418,native_project_pending_ui=True)))

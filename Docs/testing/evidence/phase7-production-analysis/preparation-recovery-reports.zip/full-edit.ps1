$ErrorActionPreference = 'Stop'
$campaign = 'C:/Dev/Dungeon-Lord/TestResults/phase7-analysis-recovery-20261022-r2'
[xml]$focused = Get-Content "$campaign/01-prerequisites.xml" -Raw
if ($focused.'test-run'.failed -ne '0' -or $focused.'test-run'.passed -ne '4') { throw 'Focused prerequisites are not passing' }
if (Test-Path "$campaign/02-full-edit.xml") { throw 'Preserve existing report' }
$started = [DateTime]::UtcNow.ToString('o')
Set-Location -LiteralPath 'C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-p249r2-edit'
& 'C:/Users/gdg34/AppData/Local/Unity/bin/unity.exe' test C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-p249r2-edit --mode EditMode --output "$campaign/02-full-edit.xml" --timeout 14400 --format json --no-color -- -logFile "$campaign/02-full-edit.log" > "$campaign/02-full-edit-command.json"
$code = $LASTEXITCODE
@{source='c870c5dc92aee87e854af350aa0a73653d045ff2';stage='edit';startedUtc=$started;finishedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$code;timeoutSeconds=14400;selection='complete EditMode; no filter or exclusions'} | ConvertTo-Json | Set-Content "$campaign/02-full-edit-exit.json"
exit $code

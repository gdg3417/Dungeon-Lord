$ErrorActionPreference = 'Stop'
$campaign = 'C:/Dev/Dungeon-Lord/TestResults/phase7-analysis-recovery-20261022-r2'
$ready = Get-Content "$campaign/static-readiness.json" -Raw | ConvertFrom-Json
if ($ready.checks.PSObject.Properties.Value -contains $false) { throw 'Static readiness is not passing' }
if (Test-Path "$campaign/01-prerequisites.xml") { throw 'Preserve existing report' }
$started = [DateTime]::UtcNow.ToString('o')
Set-Location -LiteralPath 'C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-p249r2-focused'
& 'C:/Users/gdg34/AppData/Local/Unity/bin/unity.exe' test C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-p249r2-focused --mode EditMode --filter 'HistoricalGoldenRestoresAndReencodesExactPinnedBytes;OwnerUsabilityConstructionAndContentReachability;LivingDungeonTwoFloorWaitingSelectedFloorLayoutsPreserveCanonicalState' --output "$campaign/01-prerequisites.xml" --timeout 1800 --format json --no-color -- -logFile "$campaign/01-prerequisites.log" > "$campaign/01-prerequisites-command.json"
$code = $LASTEXITCODE
@{source='c870c5dc92aee87e854af350aa0a73653d045ff2';stage='focused';startedUtc=$started;finishedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$code;timeoutSeconds=1800} | ConvertTo-Json | Set-Content "$campaign/01-prerequisites-exit.json"
exit $code

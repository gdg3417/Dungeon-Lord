$ErrorActionPreference = 'Stop'
$campaign = 'C:/Dev/Dungeon-Lord/TestResults/phase7-analysis-recovery-20261022-r2'
$project = 'C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-p249r2-native'
foreach ($report in @('02-full-edit','03-full-play','04-native-filesystem')) {
    [xml]$xml = Get-Content "$campaign/$report.xml" -Raw
    if ($xml.'test-run'.failed -ne '0') { throw "Required gate failed: $report" }
}
if (Test-Path "$project/Builds/Development/Windows") { throw 'Preserve existing build' }
if (Test-Path "$campaign/05-build.log") { throw 'Preserve existing build log' }
Set-Location -LiteralPath $project
$started = [DateTime]::UtcNow.ToString('o')
& 'C:/Users/gdg34/AppData/Local/Unity/bin/unity.exe' build $project --target StandaloneWindows64 --execute-method DungeonBuilder.M0.EditorTools.DungeonVisualBuildQualification.BuildWindows --allow-dirty-build --timeout 1800 --no-tail --log-file "$campaign/05-build.log" --format json --no-color > "$campaign/05-build-command.json"
$code = $LASTEXITCODE
@{source='c870c5dc92aee87e854af350aa0a73653d045ff2';stage='native';startedUtc=$started;finishedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$code;timeoutSeconds=1800;product='DL B3B2 Smoke Two Floor P249R2';output="$project/Builds/Development/Windows/Dungeon Lord.exe"} | ConvertTo-Json | Set-Content "$campaign/05-build-exit.json"
exit $code

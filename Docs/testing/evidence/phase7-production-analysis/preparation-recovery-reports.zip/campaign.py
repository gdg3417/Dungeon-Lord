from pathlib import Path
import sys,json,hashlib,subprocess,shutil,datetime,re
ROOT=Path('C:/Dev/Dungeon-Lord'); OUT=ROOT/'TestResults/phase7-analysis-recovery-20261022-r2'
SOURCE='c870c5dc92aee87e854af350aa0a73653d045ff2'
PRODUCT='DL B3B2 Smoke Two Floor P249R2'
OWNER=Path('C:/Users/gdg34/AppData/LocalLow/gdg3417')
DATA=OWNER/PRODUCT
sys.path.insert(0,str(ROOT/'Tools/Presentation'))
import qualification_inputs as q
STAGES=('focused','edit','play','native','nativefs')
def project(stage):
    assert stage in STAGES
    return ROOT/'Temp'/('ui-composition-analysis-p249r2-'+stage)
def namespace(stage): return 'living-dungeon-b3b2-qualification-two-floor-p249r2-'+stage+'.json'
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,value):
    p=OUT/name
    with p.open('x',encoding='utf-8') as f: json.dump(value,f,indent=2)
def read(name): return json.loads((OUT/name).read_text())
def replacements():
    return {
      'ProjectSettings/ProjectSettings.asset': [('  productName: Dungeon Lord','  productName: '+PRODUCT,'Opt-in isolated product; same company/application IDs')],
      'Assets/_Project/Scripts/BuildTools/DevelopmentBuildUtility.cs': [('public const string ProductName = "Dungeon Lord";','public const string ProductName = "'+PRODUCT+'";','Preserve exact identity validation against isolated product')],
      'Assets/_Project/Tests/EditMode/BuildReadinessTests.cs': [('"gdg3417", "Dungeon Lord", "com.gdg3417.dungeonlord"','"gdg3417", "'+PRODUCT+'", "com.gdg3417.dungeonlord"','Align only the unchanged positive identity assertion; negative cases untouched')],
      'Assets/_Project/Editor/DungeonSpatial/Tests/PhaseSevenA4ProductionSceneTests.cs': [('owner-uat-starter.json','p249r2-starter-"+System.Guid.NewGuid().ToString("N")+".json','GUID per execution, including PlayMode reflection wrapper; File.Copy overwrite=false unchanged')]
    }
def expected(path,data,stage):
    q.NAMESPACE=namespace(stage); result=q.transformed(path,data)
    for old,new,reason in replacements().get(path,[]):
        assert result.count(old.encode())==1,(path,old)
        result=result.replace(old.encode(),new.encode())
    return result
def compare(stage):
    dest=project(stage); names=q.source_inventory(ROOT); actual=q.target_inventory(dest); rows=[]; failures=[]
    for path in names:
        a=(ROOT/path).read_bytes(); b=expected(path,a,stage); p=dest/path
        equal=p.is_file() and q.normalized(path,p.read_bytes())==q.normalized(path,b)
        if not equal: failures.append(path)
        rows.append(dict(path=path,source_sha256=hashlib.sha256(a).hexdigest(),expected_sha256=hashlib.sha256(q.normalized(path,b)).hexdigest(),qualified_sha256=sha(p) if p.exists() else None,equal=equal))
    failures += sorted(actual-set(names))
    return dict(stage=stage,source=SOURCE,expected_count=len(names),actual_count=len(actual),files=rows,failures=failures)
def prepare(stage):
    dest=project(stage)
    q.NAMESPACE=namespace(stage)
    if dest.exists():
        # Resume only our interrupted static preparation, never reuse old campaigns.
        assert stage=='focused' and not (OUT/'focused-inputs-prepared.json').exists()
        assert not compare(stage)['failures']
    else: q.prepare(ROOT,dest.name)
    transforms=[]
    for path in q.source_inventory(ROOT):
        original=(ROOT/path).read_bytes(); qualified=expected(path,original,stage)
        if qualified!=original:
            oldnew=[dict(old=a,new=b,reason=c) for a,b,c in replacements().get(path,[])]
            if path in (q.CONFIG,q.SERVICE): oldnew=[dict(old='save_primary.json',new=namespace(stage),reason='Approved isolated save filename substitution; config formatting/BOM/line endings follow existing helper')]
            transforms.append(dict(path=path,original_sha256=hashlib.sha256(original).hexdigest(),qualified_sha256=hashlib.sha256(qualified).hexdigest(),changes=oldnew,scope='disposable '+stage,restoration='Archive generated version after process exit; restore exact original bytes from source verified against original_sha256'))
            if (dest/path).read_bytes()!=qualified: (dest/path).write_bytes(qualified)
    fixtures=[]
    for name in ['historical-b1-format1.json','historical-c2-format2.json']:
        path='Tools/Presentation/Fixtures/'+name; src=ROOT/path; target=dest/path
        q.no_redirect(src); q.no_redirect(target); assert src.is_file()
        if target.exists():
            assert stage=='focused' and not (OUT/'focused-inputs-prepared.json').exists()
            assert target.is_file() and sha(src)==sha(target)
        tracked=subprocess.check_output(['git','show',SOURCE+':'+path],cwd=ROOT)
        worktree=src.read_bytes()
        assert tracked.replace(b'\r\n',b'\n')==worktree.replace(b'\r\n',b'\n')
        filtered=subprocess.check_output(['git','hash-object','--path',path,str(src)],cwd=ROOT,text=True).strip()
        blob=subprocess.check_output(['git','rev-parse',SOURCE+':'+path],cwd=ROOT,text=True).strip()
        assert filtered==blob
        target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists(): shutil.copyfile(src,target)
        assert sha(src)==sha(target)
        fixtures.append(dict(path=path,source_commit=SOURCE,source_sha256=sha(src),git_blob_sha256=hashlib.sha256(tracked).hexdigest(),git_blob_id=blob,git_filtered_worktree_identity=filtered,destination_sha256=sha(target),external_to_unity_inputs=True,process_working_directory=str(dest),note='Exact tracked working-tree bytes copied; Git checkout CRLF differs from LF blob only in line endings; checkpoint payload unchanged'))
    result=compare(stage); assert not result['failures']; assert result['expected_count']==1418
    write(stage+'-transformations.json',transforms); write(stage+'-external-fixtures.json',fixtures); write(stage+'-inputs-prepared.json',result)
    return dest
def inventory():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
    assert not DATA.exists()
    for stage in STAGES: q.no_redirect(project(stage)); assert not project(stage).exists()
    # Freeze the exact file list before hashing or drafting new campaign documents.
    protected=[p for p in sorted(OWNER.rglob('*')) if p.is_file()]
    bases=[ROOT/'Builds',ROOT/'TestResults',ROOT/'Docs/testing/evidence']
    bases += [p/'TestResults' for p in (ROOT/'Temp').iterdir() if p.is_dir() and (p/'TestResults').is_dir()]
    history=sorted({p for base in bases for p in base.rglob('*') if p.is_file() and not p.is_relative_to(OUT)})
    rows=[]
    for p in protected:
        q.no_redirect(p); dest=OUT/'protected-originals'/p.relative_to(OWNER)
        dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dest); h=sha(p); assert sha(dest)==h
        rows.append(dict(path=str(p),sha256=h,bytes=p.stat().st_size,backup=str(dest)))
    write('protected-before.json',rows); print('Protected files backed up:',len(rows),flush=True)
    rows=[]
    for i,p in enumerate(history):
        q.no_redirect(p); rows.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
        if i and i%10000==0: print('Historical files hashed:',i,flush=True)
    write('historical-before.json',rows); print('Historical files hashed:',len(rows),flush=True)
    paths=[]
    for stage in STAGES:
        for filename in [namespace(stage),'living-dungeon-b3b2-qualification-two-floor-'+'0'*32+'.json','p249r2-starter-'+'0'*32+'.json']:
            p=DATA/filename
            sidecar=str(p)+'.editor-draft.draft-'+'0'*32+'.000000.candidate'
            assert len(sidecar)<=240,(sidecar,len(sidecar)); paths.append(dict(path=str(p),sidecar_characters=len(sidecar)))
    write('path-envelopes.json',paths)
    for stage in STAGES: prepare(stage)
    readiness()
def readiness():
    checks={
      'A_goldens':all(len(read(s+'-external-fixtures.json'))==2 for s in STAGES),
      'B_product_guards':'B3B2 Smoke' in PRODUCT and 'B3B2 Smoke Two Floor' in PRODUCT,
      'C_prefix_and_configuration':all(namespace(s).startswith('living-dungeon-b3b2-qualification-two-floor-') for s in STAGES) and json.loads((ROOT/'Assets/_Project/Resources/living_dungeon_foreground_v2.json').read_text(encoding='utf-8-sig'))['Profile']=='living.foreground.c2.v2',
      'D_identity':all(len(read(s+'-transformations.json'))==6 for s in STAGES),
      'E_starter':not DATA.exists() and 'System.Guid.NewGuid()' in replacements()['Assets/_Project/Editor/DungeonSpatial/Tests/PhaseSevenA4ProductionSceneTests.cs'][0][1],
      'F_fresh_outputs':all(not (project(s)/'TestResults').exists() and not (project(s)/'Builds').exists() for s in STAGES),
      'G_declared_inputs':all(not read(s+'-inputs-prepared.json')['failures'] for s in STAGES),
      'H_protection':all(sha(Path(r['path']))==r['sha256'] for r in read('protected-before.json')),
      'I_complete_selection':all('--filter' not in (OUT/n).read_text() and ' --mode ' in (OUT/n).read_text() for n in ['full-edit.ps1','full-play.ps1']),
      'J_timeouts':'--timeout 14400' in (OUT/'full-edit.ps1').read_text() and '--timeout 10800' in (OUT/'full-play.ps1').read_text()
    }
    write('static-readiness.json',dict(source=SOURCE,product=PRODUCT,company='gdg3417',application='com.gdg3417.dungeonlord',checks=checks,stage_projects={s:str(project(s)) for s in STAGES},historical_count=len(read('historical-before.json')),protected_count=len(read('protected-before.json')),unity_inputs_per_project=1418,profile_verdict='Not run; static prerequisites only'))
    assert all(checks.values()),checks
    print(json.dumps(checks),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='prepare': inventory()
    elif sys.argv[1]=='compare': print(json.dumps(compare(sys.argv[2])))

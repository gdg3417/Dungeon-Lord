import sys,json,subprocess,datetime,uuid,shutil,re
from pathlib import Path
import campaign as c
phase,label,previous=sys.argv[1:4]
assert phase in ['two-floor-wait','two-floor-release','two-floor-finish','v1-upgrade','admit']
assert re.fullmatch(r'[a-zA-Z0-9-]+',label)
seal=c.read('05-build-artifact-manifest.json'); build=Path(seal['directory']); player=build/'Dungeon Lord.exe'
for r in seal['files']: assert c.sha(build/r['path'])==r['sha256']
assert all(c.sha(Path(r['path']))==r['sha256'] for r in c.read('protected-before.json'))
report=c.OUT/(label+'.json'); log=c.OUT/(label+'.log')
for p in [report,log,c.OUT/(label+'-command.json')]: assert not p.exists()
initial=previous in ['two-floor','v1','after-history']
source_manifest=None
if initial:
    source_dir=c.project('edit')/'TestResults/living-dungeon-two-floor-20261020/inputs'
    pattern=('v1' if previous=='v1' else 'two-floor')+'-*.manifest.json'
    source_manifest=sorted(source_dir.glob(pattern),key=lambda p:p.stat().st_mtime_ns)[-1]
    meta=json.loads(source_manifest.read_text()); assert meta['Product']==c.PRODUCT
    original_seed=Path(meta['SeedPath']); assert c.sha(original_seed)==meta['SeedSha256']
    if previous=='after-history': original_seed=c.OUT/'08-native-finish-post-exit.save.json'
    folder=c.OUT/'native-inputs'; folder.mkdir(exist_ok=True)
    seed=folder/(label+'.seed.json'); assert not seed.exists(); shutil.copyfile(original_seed,seed)
    meta.update(SaveFileName='living-dungeon-b3b2-qualification-two-floor-'+uuid.uuid4().hex+'.json',SeedPath=str(seed),SeedSha256=c.sha(seed))
    prior=folder/(label+'.manifest.json'); prior.open('x').write(json.dumps(meta,indent=2))
    save=c.DATA/meta['SaveFileName']; c.q.no_redirect(save); assert not save.exists()
    assert len(str(save)+'.editor-draft.draft-'+'0'*32+'.000000.candidate')<=240
    save.open('xb').write(seed.read_bytes())
    c.write(label+'-seed-provenance.json',dict(source=c.SOURCE,source_manifest=str(source_manifest),source_manifest_sha256=c.sha(source_manifest),source_seed=str(original_seed),source_seed_sha256=c.sha(original_seed),destination_manifest=str(prior),destination_seed_sha256=c.sha(seed),metadata_only_changes=['SaveFileName','SeedPath','SeedSha256'],checkpoint_bytes_changed=False))
else:
    prior=Path(previous).resolve(); assert prior.is_relative_to(c.OUT.resolve())
    old=json.loads(prior.read_text()); assert old['Passed'] and old['Product']==c.PRODUCT
    save=Path(old['SavePath']).resolve(); assert save.parent==c.DATA.resolve()
    record=c.read(prior.stem+'-command.json'); assert c.sha(save)==record['postExitSaveSha256']
args=[str(player),'-batchmode','-screen-width','1280','-screen-height','720','-logFile',str(log),'-b3b2ForegroundSmoke',phase,str(report),str(prior)]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
record=dict(source=c.SOURCE,artifact_id=seal['artifact_id'],artifact_manifest_sha256=c.sha(c.OUT/'05-build-artifact-manifest.json'),arguments=args,preLaunchSaveSha256=c.sha(save),startedUtc=start,timeoutSeconds=1800,rendering='Development batchmode production scene; injected qualification clock; not owner UAT')
c.write(label+'-command-start.json',record)
startup=subprocess.STARTUPINFO(); startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW; startup.wShowWindow=subprocess.SW_HIDE
with (c.OUT/(label+'-launcher.log')).open('x') as stream:
    result=subprocess.run(args,cwd=build,startupinfo=startup,timeout=1800,stdout=stream,stderr=subprocess.STDOUT)
record.update(exitCode=result.returncode,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),postExitSaveSha256=c.sha(save),postExitSaveBytes=save.stat().st_size)
dest=c.OUT/(label+'-post-exit.save.json'); dest.open('xb').write(save.read_bytes())
body=json.loads(report.read_text()) if report.exists() else None
preexit=Path(str(report)+'.save.json')
if preexit.exists():
    a=json.loads(preexit.read_text()); b=json.loads(save.read_text()); keys=sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))
    record['preExitPostExitChangedRootFields']=keys
    record['lifecycleOnly']=set(keys)<={'lastSavedUtcUnix','lastPausedUtcUnix'}
    record['preExitPostExitBytesEqual']=c.sha(preexit)==c.sha(save)
record['product']=body.get('Product') if body else None
c.write(label+'-command.json',record)
print(json.dumps(dict(phase=phase,exit=result.returncode,report=body,postExitSha256=record['postExitSaveSha256'],lifecycleOnly=record.get('lifecycleOnly'))))
assert result.returncode==0 and body and body['Passed'] and body['Product']==c.PRODUCT
assert Path(body['SavePath']).resolve()==save.resolve()
assert record.get('lifecycleOnly',False),'Unexpected canonical mutation after closed-prefix report'

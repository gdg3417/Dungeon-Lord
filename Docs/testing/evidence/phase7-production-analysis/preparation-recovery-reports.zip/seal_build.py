import json,struct,uuid
import campaign as c
build=c.project('native')/'Builds/Development/Windows'
report=json.loads((build/'build-report.json').read_text()); assert report['buildResult']=='Succeeded' and report['developmentBuild'] and report['targetPlatform']=='StandaloneWindows64'
assert report['includedScenes']==['Assets/_Project/Scenes/Bootstrap.unity'] and report['errorCount']==0
data=build/'Dungeon Lord_Data'; assert c.PRODUCT.encode() in (data/'globalgamemanagers').read_bytes()
managed=data/'Managed'
assert not any((managed/name).exists() for name in ['DungeonLord.WindowsStandaloneQualification.dll','nunit.framework.dll','UnityEngine.TestRunner.dll'])
exe=(build/'Dungeon Lord.exe').read_bytes(); pe=struct.unpack_from('<I',exe,0x3c)[0]; assert struct.unpack_from('<H',exe,pe+4)[0]==0x8664
files=[]
for p in sorted(build.rglob('*')):
    c.q.no_redirect(p)
    if p.is_file(): files.append(dict(path=p.relative_to(build).as_posix(),sha256=c.sha(p),bytes=p.stat().st_size))
c.write('05-build-artifact-manifest.json',dict(artifact_id='P249R2-'+uuid.uuid4().hex,source=c.SOURCE,implementation='948a38dc6f47b1419164fdfe8f44a2b3c9fd31f5',directory=str(build),product=c.PRODUCT,product_string_packed=True,pe_machine='AMD64 (0x8664)',test_assemblies_absent=True,report=report,files=files))
print(json.dumps(dict(files=len(files),build=report,player_sha256=c.sha(build/'Dungeon Lord.exe'),gameplay_sha256=c.sha(managed/'Assembly-CSharp.dll'))))

import sys,re,json,shutil,difflib
from pathlib import Path
import campaign as c
stage,label=sys.argv[1:3]; target=c.project(stage)
observed=c.compare(stage); c.write(label+'-build-inputs-observed.json',observed)
allowed={'Assets/Settings/UniversalRP.asset','Assets/UniversalRenderPipelineGlobalSettings.asset','ProjectSettings/ProjectSettings.asset','ProjectSettings/UnityConnectSettings.asset'}
changes=[]
for r in observed['files']:
    if r['equal']: continue
    path=r['path']; assert path in allowed,path
    original=(c.ROOT/path).read_bytes(); expected=c.expected(path,original,stage); actual=(target/path).read_bytes()
    a=expected.decode('utf-8-sig').replace('\r\n','\n'); b=actual.decode('utf-8-sig').replace('\r\n','\n')
    diff=list(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile='qualified-before',tofile='Unity-generated-after',lineterm=''))
    changed=[x for x in diff if x[:1] in ['+','-'] and x[:3] not in ['+++','---']]
    if path=='Assets/Settings/UniversalRP.asset':
        assert all(re.fullmatch(r'[+-]  m_Prefilter\w+: [0-4]',x) for x in changed),changed
    elif path=='Assets/UniversalRenderPipelineGlobalSettings.asset':
        def clear_runtime(text):
            start=text.index('    m_RuntimeSettings:\n'); stop=text.index('  m_AssetVersion:',start)
            return text[:start]+text[stop:]
        assert clear_runtime(a)==clear_runtime(b)
        start=b.index('    m_RuntimeSettings:\n'); stop=b.index('  m_AssetVersion:',start)
        block=b[start:stop].splitlines()
        assert block[:2]==['    m_RuntimeSettings:','      m_List:']
        assert all(re.fullmatch(r'      - rid: \d+',x) for x in block[2:])
        assert all(x.strip() in a for x in block[2:]),'New unmanaged rendering reference'
    elif path=='ProjectSettings/ProjectSettings.asset':
        stripped=b.replace('  m_BuildTargetBatching:\n  - m_BuildTarget: Standalone\n    m_StaticBatching: 1\n    m_DynamicBatching: 0','  m_BuildTargetBatching: []')
        assert sorted(a.splitlines())==sorted(stripped.splitlines()),'Unexpected settings content change'
    else:
        assert changed==['-  m_Enabled: 0','+  m_Enabled: 1'],changed
    dest=c.OUT/(label+'-generated-build-inputs')/path; dest.parent.mkdir(parents=True,exist_ok=True); assert not dest.exists()
    shutil.copyfile(target/path,dest); assert c.sha(dest)==c.sha(target/path)
    diffpath=dest.with_suffix(dest.suffix+'.diff'); diffpath.write_text('\n'.join(diff),encoding='utf-8')
    changes.append(dict(path=path,source_sha256=c.sha(c.ROOT/path),qualified_before_sha256=__import__('hashlib').sha256(expected).hexdigest(),generated_sha256=c.sha(dest),archive=str(dest),diff=str(diffpath)))
# Complete all classification/provenance checks before restoring any generated input.
assert set(observed['failures'])=={r['path'] for r in changes}
c.write(label+'-generated-build-provenance.json',dict(changes=changes,precedent='Docs/testing/evidence/phase7-visual-run-feedback/qualification.md; phase4-passive-online-mana/static-review-evidence.md',scope='Post-exit disposable build serialization only; not an accepted input substitution at launch'))
for r in changes:
    (target/r['path']).write_bytes(c.expected(r['path'],(c.ROOT/r['path']).read_bytes(),stage))
final=c.compare(stage); assert not final['failures']; c.write(label+'-build-inputs-final.json',final)
assert all(c.sha(Path(r['path']))==r['sha256'] for r in c.read('protected-before.json'))
rows=[]
for p in sorted(c.DATA.rglob('*')):
    if not p.is_file(): continue
    dest=c.OUT/(label+'-product-artifacts')/p.relative_to(c.DATA); dest.parent.mkdir(parents=True,exist_ok=True); assert not dest.exists(); shutil.copyfile(p,dest)
    assert c.sha(p)==c.sha(dest); rows.append(dict(path=str(p),archive=str(dest),sha256=c.sha(dest)))
c.write(label+'-build-closeout.json',dict(source=c.SOURCE,restored=changes,qualified_inputs=final['actual_count'],input_failures=[],protected_unchanged=350,product_snapshot=rows))
print(json.dumps(dict(restored=[r['path'] for r in changes],qualified_inputs=final['actual_count'],protected_unchanged=350)))

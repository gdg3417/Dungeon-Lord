import subprocess,json,datetime,hashlib
from pathlib import Path
import campaign as c
# Retain the exact preparation program used by the already completed full suites.
old=next(x['sha256'] for x in c.read('tools-at-full-edit.json') if x['path'].endswith('campaign.py'))
b=(c.OUT/'campaign.py').read_bytes().replace(b"STAGES=('focused','edit','play','native','nativefs')",b"STAGES=('focused','edit','play','native')")
assert hashlib.sha256(b).hexdigest()==old
with (c.OUT/'campaign-at-full-edit.py').open('xb') as f: f.write(b)
exe=Path('C:/Program Files/Unity/Hub/Editor/6000.3.2f1/Editor/Unity.exe')
target=c.project('nativefs'); report=c.OUT/'04-native-filesystem.xml'; log=c.OUT/'04-native-filesystem.log'; build=c.OUT/'nativefs-player'
for p in [report,log,build]: c.q.no_redirect(p); assert not p.exists()
assert not c.compare('nativefs')['failures']
args=[str(exe),'-batchmode','-projectPath',str(target),'-runTests','-testPlatform','StandaloneWindows64','-testFilter','DungeonBuilder.M0.Tests.PlayMode.Gd66WindowsStandaloneQualificationTests','-testResults',str(report),'-logFile',str(log),'-buildPlayerPath',str(build),'-playerHeartbeatTimeout','600']
record=dict(source=c.SOURCE,arguments=args,editor_sha256=c.sha(exe),startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timeoutSeconds=1800,route='Docs/planning/test-stage-matrix.md')
c.write('04-native-filesystem-command-start.json',record)
with (c.OUT/'04-native-filesystem-launcher.log').open('x') as stream:
    result=subprocess.run(args,cwd=target,timeout=1800,stdout=stream,stderr=subprocess.STDOUT)
record.update(exitCode=result.returncode,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
c.write('04-native-filesystem-command.json',record)
print(json.dumps(record))
raise SystemExit(result.returncode)

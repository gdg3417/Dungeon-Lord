import sys,json,subprocess,datetime,re
from pathlib import Path
import campaign as c
label,mode,width,height=sys.argv[1:5]; assert re.fullmatch(r'[A-Za-z0-9-]+',label)
seal=c.read('05-build-artifact-manifest.json'); build=Path(seal['directory']); player=build/'Dungeon Lord.exe'
for r in seal['files']: assert c.sha(build/r['path'])==r['sha256']
save=c.DATA/c.namespace('native'); c.q.no_redirect(save)
if mode!='reopen':
    seed=(c.OUT/mode).resolve(); assert seed.is_relative_to(c.OUT.resolve()) and seed.is_file() and not save.exists()
    save.open('xb').write(seed.read_bytes())
else: assert save.is_file()
log=c.OUT/(label+'.log'); assert not log.exists()
args=[str(player),'-screen-fullscreen','0','-screen-width',width,'-screen-height',height,'-logFile',str(log)]
record=dict(source=c.SOURCE,artifact_id=seal['artifact_id'],arguments=args,prelaunch_save_sha256=c.sha(save),save=str(save),startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),requested_viewport=[int(width),int(height)],purpose='Visible native UI qualification; ordinary unmodified foreground clock, not owner UAT')
with (c.OUT/(label+'-prelaunch.save.json')).open('xb') as f: f.write(save.read_bytes())
proc=subprocess.Popen(args,cwd=build)
record['pid']=proc.pid
c.write(label+'-ui-process.json',record)
print(json.dumps(record))

param([Parameter(Mandatory=$true)][string]$Receipt,[Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$full=[IO.Path]::GetFullPath($Receipt);$root='C:\Users\gdg34\AppData\LocalLow\gdg3417\DL B3B2 Smoke Two Floor P249R2\'
if(!$full.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($full) -notlike 'living-dungeon-b3b2-qualification-two-floor-p249r2-native.json.editor-draft*.commit'){throw 'Unapproved fault-fixture path'}
$held=[IO.File]::Open($full,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
try {
 @{utc=[DateTime]::UtcNow.ToString('o');path=$full;mode='Read access, share Read; allow evidence read but deny deletion; qualification fixture only'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Output 'lock-ready.json')
 $deadline=[DateTime]::UtcNow.AddSeconds(120)
 while(!(Test-Path -LiteralPath (Join-Path $Output 'release-lock')) -and [DateTime]::UtcNow -lt $deadline){Start-Sleep -Milliseconds 200}
}finally{$held.Dispose();@{utc=[DateTime]::UtcNow.ToString('o');released=$true}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Output 'lock-released.json')}

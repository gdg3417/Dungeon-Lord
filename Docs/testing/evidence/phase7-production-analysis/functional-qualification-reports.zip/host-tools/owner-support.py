"""PR249 D1 bounded host-native diagnostic only; no Unity input changes."""
from pathlib import Path
import ctypes as C
from ctypes import wintypes as W
import json,sys,subprocess,time,datetime,hashlib,os,shutil
R=Path(__file__).resolve().parent; O=R/'Sessions'; P=R
sys.path.insert(0,str(R/'Support')); import qualification_windows as win; import qualification_inputs as qi
DATA=Path('C:/Users/gdg34/AppData/LocalLow/gdg3417/DL B3B2 Smoke Two Floor P249R2')
ACTIVE=DATA/'living-dungeon-b3b2-qualification-two-floor-p249r2-native.json'
K=C.WinDLL('kernel32',use_last_error=True)
def api(lib,name,args,ret=W.BOOL):
 f=getattr(lib,name); f.argtypes=args; f.restype=ret; return f
wait=api(K,'WaitForSingleObject',[W.HANDLE,W.DWORD],W.DWORD)
exitcode=api(K,'GetExitCodeProcess',[W.HANDLE,C.POINTER(W.DWORD)])
terminate=api(K,'TerminateProcess',[W.HANDLE,W.UINT])
U32=C.WinDLL('user32',use_last_error=True)
EnumProc=C.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
enum_windows=api(U32,'EnumWindows',[EnumProc,W.LPARAM])
window_pid=api(U32,'GetWindowThreadProcessId',[W.HWND,C.POINTER(W.DWORD)],W.DWORD)
visible=api(U32,'IsWindowVisible',[W.HWND])
client_rect=api(U32,'GetClientRect',[W.HWND,C.POINTER(W.RECT)])
def windows_for_owned_pid(pid):
 rows=[]
 @EnumProc
 def collect(hwnd,_):
  owner=W.DWORD();window_pid(hwnd,C.byref(owner))
  if owner.value==pid and visible(hwnd):
   rect=W.RECT();ok=client_rect(hwnd,C.byref(rect))
   rows.append(dict(hwnd=int(hwnd),client=[rect.right-rect.left,rect.bottom-rect.top] if ok else None,query_error=0 if ok else C.get_last_error()))
  return True
 win.checked(enum_windows(collect,0));return rows
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
def host_ps(code):
 p=subprocess.run(['powershell','-NoProfile','-NonInteractive','-Command',"$ErrorActionPreference='Stop'; "+code],capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
 if p.returncode:raise RuntimeError('Host query failed: '+p.stderr)
 return json.loads(p.stdout or 'null')
def players():
 data=host_ps("@(Get-CimInstance Win32_Process -Filter \"name = 'Dungeon Lord.exe' OR name = 'PlayerWithTests.exe'\" | Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine) | ConvertTo-Json -Depth 4 -Compress")
 return [] if data is None else data if isinstance(data,list) else [data]
def owned_identity(handle,pid):
 times=[W.FILETIME() for _ in range(4)]; win.checked(win.get_times(handle,*[C.byref(t) for t in times]))
 image=C.create_unicode_buffer(32768); size=W.DWORD(len(image)); win.checked(win.query_image(handle,0,image,C.byref(size)))
 return dict(pid=pid,created=times[0].dwHighDateTime<<32|times[0].dwLowDateTime,executable=os.path.normcase(os.path.realpath(image.value)))
def state(h):
 x=wait(h,0)
 if x not in (0,258):raise RuntimeError('Unknown native wait '+str(x)+' error '+str(C.get_last_error()))
 code=W.DWORD();win.checked(exitcode(h,C.byref(code)));return dict(wait=x,exit_code=code.value,exited=x==0)
def sealed():
 seal=read(P/'05-build-artifact-manifest.json'); b=Path(seal['directory']); assert all(sha(b/x['path'])==x['sha256'] for x in seal['files']);return seal,b,b/'Dungeon Lord.exe'

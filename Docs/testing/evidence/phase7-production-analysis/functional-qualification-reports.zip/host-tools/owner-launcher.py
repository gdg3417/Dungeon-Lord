"""Host-bound PR249 owner acceptance launcher. No gameplay code or save authoring."""
from pathlib import Path
import sys,json,os,time,shutil,subprocess,threading,queue,uuid,hashlib,ctypes as C
import tkinter as tk
from tkinter import ttk,messagebox
import owner_support as d
BASE=Path(__file__).resolve().parent
MANIFEST=d.read(BASE/'owner-manifest.json')
DATA=d.DATA
ACTIVE=DATA/MANIFEST['compiled_save_filename']
OWNED_PROCESSES=[]

def write(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2)

def inventory(root):
 d.qi.no_redirect(root)
 return {p.relative_to(root).as_posix():d.sha(p) for p in root.rglob('*') if p.is_file() and not d.qi.no_redirect(p)}

def verify_package():
 for x in MANIFEST['build_files']:
  p=BASE/'Windows'/x['path'];d.qi.no_redirect(p)
  if d.sha(p)!=x['sha256']:raise RuntimeError('Qualified build hash mismatch: '+x['path'])
 for scenario in MANIFEST['scenarios']:
  for x in scenario['files']:
   if d.sha(BASE/x['path'])!=x['sha256']:raise RuntimeError('Fixture hash mismatch')
 if len(MANIFEST['build_files'])!=303:raise RuntimeError('Unexpected build inventory')

def begin_lease(data,session,fixture):
 assert not session.exists();session.mkdir(parents=True);d.qi.no_redirect(data)
 before=inventory(data);backup=session/'original-product';backup.mkdir()
 for rel,h in before.items():
  source=data/rel;dest=backup/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.open('xb').write(source.read_bytes());assert d.sha(dest)==h
 write(session/'product-before.json',before)
 # Lease only the compiled qualification namespace, preserving every original byte separately.
 for p in sorted(data.glob(ACTIVE.name+'*')):
  assert p.is_file();dest=session/'leased-originals'/p.name;dest.parent.mkdir(exist_ok=True);assert not dest.exists();shutil.move(str(p),str(dest))
 for p in sorted(fixture.glob(ACTIVE.name+'*')):
  d.qi.no_redirect(p);dest=data/p.name;assert not dest.exists();dest.open('xb').write(p.read_bytes());assert d.sha(dest)==d.sha(p)
 return before

def end_lease(data,session,before):
 current=inventory(data)
 for rel,h in current.items():
  allowed=Path(rel).parts[0]=='Unity' or Path(rel).name.startswith(ACTIVE.name)
  if (rel not in before or h!=before[rel]) and not allowed:raise RuntimeError('Unexpected product change; preservation review required: '+rel)
 for rel in before.keys()-current.keys():
  if Path(rel).parts[0]!='Unity' and not Path(rel).name.startswith(ACTIVE.name):raise RuntimeError('Unexpected missing product original: '+rel)
 after=session/'after-exit';after.mkdir();changes=[]
 for rel,h in current.items():
  if rel not in before or h!=before[rel] or Path(rel).name.startswith(ACTIVE.name):
   source=data/rel;dest=after/rel;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();shutil.move(str(source),str(dest));assert d.sha(dest)==h;changes.append(dict(path=rel,sha256=h))
 for rel,h in before.items():
  p=data/rel
  if not p.exists():
   original=session/'original-product'/rel;assert d.sha(original)==h;p.parent.mkdir(parents=True,exist_ok=True);p.open('xb').write(original.read_bytes())
 assert inventory(data)==before
 write(session/'product-restored.json',dict(original_files=len(before),exact_inventory_restored=True,archived_generated=changes))
 return after

def validate_post_exit(path):
 x=d.read(path)
 if x.get('schemaVersion')!=15 or not isinstance(x.get('primary'),dict):raise RuntimeError('Saved state is missing or has an unexpected schema; stop for Codex review')
 p=x['primary'];history=p.get('runHistory');spatial=p.get('spatialFloors');living=p.get('livingDungeon')
 if history is None or spatial is None or living is None:raise RuntimeError('Saved canonical authorities are missing; stop for Codex review')
 records=history.get('RecentOutcomes') or [];ids=[r['RunId'] for r in records if r is not None]
 if len(ids)!=len(set(ids)):raise RuntimeError('Duplicate retained run identity; stop for Codex review')
 return dict(schema=15,retained=len(records),run_ids=ids,next_sequence=history['NextRunSequence'])

def paired_draft_files():
 for p in DATA.glob(ACTIVE.name+'.editor-draft*.candidate'):
  if not p.with_suffix('.commit').exists():return False
 return True

def run_game(scenario,fixture,resolution,session,send):
 before=None;proc=None;h2=None;identity=None;forced=False;failure=None
 try:
  verify_package()
  if d.players():raise RuntimeError('Another game player is running. Close it normally before starting this isolated scenario.')
  before=begin_lease(DATA,session,fixture)
  args=[str(BASE/'Windows/Dungeon Lord.exe'),'-screen-fullscreen','0','-screen-width',str(resolution[0]),'-screen-height',str(resolution[1]),'-logFile',str(session/'player.log')]
  proc=subprocess.Popen(args,cwd=BASE/'Windows');OWNED_PROCESSES.append(proc);h1=int(proc._handle);h2=d.win.checked(d.win.open_process(0x1000|0x100000,False,proc.pid));identity=d.owned_identity(h1,proc.pid)
  assert identity==d.owned_identity(h2,proc.pid)
  cim=d.host_ps(f"Get-CimInstance Win32_Process -Filter 'ProcessId={proc.pid}' | Select-Object ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json")
  assert cim and cim['CommandLine']==subprocess.list2cmdline(args)
  write(session/'launch.json',dict(utc=d.utc(),identity=identity,arguments=args,executable_sha256=d.sha(BASE/'Windows/Dungeon Lord.exe'),launch_handle=h1,independent_handle=h2,cim=cim,scenario=scenario,qualified_source=MANIFEST['qualified_source']))
  send('Game running. Close its window normally when finished. This launcher handles verified exit and isolated save archiving.')
  quit_seen=None;started=time.monotonic()
  with (session/'process-observations.jsonl').open('x') as stream:
   while True:
    a,b=d.state(h1),d.state(h2)
    if a!=b:raise RuntimeError('Native handles disagree; process exit is unknown')
    windows=[] if a['exited'] else d.windows_for_owned_pid(proc.pid)
    stream.write(json.dumps(dict(utc=d.utc(),launch=a,independent=b,windows=windows))+'\n');stream.flush()
    if a['exited']:break
    if d.owned_identity(h1,proc.pid)!=identity or d.owned_identity(h2,proc.pid)!=identity:raise RuntimeError('Process identity uncertainty; no termination or save replacement permitted')
    log=(session/'player.log').read_text(errors='replace') if (session/'player.log').exists() else ''
    if 'Reason: AppQuit' in log and quit_seen is None:
     quit_seen=time.monotonic();send('AppQuit save succeeded. Waiting for verified Windows process exitâ€¦')
    if quit_seen and not windows and time.monotonic()-quit_seen>=30:
     if not paired_draft_files():raise RuntimeError('Incomplete draft receipt detected; no forced termination or successful snapshot permitted')
     write(session/'failed-graceful-exit.json',dict(utc=d.utc(),identity=identity,seconds_after_saved_appquit=time.monotonic()-quit_seen,classification='Known unresolved owner-reported Windows closure limitation; graceful shutdown failed'))
     send('Windows closure limitation recorded. Closing only this verified, saved campaign processâ€¦')
     d.win.checked(d.terminate(h1,0xE2490001));forced=True;assert d.wait(h1,20000)==0 and d.wait(h2,0)==0
    if not windows and not quit_seen and time.monotonic()-started>120:
     raise RuntimeError('No authoritative AppQuit save success. Leave the process for Codex review; no forced exit or snapshot is accepted.')
    time.sleep(1)
  a,b=d.state(h1),d.state(h2);assert a==b and a['exited'];code=proc.wait();d.win.close(h2);h2=None
  if d.players():raise RuntimeError('A surviving or overlapping player blocks all save reads and restoration')
  children=d.host_ps(f"@(Get-CimInstance Win32_Process -Filter 'ParentProcessId={proc.pid}' | Select-Object ProcessId,CreationDate,ExecutablePath) | ConvertTo-Json")
  if children:raise RuntimeError('Surviving child process requires Codex review')
  write(session/'exit.json',dict(utc=d.utc(),actual_exit_code=code,normal=not forced,failed_graceful_exit=forced,launch_handle=a,independent_handle=b,no_children=True))
  # Read only after actual native exit. The game's canonical writer and normal load retain authority.
  summary=validate_post_exit(ACTIVE)
  after=end_lease(DATA,session,before);before=None
  write(session/'saved-state-summary.json',summary)
  send('Saved and archived: '+str(summary['retained'])+' retained runs. '+('Graceful exit failed under the documented Windows limitation.' if forced else 'Normal Windows exit confirmed.'))
  return after
 except Exception as error:
  failure=str(error)
  if session.exists() and not (session/'blocked.json').exists():write(session/'blocked.json',dict(utc=d.utc(),error=failure,pid=proc.pid if proc is not None else None,identity=identity,status='Stop for Codex review; not a UAT pass; original backups retained'))
  # Fail closed. Never kill or replace a save to bypass an incomplete save or uncertain process.
  if before is not None and (proc is None or d.state(int(proc._handle))['exited']):
   if not d.players():end_lease(DATA,session,before)
  raise
 finally:
  if h2:d.win.close(h2)

def self_check():
 verify_package()
 root=BASE/'LauncherSelfcheck';assert not root.exists();root.mkdir();data=root/'isolated-product';data.mkdir();(data/ACTIVE.name).write_bytes(b'original-owner-bytes');(data/'Unity').mkdir();(data/'Unity/old-cache').write_bytes(b'original-cache');(data/'unrelated-owner-file').write_bytes(b'keep-me')
 fixture=root/'fixture';fixture.mkdir();(fixture/ACTIVE.name).write_bytes(b'detached-fixture');session=root/'session';before=begin_lease(data,session,fixture)
 (data/ACTIVE.name).write_bytes(b'normal-authority-output');(data/'Unity/old-cache').rename(root/'simulated-pruned-cache');(data/'Unity/new-cache').write_bytes(b'new-cache')
 after=end_lease(data,session,before);assert inventory(data)==before and (after/ACTIVE.name).read_bytes()==b'normal-authority-output'
 # Non-game owned-process check: live, then real exit code 23 through both handles.
 child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(1);raise SystemExit(23)'],creationflags=subprocess.CREATE_NO_WINDOW);h1=int(child._handle);h2=d.win.checked(d.win.open_process(0x1000|0x100000,False,child.pid));identity=d.owned_identity(h1,child.pid);assert identity==d.owned_identity(h2,child.pid) and not d.state(h1)['exited'];assert d.wait(h1,5000)==0 and d.wait(h2,0)==0;assert d.state(h1)==d.state(h2) and d.state(h1)['exit_code']==23;child.wait();d.win.close(h2)
 write(root/'verdict.json',dict(passed=True,unchanged_build_files=303,fixtures=len(MANIFEST['scenarios']),lease_restoration=True,generated_outputs_retained=True,unrelated_owner_sentinel_unchanged=True,two_handle_child_exit_code=23,no_game_launched=True))
 print('PASS owner launcher package, fixture hashes, preservation dry run and native handle exit-23 self-check')

if '--self-check' in sys.argv:
 self_check();raise SystemExit(0)

root=tk.Tk();root.title('PR #249 â€” Isolated Analysis UAT');root.geometry('760x590');root.minsize(660,530)
style=ttk.Style();style.configure('.',font=('Segoe UI',12));frame=ttk.Frame(root,padding=18);frame.pack(fill='both',expand=True)
ttk.Label(frame,text='Dungeon Lord â€” Analysis owner acceptance',font=('Segoe UI',17,'bold')).pack(anchor='w')
ttk.Label(frame,text='Qualified isolated Development build â€¢ PR remains draft and unmerged',wraplength=700).pack(anchor='w',pady=(5,15))
labels=[x['label'] for x in MANIFEST['scenarios']];scenario=tk.StringVar(value=labels[0]);ttk.Label(frame,text='Scenario').pack(anchor='w');combo=ttk.Combobox(frame,textvariable=scenario,values=labels,state='readonly',width=47);combo.pack(anchor='w',pady=(4,12))
view=tk.StringVar(value='Desktop 1280Ã—720');sizes={'Desktop 1280Ã—720':(1280,720),'Portrait 360Ã—640':(360,640),'Phone landscape 640Ã—360':(640,360)}
ttk.Label(frame,text='Window size').pack(anchor='w')
for label in sizes:ttk.Radiobutton(frame,text=label,variable=view,value=label).pack(anchor='w',pady=2)
buttons=ttk.Frame(frame);buttons.pack(fill='x',pady=15)
status=tk.StringVar(value='Ready. Choose a scenario, then Start fresh. Use Reopen last after closing a game.');ttk.Label(frame,textvariable=status,wraplength=700,justify='left').pack(anchor='w',fill='x',pady=6)
ttk.Label(frame,text='Close through the game window. This launcher verifies actual exit, archives the isolated save and restores the original namespace. A saved AppQuit hang is recorded as failed graceful shutdown before controlled termination. No owner UAT pass is claimed automatically.',wraplength=700,justify='left').pack(anchor='w',pady=10)
messages=queue.Queue();busy=False;fatal=False
last_file=BASE/'last-sessions.json';last=d.read(last_file) if last_file.exists() else {}

def send(message):messages.put(('status',message))
def launch(reopen=False):
 global busy
 if busy or fatal:return
 label=scenario.get();item=next(x for x in MANIFEST['scenarios'] if x['label']==label);fixture=Path(last[label]) if reopen and label in last else BASE/item['folder']
 if reopen and label not in last:messagebox.showinfo('No previous session','Start this scenario once before reopening it.');return
 session=BASE/'Sessions'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);resolution=sizes[view.get()];busy=True;fresh.configure(state='disabled');again.configure(state='disabled');send('Checking sealed artifact and preparing an exclusive isolated fixtureâ€¦')
 def worker():
  try:after=run_game(label,fixture,resolution,session,send);messages.put(('done',(label,str(after))))
  except Exception as error:messages.put(('error',str(error)))
 threading.Thread(target=worker,daemon=False).start()
fresh=ttk.Button(buttons,text='Start fresh scenario',command=lambda:launch(False));fresh.pack(side='left',padx=(0,10));again=ttk.Button(buttons,text='Reopen last saved session',command=lambda:launch(True));again.pack(side='left')

def poll():
 global busy,fatal
 try:
  while True:
   kind,value=messages.get_nowait()
   if kind=='status':status.set(value)
   elif kind=='done':
    label,folder=value;last[label]=folder;temp=BASE/'last-sessions.next.json';temp.write_text(json.dumps(last,indent=2));os.replace(temp,last_file);busy=False;fresh.configure(state='normal');again.configure(state='normal')
   elif kind=='error':fatal=True;busy=False;status.set('STOP â€” Codex review required: '+value);messagebox.showerror('Qualification blocked',value)
 except queue.Empty:pass
 root.after(250,poll)
def close():
 if busy or any(not d.state(int(p._handle))['exited'] for p in OWNED_PROCESSES):messagebox.showinfo('Game session active','Close the game window and wait for this launcher to confirm saved state and actual exit first.');return
 root.destroy()
root.protocol('WM_DELETE_WINDOW',close);poll();root.mainloop()

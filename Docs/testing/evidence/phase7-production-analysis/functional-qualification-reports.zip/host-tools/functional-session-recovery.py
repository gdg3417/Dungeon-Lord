"""PR249 D1 bounded host-native diagnostic only; no Unity input changes."""
from pathlib import Path
import ctypes as C
from ctypes import wintypes as W
import json,sys,subprocess,time,datetime,hashlib,os,shutil
R=Path('C:/Dev/Dungeon-Lord'); O=R/'TestResults/phase7-analysis-functional-20261023-f1'; P=R/'TestResults/phase7-analysis-recovery-20261022-r2'
sys.path.insert(0,str(R/'Tools/Presentation')); import qualification_windows as win; import qualification_inputs as qi
DATA=Path('C:/Users/gdg34/AppData/LocalLow/gdg3417/DL B3B2 Smoke Two Floor P249R2')
ACTIVE=DATA/'living-dungeon-b3b2-qualification-two-floor-p249r2-native.json'
K=C.WinDLL('kernel32',use_last_error=True)
def api(lib,name,args,ret=W.BOOL):
 f=getattr(lib,name); f.argtypes=args; f.restype=ret; return f
wait=api(K,'WaitForSingleObject',[W.HANDLE,W.DWORD],W.DWORD)
exitcode=api(K,'GetExitCodeProcess',[W.HANDLE,C.POINTER(W.DWORD)])
terminate=api(K,'TerminateProcess',[W.HANDLE,W.UINT])
U32=C.WinDLL('user32',use_last_error=True)
EnumProc=C.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
enum_windows=api(U32,'EnumWindows',[EnumProc,W.LPARAM])
window_pid=api(U32,'GetWindowThreadProcessId',[W.HWND,C.POINTER(W.DWORD)],W.DWORD)
visible=api(U32,'IsWindowVisible',[W.HWND])
client_rect=api(U32,'GetClientRect',[W.HWND,C.POINTER(W.RECT)])
def windows_for_owned_pid(pid):
 rows=[]
 @EnumProc
 def collect(hwnd,_):
  owner=W.DWORD();window_pid(hwnd,C.byref(owner))
  if owner.value==pid and visible(hwnd):
   rect=W.RECT();ok=client_rect(hwnd,C.byref(rect))
   rows.append(dict(hwnd=int(hwnd),client=[rect.right-rect.left,rect.bottom-rect.top] if ok else None,query_error=0 if ok else C.get_last_error()))
  return True
 win.checked(enum_windows(collect,0));return rows
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
def host_ps(code):
 p=subprocess.run(['powershell','-NoProfile','-NonInteractive','-Command',"$ErrorActionPreference='Stop'; "+code],capture_output=True,text=True,timeout=30)
 if p.returncode:raise RuntimeError('Host query failed: '+p.stderr)
 return json.loads(p.stdout or 'null')
def players():
 data=host_ps("@(Get-CimInstance Win32_Process -Filter \"name = 'Dungeon Lord.exe' OR name = 'PlayerWithTests.exe'\" | Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine) | ConvertTo-Json -Depth 4 -Compress")
 return [] if data is None else data if isinstance(data,list) else [data]
def owned_identity(handle,pid):
 times=[W.FILETIME() for _ in range(4)]; win.checked(win.get_times(handle,*[C.byref(t) for t in times]))
 image=C.create_unicode_buffer(32768); size=W.DWORD(len(image)); win.checked(win.query_image(handle,0,image,C.byref(size)))
 return dict(pid=pid,created=times[0].dwHighDateTime<<32|times[0].dwLowDateTime,executable=os.path.normcase(os.path.realpath(image.value)))
def state(h):
 x=wait(h,0)
 if x not in (0,258):raise RuntimeError('Unknown native wait '+str(x)+' error '+str(C.get_last_error()))
 code=W.DWORD();win.checked(exitcode(h,C.byref(code)));return dict(wait=x,exit_code=code.value,exited=x==0)
def sealed():
 seal=read(P/'05-build-artifact-manifest.json'); b=Path(seal['directory']); assert all(sha(b/x['path'])==x['sha256'] for x in seal['files']);return seal,b,b/'Dungeon Lord.exe'
def wct(threads):
 A=C.WinDLL('advapi32',use_last_error=True)
 class Lock(C.Structure):_fields_=[('name',W.WCHAR*128),('timeout',C.c_longlong),('alertable',W.BOOL)]
 class Thread(C.Structure):_fields_=[('pid',W.DWORD),('tid',W.DWORD),('waitms',W.DWORD),('switches',W.DWORD)]
 class U(C.Union):_fields_=[('lock',Lock),('thread',Thread)]
 class Node(C.Structure):_fields_=[('type',C.c_int),('status',C.c_int),('u',U)]
 op=api(A,'OpenThreadWaitChainSession',[W.DWORD,W.LPVOID],W.HANDLE);cl=api(A,'CloseThreadWaitChainSession',[W.HANDLE],None)
 get=api(A,'GetThreadWaitChain',[W.HANDLE,C.c_size_t,W.DWORD,W.DWORD,C.POINTER(W.DWORD),C.POINTER(Node),C.POINTER(W.BOOL)])
 h=op(0,None)
 if not h:return dict(error=C.get_last_error())
 rows=[]
 try:
  for tid in threads:
   n=W.DWORD(16); nodes=(Node*16)(); cyc=W.BOOL()
   ok=get(h,0,0,int(tid),C.byref(n),nodes,C.byref(cyc)); row=dict(tid=tid,ok=bool(ok),error=0 if ok else C.get_last_error(),cycle=bool(cyc.value),nodes=[])
   if ok:
    for node in nodes[:min(n.value,16)]:
     v=dict(type=node.type,status=node.status)
     if node.type==8:v.update(pid=node.u.thread.pid,tid=node.u.thread.tid,wait_ms=node.u.thread.waitms,context_switches=node.u.thread.switches)
     else:v['object_name']=node.u.lock.name
     row['nodes'].append(v)
   rows.append(row)
 finally:cl(h)
 return rows
def detail(pid,folder,label):
 code=f"$p=Get-Process -Id {pid}; $ts=@($p.Threads | ForEach-Object {{ $w=$null; if($_.ThreadState -eq 'Wait') {{$w=$_.WaitReason.ToString()}}; [pscustomobject]@{{id=$_.Id;state=$_.ThreadState.ToString();waitReason=$w;cpuTicks=$_.TotalProcessorTime.Ticks;startAddress=$_.StartAddress.ToInt64()}} }}); [pscustomobject]@{{pid=$p.Id;hasExited=$p.HasExited;cpu=$p.CPU;window=$p.MainWindowHandle.ToInt64();threads=$ts;modules=@($p.Modules | Select-Object ModuleName,FileName,BaseAddress,ModuleMemorySize)}} | ConvertTo-Json -Depth 7 -Compress"
 result=host_ps(code); result['wct']=wct([t['id'] for t in result['threads']]); write(folder/(label+'.json'),result);return result
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='detail':
  detail(int(sys.argv[2]),Path(sys.argv[3]),sys.argv[4])
 elif mode=='host-preflight':
  old={}
  for pid in [38808,39392,7384,44508,27080]:old[str(pid)]=win.identity(pid)
  assert not any(old.values()),'Prior PID still live or reused; inspect identity'
  running=players();assert not running,running
  write(O/'host-preflight.json',dict(utc=utc(),prior_pids=old,player_inventory=running,identity_method='OpenProcess + native signaled state; access/query errors raise unknown'))
  print('HOST PREFLIGHT PASS: prior PIDs absent/exited; no existing players')
 elif mode=='run':
  label,kind=sys.argv[2:4]; assert kind in ['visible','scripted']; assert (O/'preflight.json').exists() and (O/'host-preflight.json').exists()
  folder=O/label;assert not folder.exists();folder.mkdir();assert not players(),'Any existing player blocks launch'
  seal,build,exe=sealed(); lease=[]
  if kind=='visible':
   seed=Path(sys.argv[6]) if len(sys.argv)>6 else P/'08-native-finish-post-exit.save.json'; backup=folder/'leased-originals';backup.mkdir()
   # Temporarily lease only the existing qualification namespace. Restore exact bytes after verified exit.
   for p in sorted(DATA.glob(ACTIVE.name+'*')):
    qi.no_redirect(p); dest=backup/p.name;assert not dest.exists();digest=sha(p);shutil.move(str(p),str(dest));assert sha(dest)==digest;lease.append(dict(original=str(p),backup=str(dest),sha256=digest))
   write(folder/'lease.json',lease);ACTIVE.open('xb').write(seed.read_bytes());save=ACTIVE
   args=[str(exe),'-screen-fullscreen','0','-screen-width',sys.argv[4],'-screen-height',sys.argv[5],'-logFile',str(folder/'player.log')]
  else:
   sources=sorted((R/'Temp/ui-composition-analysis-p249r2-edit/TestResults/living-dungeon-two-floor-20261020/inputs').glob('two-floor-*.manifest.json'))
   m=read(sources[-1]);seed=Path(m['SeedPath']);assert sha(seed)==m['SeedSha256'];save=DATA/'living-dungeon-b3b2-qualification-two-floor-p249d2-visiblequit01.json';assert not save.exists();save.open('xb').write(seed.read_bytes())
   fresh=folder/'seed.json';fresh.open('xb').write(seed.read_bytes());m.update(SeedPath=str(fresh),SeedSha256=sha(fresh),SaveFileName=save.name);write(folder/'seed.manifest.json',m)
   args=[str(exe),'-screen-width',sys.argv[4],'-screen-height',sys.argv[5],'-logFile',str(folder/'player.log'),'-b3b2ForegroundSmoke','two-floor-wait',str(folder/'smoke.json'),str(folder/'seed.manifest.json')]
  assert len(str(save)+'.editor-draft.draft-'+'0'*32+'.000000.candidate')<=240
  write(folder/'fixture.json',dict(source=str(seed),sha256=sha(seed),active=str(save),kind=kind,isolated_lease=lease))
  if len(sys.argv)>7:
   sidecars=[]
   for source in sorted(Path(sys.argv[7]).glob(save.name+'.editor-draft*')):
    qi.no_redirect(source);dest=DATA/source.name;assert not dest.exists();dest.open('xb').write(source.read_bytes());assert sha(dest)==sha(source);sidecars.append(dict(source=str(source),destination=str(dest),sha256=sha(source)))
   assert sidecars;write(folder/'sidecar-inputs.json',sidecars)
  # Process launch and both handles remain owned by this monitor until the terminal record.
  startup=None
  if False:startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=subprocess.SW_HIDE
  proc=subprocess.Popen(args,cwd=build,startupinfo=startup);h1=int(proc._handle)
  try:
   h2=win.checked(win.open_process(0x1000|0x100000,False,proc.pid));ident=owned_identity(h1,proc.pid);assert owned_identity(h2,proc.pid)==ident
   assert Path(ident['executable'])==Path(os.path.normcase(str(exe.resolve())))
   cim=host_ps(f"Get-CimInstance Win32_Process -Filter 'ProcessId = {proc.pid}' | Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 4 -Compress")
   assert cim and Path(cim['ExecutablePath']).resolve()==exe.resolve() and cim['ProcessId']==proc.pid
   assert cim['CommandLine']==subprocess.list2cmdline(args),'Host command line differs from exact launch arguments'
  except Exception as ex:
   write(folder/'launch-identity-unknown.json',dict(utc=utc(),pid=proc.pid,handle=h1,error=repr(ex),status='unknown, qualification blocked'))
   # The actual CreateProcess handle is ours even if a query fails. Never kill by PID.
   if not state(h1)['exited']:win.checked(terminate(h1,0xE2490003));assert wait(h1,20000)==0
   raise
  write(folder/'launch.json',dict(utc=utc(),monitor_pid=os.getpid(),pid=proc.pid,creation=ident,launch_process_handle=h1,independent_open_handle=h2,cim=cim,arguments=args,executable_sha256=sha(exe),source=seal['source'],artifact_id=seal['artifact_id'],script_sha256=sha(Path(__file__)),bounds=dict(total_seconds=3600,after_appquit_seconds=30)))
  print('LAUNCHED',label,proc.pid,flush=True); start=time.monotonic();quit_seen=None; forced=False;error=None;detail_at=set()
  try:
   with (folder/'observations.jsonl').open('x',encoding='utf-8') as stream:
    while True:
     a,b=state(h1),state(h2);assert a==b,'Independent native handles disagree'
     row=dict(utc=utc(),seconds=time.monotonic()-start,launch_handle=a,independent_handle=b,visible_owned_windows=[] if a['exited'] else windows_for_owned_pid(proc.pid))
     stream.write(json.dumps(row)+'\n');stream.flush()
     if a['exited']:break
     assert owned_identity(h1,proc.pid)==ident and owned_identity(h2,proc.pid)==ident
     text=(folder/'player.log').read_text(errors='replace') if (folder/'player.log').exists() else ''
     if 'Reason: AppQuit' in text and quit_seen is None:quit_seen=time.monotonic();write(folder/'appquit-observed.json',dict(utc=utc(),seconds=quit_seen-start,native_state=a))
     elapsed=time.monotonic()-(quit_seen or start)
     if quit_seen and elapsed>=30:
      assert not windows_for_owned_pid(proc.pid),'Visible window remains; close incomplete'
      write(folder/'unsuccessful-graceful-exit.json',dict(utc=utc(),state=a,elapsed_since_appquit=elapsed,identity=ident,classification='Failed graceful exit under owner-reported pre-existing limitation; canonical AppQuit success marker required'))
      assert owned_identity(h1,proc.pid)==ident and owned_identity(h2,proc.pid)==ident
      win.checked(terminate(h1,0xE2490001));forced=True;assert wait(h1,20000)==0 and wait(h2,0)==0;break
     if time.monotonic()-start>=3600:raise RuntimeError('Functional session deadline; save/close incomplete')
     time.sleep(1)
  except Exception as ex:
   error=repr(ex);write(folder/'monitor-error.json',dict(error=error,utc=utc(),status='unknown, never accepted as exit'))
   if quit_seen and state(h1)['exited']==False and owned_identity(h1,proc.pid)==ident:
    win.checked(terminate(h1,0xE2490002));forced=True;assert wait(h1,20000)==0
  a,b=state(h1),state(h2);assert a['exited'] and b['exited'] and a==b
  rc=proc.wait(timeout=1);assert rc==a['exit_code'];win.close(h2)
  children=host_ps(f"@(Get-CimInstance Win32_Process -Filter 'ParentProcessId = {proc.pid}' | Select-Object ProcessId,CreationDate,ExecutablePath,CommandLine) | ConvertTo-Json -Depth 4 -Compress")
  assert children is None or children==[], 'Surviving child identity requires review'
  write(folder/'exit.json',dict(utc=utc(),normal=not forced and error is None,forced=forced,error=error,exit_code=rc,launch_handle_state=a,independent_handle_state=b,wall_seconds=time.monotonic()-start,appquit_seen=quit_seen is not None,surviving_children=children))
  assert not players(),'A surviving player blocks save access and restoration'
  after=folder/'after-verified-exit';after.mkdir()
  for p in sorted(DATA.glob(save.name+'*')):
   qi.no_redirect(p);dest=after/p.name;dest.open('xb').write(p.read_bytes());assert sha(dest)==sha(p)
   # Move only fresh diagnostic output away from leased namespace, never overwrite originals.
   moved=after/('moved-'+p.name);assert not moved.exists();shutil.move(str(p),str(moved))
  for r in lease:
   p=Path(r['original']);bk=Path(r['backup']);assert not p.exists() and sha(bk)==r['sha256'];p.open('xb').write(bk.read_bytes());assert sha(p)==r['sha256']
  write(folder/'fixture-closed.json',dict(utc=utc(),save_snapshot_after_both_handles_signaled=True,original_namespace_restored=lease,graceful_exit=not forced and error is None))
  print(json.dumps(read(folder/'exit.json')),flush=True)

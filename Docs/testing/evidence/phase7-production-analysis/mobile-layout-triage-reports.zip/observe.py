from pathlib import Path
import sys,hashlib,json
R=Path('C:/Dev/Dungeon-Lord');P=R/'Temp/pr249-analysis-owner-f1';O=R/'TestResults/phase7-analysis-mobile-triage-20261024'
sys.path.insert(0,str(P));src=P/'launcher.py';ns={'__file__':str(src),'__name__':'triage_host'}
exec(compile(src.read_text().split("if '--self-check' in sys.argv:")[0],str(src),'exec'),ns)
ns['verify_package']();assert not ns['d'].players()
label=sys.argv[1];res=tuple(map(int,sys.argv[2:4]));fixture=P/'Fixtures/scenario-1'
ns['run_game']('Codex bounded layout observation; not owner acceptance',fixture,res,O/label,lambda x:print(x,flush=True))

$ErrorActionPreference = 'Stop'
$campaign = 'C:/Dev/Dungeon-Lord/TestResults/phase7-analysis-final-20261023-01'
if (Test-Path "$campaign/01-full-edit.xml") { throw 'Preserve existing report' }
$started = [DateTime]::UtcNow.ToString('o')
& 'C:/Users/gdg34/AppData/Local/Unity/bin/unity.exe' test C:/Dev/Dungeon-Lord/Temp/ui-composition-analysis-final-20261022-01 --mode EditMode --output "$campaign/01-full-edit.xml" --timeout 10800 --format json --no-color -- -logFile "$campaign/01-full-edit.log" > "$campaign/01-full-edit-command.json"
$code = $LASTEXITCODE
@{ source = 'd4071924993c67f2b22722a539be37eea781017e'; implementation = '948a38dc6f47b1419164fdfe8f44a2b3c9fd31f5'; startedUtc = $started; finishedUtc = [DateTime]::UtcNow.ToString('o'); exitCode = $code; timeoutSeconds = 10800; selection = 'complete EditMode suite; no filter or exclusions' } | ConvertTo-Json | Set-Content "$campaign/01-full-edit-exit.json"
exit $code

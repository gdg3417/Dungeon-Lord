from pathlib import Path
import sys, json, hashlib, shutil, xml.etree.ElementTree as ET, datetime
ROOT=Path('C:/Dev/Dungeon-Lord'); OUT=ROOT/'TestResults/phase7-analysis-final-20261023-01'
sys.path.insert(0,str(ROOT/'Tools/Presentation'))
import qualification_inputs as q
q.NAMESPACE='p7-analysis-final-20261022-01.json'
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,d):
    with (OUT/n).open('x',encoding='utf-8') as f: json.dump(d,f,indent=2)
r=ET.parse(OUT/'01-full-edit.xml').getroot(); cases=list(r.iter('test-case'))
assert len(cases)==int(r.get('total'))==int(r.get('testcasecount'))
assert len({c.get('id') for c in cases})==len(cases)
write('01-report-summary.json',dict(source='d4071924993c67f2b22722a539be37eea781017e',root=r.attrib,unique_leaf_ids=len(cases),report_sha256=sha(OUT/'01-full-edit.xml'),failures=[dict(name=c.get('fullname'),message=c.findtext('failure/message'),stack=c.findtext('failure/stack-trace')) for c in cases if c.get('result')=='Failed'],skips=[dict(name=c.get('fullname'),reason=c.findtext('reason/message')) for c in cases if c.get('result') in ('Skipped','Inconclusive')],analysis_cases=[dict(name=c.get('fullname'),result=c.get('result')) for c in cases if 'Analysis' in c.get('fullname','')],bounded_performance=[dict(name=c.get('fullname'),result=c.get('result'),output=c.findtext('output')) for c in cases if any(k in c.get('fullname','') for k in ['ActiveIdleFrames','FramesBeforeCached','CompositionLayoutsAndPresentationWork'])]))
before=json.loads((OUT/'protected-before.json').read_text()); protected=[]
for row in before:
    p=Path(row['path']); h=sha(p) if p.exists() else None
    protected.append(dict(path=str(p),before=row['sha256'],after=h,equal=h==row['sha256']))
    if h!=row['sha256'] and p.exists():
        dest=OUT/'protected-generated-after'/p.name; dest.parent.mkdir(exist_ok=True); shutil.copyfile(p,dest)
base=Path(before[0]['path']).parent; expected={r['path'] for r in before}
extra=[str(p) for p in base.rglob('*') if p.is_file() and str(p) not in expected]
write('protected-after-before-restoration.json',dict(files=protected,extra=extra))
inputs=q.compare(ROOT,'ui-composition-analysis-final-20261022-01'); write('inputs-after-before-restoration.json',inputs)
target=Path(inputs['validation_directory'])
for row in inputs['files']:
    if not row['equal'] and (target/row['path']).exists():
        dest=OUT/'generated-inputs-after'/row['path']; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(target/row['path'],dest)
history=json.loads((OUT/'historical-before.json').read_text()); failures=[]
for row in history:
    p=Path(row['path']); h=sha(p) if p.exists() else None
    if h!=row['sha256']: failures.append(dict(path=str(p),before=row['sha256'],after=h))
write('historical-after.json',dict(files=len(history),failures=failures,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print(json.dumps(dict(protected_changes=[r for r in protected if not r['equal']],protected_extras=extra,input_failures=inputs['failures'],historical_checked=len(history),historical_failures=failures)))

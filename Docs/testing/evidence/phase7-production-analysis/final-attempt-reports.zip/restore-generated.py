from pathlib import Path
import json, hashlib, shutil, sys
ROOT=Path('C:/Dev/Dungeon-Lord'); OUT=ROOT/'TestResults/phase7-analysis-final-20261023-01'
sys.path.insert(0,str(ROOT/'Tools/Presentation'))
import qualification_inputs as q
q.NAMESPACE='p7-analysis-final-20261022-01.json'
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,d):
    with (OUT/n).open('x',encoding='utf-8') as f: json.dump(d,f,indent=2)
before=json.loads((OUT/'protected-before.json').read_text()); after=json.loads((OUT/'protected-after-before-restoration.json').read_text())
base=Path('C:/Users/gdg34/AppData/LocalLow/gdg3417/Dungeon Lord').resolve()
changes=[r for r in after['files'] if not r['equal']]
assert len(changes)==1 and Path(changes[0]['path'])==base/'TestResults.xml'
report=next(r for r in before if Path(r['path'])==base/'TestResults.xml')
assert sha(Path(report['backup']))==report['sha256']
assert sha(base/'TestResults.xml')==changes[0]['after']
assert sha(OUT/'protected-generated-after/TestResults.xml')==changes[0]['after']
inputs=json.loads((OUT/'inputs-after-before-restoration.json').read_text()); target=Path(inputs['validation_directory'])
changed=[r for r in inputs['files'] if not r['equal']]
assert [r['path'] for r in changed]==['Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Fallback.asset']
for r in changed:
    assert sha(ROOT/r['path'])==r['source_sha256']
    assert sha(target/r['path'])==sha(OUT/'generated-inputs-after'/r['path'])
manifests=[(p,json.loads(p.read_text())) for p in (target/'TestResults/living-dungeon-two-floor-20261020/inputs').glob('*.manifest.json')]
moves=[]
for extra in after['extra']:
    src=Path(extra).resolve(); q.no_redirect(src)
    assert src.parent==base and extra not in {r['path'] for r in before}
    matches=[(p,d) for p,d in manifests if d.get('SaveFileName')==src.name]
    assert len(matches)==1
    dest=(OUT/'generated-qualification-saves'/src.name).resolve(); q.no_redirect(dest)
    assert dest.is_relative_to(OUT.resolve()) and not dest.exists()
    moves.append(dict(source=str(src),destination=str(dest),sha256=sha(src),manifest=str(matches[0][0])))
write('restoration-provenance.json',dict(default_report=report,generated_report_sha256=changes[0]['after'],font=[r['path'] for r in changed],moves=moves))
for row in moves:
    dest=Path(row['destination']); dest.parent.mkdir(exist_ok=True)
    shutil.move(row['source'],dest)
    assert sha(dest)==row['sha256'] and not Path(row['source']).exists()
shutil.copyfile(report['backup'],base/'TestResults.xml')
for row in changed: shutil.copyfile(ROOT/row['path'],target/row['path'])
assert all(sha(Path(r['path']))==r['sha256'] for r in before)
assert {str(p) for p in base.rglob('*') if p.is_file()}=={r['path'] for r in before}
result=q.compare(ROOT,target.name); assert not result['failures']
write('inputs-after-restoration.json',result)
write('protected-final.json',dict(protected=len(before),all_byte_identical=True,extra_files=[],generated_saves_archived=len(moves),save_or_recovery_restored=False,default_report_restored=True,inputs=result['expected_count'],input_failures=result['failures']))
print(json.dumps(dict(protected=len(before),all_byte_identical=True,generated_saves_archived=len(moves),inputs=result['expected_count'])))

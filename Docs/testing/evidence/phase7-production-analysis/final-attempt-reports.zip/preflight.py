from pathlib import Path
import sys, json, hashlib, shutil, subprocess, datetime
ROOT=Path('C:/Dev/Dungeon-Lord')
OUT=ROOT/'TestResults/phase7-analysis-final-20261023-01'
sys.path.insert(0,str(ROOT/'Tools/Presentation'))
import qualification_inputs as q
q.NAMESPACE='p7-analysis-final-20261022-01.json'
NAME='ui-composition-analysis-final-20261022-01'
def sha(p): return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def write(name,value):
    with (OUT/name).open('x',encoding='utf-8') as f: json.dump(value,f,indent=2)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='d4071924993c67f2b22722a539be37eea781017e'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
protected=Path('C:/Users/gdg34/AppData/LocalLow/gdg3417/Dungeon Lord')
rows=[]
for p in sorted(protected.rglob('*')):
    q.no_redirect(p)
    if p.is_file():
        dest=OUT/'protected-before-files'/p.relative_to(protected)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dest)
        h=sha(p)
        assert sha(dest)==h
        rows.append(dict(path=str(p),sha256=h,bytes=p.stat().st_size,backup=str(dest)))
write('protected-before.json',rows)
history=[]
for base in ['Builds','TestResults','Docs/testing/evidence']:
    for p in sorted((ROOT/base).rglob('*')):
        if p.is_relative_to(OUT): continue
        q.no_redirect(p)
        if p.is_file(): history.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
write('historical-before.json',history)
assert not (ROOT/'Temp'/NAME).exists()
inputs=q.prepare(ROOT,NAME)
write('inputs-before.json',inputs)
write('preflight.json',dict(source='d4071924993c67f2b22722a539be37eea781017e',implementation='948a38dc6f47b1419164fdfe8f44a2b3c9fd31f5',main='fbe4bdff0cba9fea72b42fb6a05714327f880df4',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),protected=len(rows),historical=len(history),inputs=inputs['expected_count'],namespace=q.NAMESPACE,disposable=NAME,default_report_backup=next((r for r in rows if Path(r['path']).name=='TestResults.xml'),None)))
print(json.dumps(dict(protected=len(rows),historical=len(history),inputs=inputs['expected_count'],failures=inputs['failures'])))

import sys,subprocess,json,time
from pathlib import Path
sys.path.insert(0,'C:/Dev/Dungeon-Lord/TestResults/phase7-analysis-shutdown-20261023-d1');import diagnose as d
p=subprocess.Popen([sys.executable,'-c','import time,sys;time.sleep(1);sys.exit(23)']);h1=int(p._handle);h2=d.win.checked(d.win.open_process(0x1000|0x100000,False,p.pid));a=d.owned_identity(h1,p.pid);b=d.owned_identity(h2,p.pid);assert a==b
live1=d.state(h1);live2=d.state(h2);assert live1==live2 and not live1['exited'];assert d.wait(h1,10000)==0
end1=d.state(h1);end2=d.state(h2);assert end1==end2 and end1['exited'] and end1['exit_code']==23 and p.wait()==23
try:d.state(0)
except Exception as e:invalid=repr(e)
else:raise AssertionError('Invalid handle accepted')
d.win.close(h2)
d.write(d.O/'monitor-self-check.json',dict(identity_equal=a==b,live_launch=live1,live_independent=live2,exited_launch=end1,exited_independent=end2,invalid_handle_result=invalid,verdict='Passed process-observation self-check; not a Unity test'))
print('Two-handle monitor self-check passed; actual child exit=23; invalid handle raises unknown')

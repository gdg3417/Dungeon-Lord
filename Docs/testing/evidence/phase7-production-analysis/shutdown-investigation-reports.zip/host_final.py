import diagnose as d
pids=[38808,39392,7384,44508,27080];states={str(x):d.win.identity(x) for x in pids};assert not any(states.values()),states
running=d.players();assert not running,running
for label in ['01-scripted','02-visible','03-visible-no-capture']:
 f=d.O/label;assert (f/'exit.json').exists() and (f/'fixture-closed.json').exists()
 for row in d.read(f/'fixture-closed.json')['original_namespace_restored']:
  assert d.sha(row['original'])==row['sha256']
d.write(d.O/'host-final.json',dict(utc=d.utc(),process_states=states,active_players=running,all_fixture_leases_restored=True,method='Existing qualification_windows.identity: native process handle, executable and creation time; signaled or absent is exited; access errors raise'))
print('HOST FINAL PASS: all recorded player processes exited, no active players, fixture leases restored')

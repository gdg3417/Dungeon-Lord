import diagnose as d
names=d.qi.source_inventory(d.R); stages=[]
for st in ['focused','edit','play','native','nativefs']:
 p=d.R/'Temp'/('ui-composition-analysis-p249r2-'+st);assert d.qi.target_inventory(p)==set(names)
 assert all(d.sha(d.R/n)==d.sha(p/n) for n in names)
 stages.append(dict(stage=st,exact_original_inputs=len(names)))
seal,build,exe=d.sealed()
d.write(d.O/'final-source-build.json',dict(source='c870c5dc92aee87e854af350aa0a73653d045ff2',stages=stages,sealed_files=len(seal['files']),artifact=seal['artifact_id'],executable_sha256=d.sha(exe),unity_source_changes=False,build_repeated=False))
d.write(d.O/'ui-actions.json',dict(attempt02=dict(window_hwnd=6296520,action='Computer Use screenshot, then mouse click Windows X at 1259,14 in the observed 1282x752 outer window',capture='02-visible/before-close.png'),attempt03=dict(window_hwnd=10946920,action='Computer Use list/get/activate, then Alt_L+F4; no screenshot requested'),unchanged_options=['sealed player','ordinary foreground clock','1280x720 request','exact 08 authority-generated fixture bytes','no previous live player','same isolated product and leased active namespace'],changed_comparison_dimensions=['Windows X versus Alt+F4','Computer Use screenshot requested versus not requested'],normal_lifecycle_acceptance=False))
print('All 5 original project input inventories and all 303 sealed build files still match')

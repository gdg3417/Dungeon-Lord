import diagnose as d
import zipfile,hashlib,re
D=d.R/'Docs/testing/evidence/phase7-production-analysis'
failed_preservation=d.read(d.O/'preservation-final.json');assert len(failed_preservation['changes'])==10
restoration=d.read(d.O/'analytics-restoration.json');assert len(restoration['restored'])==10
preserved=d.read(d.O/'preservation-final-restored.json');assert not preserved['changes'] and not preserved['unity_input_changes']
summary=d.read(d.O/'attempt-summary.json');assert summary[0]['exit']['normal'] and summary[0]['exit']['exit_code']==0 and summary[0]['scripted_report_passed']
assert all(not x['exit']['normal'] and x['exit']['forced'] and x['exit']['exit_code']==0xE2490001 for x in summary[1:])
assert all(x['exit']['launch_handle_state']['exited'] and x['exit']['independent_handle_state']['exited'] for x in summary)
assert summary[1]['fixture_source_sha256']==summary[2]['fixture_source_sha256']
entries=[];raw_logs=[]
for label in ['01-scripted','02-visible','03-visible-no-capture']:
 folder=d.O/label;log=folder/'player.log';lines=log.read_text(errors='replace').splitlines()
 selected=[x for x in lines if ('[INFO] Entered BootState.' in x or '[INFO] Saved canonical complete save. Reason: AppQuit' in x)]
 selected+=lines[-9:];excerpt=folder/'shutdown-excerpt.txt';excerpt.open('x',encoding='utf-8').write('\n'.join(selected)+'\n')
 raw_logs.append(dict(attempt=label,sha256=d.sha(log),bytes=log.stat().st_size,excerpt=str(excerpt.relative_to(d.O))))
 entries += [p for p in folder.iterdir() if p.is_file() and (p.suffix in ['.json','.jsonl','.txt','.png']) and '.save.' not in p.name and p.name!='seed.json']
for name in ['preflight.json','host-preflight.json','host-final.json','monitor-self-check.json','preservation-final.json','preservation-final-restored.json','analytics-restoration.json','restore_analytics.py','preservation_after_restore.py','final-source-build.json','ui-actions.json','attempt-summary.json','environment.json','windows-events.json','windows-events-verified.json','diagnose.py','monitor_self_check.py','host_final.py','thread_descriptions.py','final_source_build.py','preservation_final.py','summarize_attempts.py','summarize_waits.py','collect_shutdown.py']:
 entries.append(d.O/name)
entries += [d.R/'Tools/Presentation/qualification_windows.py',d.R/'Tools/Presentation/qualification_inputs.py',d.R/'Temp/p249-shutdown-preflight.py']
packet=D/'shutdown-investigation-reports.zip';rows=[]
with zipfile.ZipFile(packet,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(entries)):
  raw=p.read_bytes();assert not re.search(rb'(?i)(Bearer\s+[A-Za-z0-9_.-]{20}|[-/]accessToken\s+[A-Za-z0-9_.-]{20})',raw)
  name=str(p.relative_to(d.O)).replace('\\','/') if p.is_relative_to(d.O) else 'tools/'+p.name
  # No canonical save payload or raw-memory dump is published.
  assert p.name not in ['seed.json']
  z.writestr(name,raw);rows.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
result=dict(status='still blocked',python_version=d.sys.version,python_executable=d.sys.executable,classifications=[dict(category=4,label='Unresolved after bounded diagnosis',confidence='High confidence in the reproduced visible-process hang; insufficient evidence to assign its production/engine/environment cause'),dict(category=3,label='Qualification process-observation defect',confidence='Confirmed; corrected by the native two-handle diagnostic monitor; older provisional snapshots remain invalid')],source='c870c5dc92aee87e854af350aa0a73653d045ff2',implementation='948a38dc6f47b1419164fdfe8f44a2b3c9fd31f5',starting_head='5174e92c2c074d827b7296290ce71e5c3b6d7fef',main='fbe4bdff0cba9fea72b42fb6a05714327f880df4',original_baseline='7dc6f96b5c35f24923f6e8cbfa8a5e256c16c3ac',artifact=d.read(d.O/'final-source-build.json'),preflight=d.read(d.O/'preflight.json'),monitor_self_check=d.read(d.O/'monitor-self-check.json'),attempts=summary,host_final=d.read(d.O/'host-final.json'),environment=d.read(d.O/'environment.json'),events=d.read(d.O/'windows-events-verified.json'),initial_preservation_failure=failed_preservation,sdk_cache_restoration=restoration,preservation=preserved,protected_manifest_sha256=d.sha(d.O/'protected-before.json'),raw_logs=raw_logs,production_code_change_required='Not demonstrated; no production correction proposed or made',new_full_suites=0,new_builds=0,new_sustained_profiles=0,completed_gap='Independent 1280x720 selected native client verification',remaining_blocked=['valid modified Save/Discard/Continue','invalid draft two-choice','pending/failed/stale native draft safety','empty/incomplete-history native Analysis','strict graceful visible close/reopen and canonical/draft comparison','remaining Default/Large portrait/landscape checks','independent portrait client resolution','owner UAT fixture/launcher and physical Moonlight acceptance'],owner_uat_ready=False,next_recommendation='Independent review; then explicitly scoped symbolized thread-stack investigation and a proposed same-build comparison outside the Codex/Computer Use launch environment. No speculative production or graphics/security changes.',packet=dict(path=packet.name,sha256=d.sha(packet),entries=rows))
with (D/'shutdown-investigation.json').open('x',encoding='utf-8') as f:d.json.dump(result,f,indent=2)
print(d.json.dumps(dict(packet_entries=len(rows),packet_bytes=packet.stat().st_size,classification=[4,3],protected_unchanged=preserved['protected_files'])))

import diagnose as d
import ctypes as C
from ctypes import wintypes as W
import sys
pid=int(sys.argv[1]);identity=d.win.identity(pid);assert identity and 'ui-composition-analysis-p249r2-native' in identity['executable']
h=d.win.checked(d.win.open_process(0x0410,False,pid))
open_thread=d.api(d.K,'OpenThread',[W.DWORD,W.BOOL,W.DWORD],W.HANDLE)
get_name=d.api(d.K,'GetThreadDescription',[W.HANDLE,C.POINTER(W.LPWSTR)],C.c_long)
free=d.api(d.K,'LocalFree',[W.HANDLE],W.HANDLE)
nt=C.WinDLL('ntdll'); query=d.api(nt,'NtQueryInformationThread',[W.HANDLE,C.c_int,W.LPVOID,W.ULONG,W.LPVOID],C.c_long)
psapi=C.WinDLL('psapi'); mapped=d.api(psapi,'GetMappedFileNameW',[W.HANDLE,W.LPVOID,W.LPWSTR,W.DWORD],W.DWORD)
threads=d.host_ps(f"@((Get-Process -Id {pid}).Threads | Select-Object -ExpandProperty Id) | ConvertTo-Json -Compress"); rows=[]
for tid in threads:
 t=open_thread(0x0040|0x0800,False,tid);row=dict(tid=tid)
 if not t:row['query_error']=C.get_last_error();rows.append(row);continue
 try:
  name=W.LPWSTR();hr=get_name(t,C.byref(name));row['description']=name.value if hr==0 else None;row['description_hresult']=hr
  if name:free(C.cast(name,W.HANDLE))
  address=C.c_void_p();status=query(t,9,C.byref(address),C.sizeof(address),None);row['start_query_ntstatus']=status
  if status==0:
   buf=C.create_unicode_buffer(32768);n=mapped(h,address,buf,len(buf));row['start_address']=address.value;row['start_module']=buf.value if n else None
 finally:d.win.close(t)
 rows.append(row)
assert d.win.identity(pid)==identity
d.win.close(h);d.write(d.O/'03-visible-no-capture/thread-descriptions.json',dict(identity=identity,utc=d.utc(),threads=rows,method='Read-only GetThreadDescription/NtQueryInformationThread start-module mapping; no suspension, stack dump or injection'))
print([(x['tid'],x.get('description'),(x.get('start_module') or '').split('\\')[-1]) for x in rows if x.get('description')])

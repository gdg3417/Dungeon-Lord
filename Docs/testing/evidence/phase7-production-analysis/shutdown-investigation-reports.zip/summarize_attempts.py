import diagnose as d
import collections
rows=[]
for label in ['01-scripted','02-visible','03-visible-no-capture']:
 f=d.O/label;e=d.read(f/'exit.json');launch=d.read(f/'launch.json');fixture=d.read(f/'fixture.json');s=f/'after-verified-exit'/d.Path(fixture['active']).name;p=d.read(s)
 text=(f/'player.log').read_text(errors='replace').splitlines();appquit=[x for x in text if '[INFO] Saved canonical complete save. Reason: AppQuit' in x]
 recent=p['primary']['runHistory'].get('RecentOutcomes') or []
 row=dict(attempt=label,pid=launch['pid'],exit=e,fixture_source_sha256=fixture['sha256'],post_verified_exit_save_sha256=d.sha(s),schemaVersion=p['schemaVersion'],retained_records=len(recent),active_parties=len(p['primary']['livingDungeon']['Parties']),appquit_log=appquit,last_log_lines=text[-9:])
 if (f/'smoke.json').exists():row['scripted_report_passed']=d.read(f/'smoke.json')['Passed'];assert row['scripted_report_passed']
 observations=[d.json.loads(x) for x in (f/'observations.jsonl').read_text().splitlines()];row['native_client_resolutions']=sorted({tuple(w['client']) for x in observations for w in x['visible_owned_windows'] if w['client']})
 waits=[]
 for t in [10,70]:
  path=f/('hang-detail-'+str(t)+'.json')
  if path.exists():
   b=d.read(path);waits.append(dict(seconds_after_appquit=t,cpu=b['cpu'],thread_count=len(b['threads']),wait_reasons=dict(collections.Counter(x['waitReason'] for x in b['threads'])),wct_node_counts=dict(collections.Counter(len(x['nodes']) for x in b['wct'])),wct_cycles=sum(x['cycle'] for x in b['wct']),wct_errors=sum(not x['ok'] for x in b['wct'])))
 row['wait_samples']=waits;rows.append(row)
d.write(d.O/'attempt-summary.json',rows)
print(d.json.dumps([dict(attempt=x['attempt'],pid=x['pid'],normal=x['exit']['normal'],exit_code=x['exit']['exit_code'],retained=x['retained_records'],client=x['native_client_resolutions']) for x in rows]))

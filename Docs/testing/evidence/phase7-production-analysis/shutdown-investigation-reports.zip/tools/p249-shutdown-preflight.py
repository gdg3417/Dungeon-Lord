from pathlib import Path
import sys,json,hashlib,datetime,subprocess
R=Path('C:/Dev/Dungeon-Lord'); O=R/'TestResults/phase7-analysis-shutdown-20261023-d1'; assert not O.exists(); O.mkdir()
sys.path.insert(0,str(R/'Tools/Presentation')); import qualification_inputs as q
prior=R/'TestResults/phase7-analysis-recovery-20261022-r2'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(n,v):
 with (O/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
seal=json.loads((prior/'05-build-artifact-manifest.json').read_text()); B=Path(seal['directory'])
assert all(sha(B/x['path'])==x['sha256'] for x in seal['files'])
old=json.loads((prior/'historical-before.json').read_text()); oldp=json.loads((prior/'protected-before.json').read_text()); previous=[]
for rows in [old,oldp]:
 for x in rows: assert sha(Path(x['path']))==x['sha256'],x['path']
print('Prior preservation comparison still valid',len(old),len(oldp),flush=True)
paths={Path(x['path']) for x in old+oldp}
# Protect all current company products, the complete most recent campaign, sealed build and tracked evidence.
for base in [Path('C:/Users/gdg34/AppData/LocalLow/gdg3417'),prior,R/'Docs/testing/evidence',B]:
 for p in base.rglob('*'):
  if p.is_file(): paths.add(p)
rows=[]
for p in sorted(paths):
 q.no_redirect(p); rows.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
write('protected-before.json',rows)
source=[dict(path=n,sha256=sha(R/n)) for n in q.source_inventory(R)]; write('unity-inputs-before.json',source)
assert not subprocess.check_output(['git','diff','c870c5dc92aee87e854af350aa0a73653d045ff2','HEAD','--name-only','--',*q.INPUT_ROOTS],cwd=R,text=True).strip()
write('preflight.json',dict(source='c870c5dc92aee87e854af350aa0a73653d045ff2',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=R,text=True).strip(),sealed_build_artifact=seal['artifact_id'],build_manifest_sha256=sha(prior/'05-build-artifact-manifest.json'),build_files=len(seal['files']),protected_files=len(rows),unity_inputs=len(source),prior_preservation_valid=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print('Diagnostic static preservation and sealed build preflight passed',len(rows),flush=True)

import json,collections
from pathlib import Path
b=Path('TestResults/phase7-analysis-shutdown-20261023-d1')
r=json.loads((b/'03-visible-no-capture/thread-descriptions.json').read_text());print('Thread start modules',collections.Counter((x.get('start_module') or 'Unavailable').split('\\')[-1] for x in r['threads']));print('First thread',r['threads'][:1])
for label in ['02-visible','03-visible-no-capture']:
 for t in [10,70]:
  p=b/label/('hang-detail-'+str(t)+'.json')
  if p.exists():
   r=json.loads(p.read_text());print(label,t,'CPU',r['cpu'],'threads',len(r['threads']),'WaitReasons',dict(collections.Counter(x['waitReason'] for x in r['threads'])),'WCTNodes',dict(collections.Counter(len(x['nodes']) for x in r['wct'])),'cycles',sum(x['cycle'] for x in r['wct']))

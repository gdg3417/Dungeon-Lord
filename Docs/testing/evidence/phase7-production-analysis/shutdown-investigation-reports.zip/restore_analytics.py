import diagnose as d
from pathlib import Path
import shutil
assert d.read(d.O/'host-final.json')['active_players']==[] and not d.players()
failed=d.read(d.O/'preservation-final.json');assert len(failed['changes'])==10 and not failed['unity_input_changes']
base={r['path']:r for r in d.read(d.O/'protected-before.json')}
prior={r['path']:r for r in d.read(d.P/'13-native-product-closed.json')['files']}
unity=d.DATA/'Unity';arch=d.O/'analytics-closeout';assert not arch.exists();arch.mkdir()
rows=[]
for change in failed['changes']:
 target=Path(change['path']);d.qi.no_redirect(target);assert target.resolve().is_relative_to(unity.resolve()),'Only this test product Unity cache may be restored'
 original=prior[str(target)];source=Path(original['archive']);d.qi.no_redirect(source)
 assert d.sha(source)==base[str(target)]['sha256']==original['sha256']==change['before'],'No hash-verified original backup'
 current=d.sha(target) if target.is_file() else None;assert current==change['after'],'Current cache changed after failed check'
 if target.exists():
  moved=arch/'generated-replacements'/target.relative_to(d.DATA);d.qi.no_redirect(moved);assert moved.resolve().is_relative_to(arch.resolve());moved.parent.mkdir(parents=True,exist_ok=True);assert not moved.exists();shutil.move(str(target),str(moved));assert d.sha(moved)==current
 target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.open('xb').write(source.read_bytes());assert d.sha(target)==change['before']
 rows.append(dict(path=str(target),before=change['before'],generated=current,verified_original_archive=str(source),restored_sha256=d.sha(target),classification='Existing isolated product SDK telemetry/cache pruning or rewrite; not canonical save or recovery data'))
extras=[]
for p in sorted(d.DATA.rglob('*')):
 if not p.is_file() or str(p) in base:continue
 d.qi.no_redirect(p);assert p.resolve().is_relative_to(unity.resolve()),'Unexpected new file outside SDK cache; preserve and stop'
 dest=arch/'generated-new'/p.relative_to(d.DATA);assert dest.resolve().is_relative_to(arch.resolve());dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();h=d.sha(p);shutil.move(str(p),str(dest));assert d.sha(dest)==h;extras.append(dict(original_path=str(p),archived_path=str(dest),sha256=h))
expected={str(Path(r['path'])) for r in base.values() if Path(r['path']).is_relative_to(d.DATA)}
actual={str(p) for p in d.DATA.rglob('*') if p.is_file()};assert actual==expected
assert all(d.sha(Path(p))==base[p]['sha256'] for p in expected)
d.write(d.O/'analytics-restoration.json',dict(utc=d.utc(),failed_check_retained='preservation-final.json',restored=rows,generated_new_archived=extras,exact_product_inventory_restored=len(expected),all_processes_exited_before_restore=True,no_canonical_save_or_recovery_change=True,reason='Post-exit restoration of SDK-generated changes from independently hash-verified original archives; no passing shutdown verdict is manufactured'))
print('SDK cache originals restored',len(rows),'new cache files archived',len(extras),'original product file count',len(expected))

from pathlib import Path
import sys,json,hashlib,datetime
R=Path('C:/Dev/Dungeon-Lord');O=R/'TestResults/phase7-analysis-shutdown-20261023-d1'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert (O/'host-final.json').exists(),'Host exit verification required before reading save preservation'
rows=json.loads((O/'protected-before.json').read_text());changes=[]
for i,r in enumerate(rows):
 p=Path(r['path']);actual=sha(p) if p.is_file() else None
 if actual!=r['sha256']:changes.append(dict(path=str(p),before=r['sha256'],after=actual))
 if i and i%10000==0:print('Protected files rechecked',i,flush=True)
inputs=json.loads((O/'unity-inputs-before.json').read_text());input_changes=[r['path'] for r in inputs if sha(R/r['path'])!=r['sha256']]
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),protected_files=len(rows),changes=changes,unity_input_files=len(inputs),unity_input_changes=input_changes,original_normal_owner_and_recovery_files_unchanged=True if not changes else False)
with (O/'preservation-final-restored.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
assert not changes and not input_changes
print('Preservation closeout passed',len(rows),'files and',len(inputs),'Unity inputs',flush=True)

import campaign as c
from pathlib import Path
import json,shutil,subprocess
assert not subprocess.run(['powershell','-NoProfile','-Command',"Get-Process -Name 'Dungeon Lord' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id"],capture_output=True,text=True).stdout.strip(),'Player must exit'
folder=c.OUT/'12-native-portrait-closed'; folder.mkdir()
s=c.DATA/c.namespace('native'); rows=[]
for p in sorted(c.DATA.glob(s.name+'*')):
    c.q.no_redirect(p); dst=folder/p.name; dst.open('xb').write(p.read_bytes()); rows.append(dict(path=str(p),archive=str(dst),sha256=c.sha(dst)))
# Archive exact generated native fixture, then move only our namespace to unused storage.
for r in rows:
    p=Path(r['path']); assert c.sha(p)==r['sha256']; dest=folder/('moved-'+p.name); assert not dest.exists(); shutil.move(str(p),str(dest))
starter=c.DATA/'p249r2-starter-7d83aa81c1444dbe8f7c933669a30773.json'; assert starter.is_file()
s.open('xb').write(starter.read_bytes()); assert c.sha(s)==c.sha(starter)
c.write('13-native-starter-preparation.json',dict(source=c.SOURCE,canonical_starter=str(starter),sha256=c.sha(starter),destination=str(s),prior_namespace_archives=rows,reason='Exact authority-generated funded starter from successful scene fixture; empty history and editor native checks'))
print(json.dumps(dict(history=json.loads((folder/s.name).read_text())['primary']['runHistory'],starter=str(starter))))

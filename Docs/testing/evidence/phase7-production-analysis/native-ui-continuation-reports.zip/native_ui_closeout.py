import campaign as c
from pathlib import Path
import json,shutil,datetime,hashlib
# No player canonical bytes are read until both recorded campaign processes were terminated.
s=c.DATA/c.namespace('native'); snapshot=c.OUT/'13-native-closed-product'; snapshot.mkdir()
rows=[]
for p in sorted(c.DATA.rglob('*')):
    if not p.is_file(): continue
    c.q.no_redirect(p); dst=snapshot/p.relative_to(c.DATA); dst.parent.mkdir(parents=True,exist_ok=True)
    dst.open('xb').write(p.read_bytes()); assert c.sha(dst)==c.sha(p)
    rows.append(dict(path=str(p),archive=str(dst),sha256=c.sha(dst),bytes=p.stat().st_size))
c.write('13-native-product-closed.json',dict(source=c.SOURCE,files=rows,after_forced_process_exit=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
# Build artifact must still match its sealed identity.
seal=c.read('05-build-artifact-manifest.json'); build=Path(seal['directory'])
assert all(c.sha(build/r['path'])==r['sha256'] for r in seal['files'])
# Retire all temporary native inputs using verified original bytes; preserve each qualified byte stream first.
stage='native'; before=c.compare(stage); assert not before['failures']; prepared=c.read(stage+'-inputs-prepared.json')
originals={r['path']:r['source_sha256'] for r in prepared['files']}; archived=[]
for name in c.q.source_inventory(c.ROOT):
    src=c.ROOT/name; dst=c.project(stage)/name; assert c.sha(src)==originals[name]
    if src.read_bytes()!=dst.read_bytes():
        saved=c.OUT/'source-input-closure'/stage/name; c.q.no_redirect(saved); saved.parent.mkdir(parents=True,exist_ok=True)
        saved.open('xb').write(dst.read_bytes()); archived.append(dict(path=name,qualified_sha256=c.sha(saved),source_sha256=c.sha(src)))
        shutil.copyfile(src,dst)
names=c.q.source_inventory(c.ROOT); stages=[]
for st in c.STAGES:
    assert set(names)==c.q.target_inventory(c.project(st))
    assert all(c.sha(c.ROOT/n)==c.sha(c.project(st)/n) for n in names)
    stages.append(dict(stage=st,original_exact_inputs=len(names)))
c.write('13-all-source-inputs-restored.json',dict(source=c.SOURCE,stages=stages,native_archived_qualified_inputs=archived,build_files_verified=len(seal['files']),artifact_id=seal['artifact_id']))
changes=[]; history=c.read('historical-before.json')
for i,r in enumerate(history):
    p=Path(r['path']); h=c.sha(p) if p.is_file() else None
    if h!=r['sha256']: changes.append(dict(path=str(p),before=r['sha256'],after=h))
    if i and i%10000==0: print('Historical files checked',i,flush=True)
protected=c.read('protected-before.json'); personal=[]
for r in protected:
    p=Path(r['path']); h=c.sha(p) if p.is_file() else None
    if h!=r['sha256']: personal.append(dict(path=str(p),before=r['sha256'],after=h))
c.write('13-preservation-final.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),historical_checked=len(history),historical_changes=changes,protected_checked=len(protected),protected_changes=personal,all_disposable_original_input_files_restored=stages,exceptions='No protected-byte changes; native visible-player process exit/reopen evidence is invalidated, not accepted as a pass'))
assert not changes and not personal
print(json.dumps(dict(historical_unchanged=len(history),original_persistent_unchanged=len(protected),stages=stages,archived_new_product_files=len(rows))))

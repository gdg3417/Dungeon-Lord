$ErrorActionPreference='Stop'
$campaignRoot='C:\Dev\Dungeon-Lord\TestResults\phase7-analysis-recovery-20261022-r2'
$campaignExe='C:\Dev\Dungeon-Lord\Temp\ui-composition-analysis-p249r2-native\Builds\Development\Windows\Dungeon Lord.exe'
$campaignIds=@(38808,39392)
$rows=@()
foreach($campaignPid in $campaignIds) {
  $p=Get-CimInstance Win32_Process -Filter "ProcessId = $campaignPid"
  if($p.ExecutablePath -ne $campaignExe) { throw 'Unexpected process identity' }
  if($p.CommandLine -notlike '*phase7-analysis-recovery-20261022-r2*') {throw 'Unexpected command provenance'}
  $native=Get-Process -Id $campaignPid
  $rows+= [pscustomobject]@{pid=$campaignPid;path=$p.ExecutablePath;command=$p.CommandLine;cpu=$native.CPU;handle=$native.MainWindowHandle.ToInt64();observedUtc=[DateTime]::UtcNow.ToString('o')}
}
Start-Sleep -Seconds 3
foreach($row in $rows) {
  $native=Get-Process -Id $row.pid
  if($native.MainWindowHandle -ne 0) {throw 'Player window still active'}
  $row | Add-Member -NotePropertyName cpuAfter3Seconds -NotePropertyValue $native.CPU
  $log=if($row.pid -eq 38808){'10-native-ui-landscape.log'}else{'12-native-ui-portrait.log'}
  $text=Get-Content -LiteralPath (Join-Path $campaignRoot $log) -Raw
  if(!$text.Contains('Reason: AppQuit') -or !$text.Contains('PlayerConnection::Cleanup')) {throw 'Shutdown not reached'}
}
$out=Join-Path $campaignRoot '13-native-shutdown-hang.json'
if(Test-Path -LiteralPath $out){throw 'Evidence exists'}
[pscustomobject]@{status='Native visible-player exit failed: window closed and AppQuit persisted, but process remains alive after cleanup';processes=$rows;action='Terminate only these two exact campaign processes after evidence capture; no further native launch or fixture preparation';source='c870c5dc92aee87e854af350aa0a73653d045ff2'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $out
foreach($row in $rows) { Stop-Process -Id $row.pid; Wait-Process -Id $row.pid -Timeout 20 -ErrorAction SilentlyContinue }
if(Get-Process -Id $campaignIds -ErrorAction SilentlyContinue){throw 'Campaign processes remain'}
Write-Output 'Both exact campaign processes terminated after recorded shutdown hang; no player window or Unity Editor process was changed.'

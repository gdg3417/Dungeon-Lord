import campaign as c
from pathlib import Path
s=c.DATA/c.namespace('native')
p=c.OUT/'10-native-ui-post-exit.save.json'
p.open('xb').write(s.read_bytes())
a=c.read('10-native-ui-landscape-prelaunch.save.json'); b=c.read(p.name)
print('envelope keys',list(b))
print('primary keys',list(b.get('primary',{})))
c.write('10-native-ui-archive.json',dict(save=str(s),sha256=c.sha(p),purpose='Exact after process exit; ordinary clock ran overnight while user cleared security prompt, so navigation-only equality is not inferred'))

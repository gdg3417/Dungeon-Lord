#if UNITY_EDITOR
using System;
using System.Collections;
using System.Linq;
using DungeonBuilder.M0.Gameplay.RunSimulation;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.TestTools;
using UnityEngine.UIElements;

namespace DungeonBuilder.M0.Tests
{
    public abstract partial class PhaseSevenA4ProductionSceneTests
    {
        [UnityTest]
        public IEnumerator C0DiagnosticsInputBaselineTrace()
        {
            var root = GameRoot.Instance;
            root.Save.structureRuntime.ManaReserve = 1000;
            Assert.That(root.SimulateRunOnce(), Is.True);
            var latest = root.Save.runHistory.LatestOutcome;
            var selected = root.Save.runHistory.RecentOutcomes.Last();
            TestContext.WriteLine("Latest " + latest.RunId + " events=" + CombatC0Diagnostics.Events(latest).Count +
                "; history " + selected.RunId + " events=" + CombatC0Diagnostics.Events(selected).Count);
            Assert.That(CombatC0Diagnostics.Events(selected).Count, Is.GreaterThan(0));
            Click(controller.GetComponent<UIDocument>().rootVisualElement.Q<Button>("legacy"));
            var keyboard = InputSystem.AddDevice<Keyboard>(); var mouse = InputSystem.AddDevice<Mouse>();
            try
            {
                yield return null;
                InputSystem.QueueStateEvent(keyboard, new KeyboardState(Key.F2)); yield return null;
                InputSystem.QueueStateEvent(keyboard, new KeyboardState()); yield return null;
                TestContext.WriteLine("Input state: overlay enabled=" + root.overlay.enabled + ", active=" + root.overlay.gameObject.activeInHierarchy +
                    ", diagnostics=" + root.overlay.DiagnosticsVisible + ", development=" + root.DevPanelEnabled +
                    ", keyboard current=" + (Keyboard.current == keyboard) + ", update=" + InputSystem.settings.updateMode);
                // Owner already confirms F2 opens focus. Establish that initial state so this
                // reproduction isolates the reported PageDown/wheel failure rather than F2.
                if (!root.overlay.DiagnosticsVisible) root.overlay.ToggleRunDiagnosticsFocus();
                root.overlay.RefreshOverlayText();
                var text = root.overlay.overlayText.text;
                TestContext.WriteLine("Initial rendered text: " + text);
                for (int i = 0; i < 5; i++)
                {
                    InputSystem.QueueStateEvent(keyboard, new KeyboardState(Key.PageDown)); yield return null;
                    InputSystem.QueueStateEvent(keyboard, new KeyboardState()); yield return null;
                }
                TestContext.WriteLine("After PageDown: " + root.overlay.overlayText.text);
                TestContext.WriteLine("Paged field=" + root.overlay.FullDiagnosticsScrollOffset);
                Assert.That(root.overlay.overlayText.text, Is.Not.EqualTo(text), "Real Update input must change rendered text");
                text = root.overlay.overlayText.text;
                InputSystem.QueueStateEvent(mouse, new MouseState { scroll = new Vector2(0, -120) });
                yield return null; yield return null;
                TestContext.WriteLine("After wheel: " + root.overlay.overlayText.text);
                Assert.That(root.overlay.overlayText.text, Is.Not.EqualTo(text));
            }
            finally { InputSystem.RemoveDevice(keyboard); InputSystem.RemoveDevice(mouse); }
        }
    }
}
#endif

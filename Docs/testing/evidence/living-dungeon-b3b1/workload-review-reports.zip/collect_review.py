from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
DEST=ROOT/'Docs/testing/evidence/living-dungeon-b3b1'
REVIEWED='4e05a3c4d6c7a7e6125471029f8423276246f4ca'
TESTED='6217995eb63f8df00283235f34ccbfa5d34f0538'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
reports=[];measurements=[]
for p in sorted(OUT.glob('*.xml')):
    r=ET.parse(p).getroot();cases=list(r.iter('test-case'))
    reports.append(dict(file=p.name,sha256=sha(p),verdict=r.attrib,
        failures=[dict(name=c.get('fullname'),message=c.findtext('failure/message')) for c in cases if c.get('result')=='Failed'],
        skips=[dict(name=c.get('fullname'),reason=c.findtext('reason/message')) for c in cases if c.get('result') in ('Skipped','Ignored')],
        groups={k:dict(passed=sum(c.get('result')=='Passed' for c in cases if k in c.get('fullname','')),
            failed=sum(c.get('result')=='Failed' for c in cases if k in c.get('fullname','')))
            for k in ['LivingDungeonB3B1','LivingDungeonPhaseB1','LivingDungeonPhaseB2','CombatC0','CombatC2','Migration','DetachedCanonical','RunHistory','RunHeat','LootHeat']}))
    for c in cases:
        for line in (c.findtext('output') or '').splitlines():
            if line.startswith('Work boundary '): measurements.append(dict(item.split('=',1) for item in line[len('Work boundary '):].split()))
assert len(measurements)==36,len(measurements)
preservation={}
for name in ['preservation-after.json','historical-evidence-after.json']:
    rows=json.loads((OUT/name).read_text());preservation[name]=dict(total=len(rows),equal=sum(r['equal'] for r in rows),exceptions=[r for r in rows if not r['equal']])
    assert all(r['equal'] for r in rows),name
runtimeDiff=git('diff','--name-only',REVIEWED,'HEAD','--','Assets/_Project/Scripts','Assets/_Project/Editor','Packages','ProjectSettings','ContentAuthoring')
assert not runtimeDiff,runtimeDiff
sources=[]
with zipfile.ZipFile(OUT/'root-inputs-before.zip') as z:
    names=['Assets/_Project/Data/Bootstrap/build_config.json','Assets/_Project/Scripts/Services/SaveService.cs',
        'Assets/_Project/Scripts/BuildTools/DevelopmentBuildUtility.cs','ProjectSettings/ProjectSettings.asset',
        'ProjectSettings/UnityConnectSettings.asset','Assets/Settings/UniversalRP.asset','Assets/UniversalRenderPipelineGlobalSettings.asset',
        'Assets/_Project/Editor/DungeonSpatial/Tests/CombatC0ProductionEvidenceSceneTests.cs',
        'Assets/_Project/Editor/DungeonSpatial/Tests/ProductionDungeonFloorSceneTests.cs',
        'Assets/_Project/Scripts/BuildTools/ProductionDungeonScreenshots.cs',
        'Assets/_Project/Editor/DungeonSpatial/Tests/PhaseSevenA4ProductionSceneTests.cs',
        'Assets/_Project/Tests/EditMode/BootstrapOverlayPagingTests.cs',
        'Assets/_Project/Tests/EditMode/MvpCanonicalJourneyIntegrationTests.cs','Assets/_Project/Tests/EditMode/RunSimulationTests.cs']
    for name in names:
        equal=(ROOT/name).read_bytes()==z.read(name);assert equal,name
        sources.append(dict(path=name,equal=equal,sha256=sha(ROOT/name)))
record=dict(reviewedHead=REVIEWED,testedSource=TESTED,collectedAtHead=git('rev-parse','HEAD'),runtimeChanges=runtimeDiff.splitlines(),
    beforeAfterCorrection='Not applicable: no runtime defect reproduced and no production code corrected.',
    reports=reports,measurements=measurements,preservation=preservation,restoredSources=sources,
    commands=[json.loads(p.read_text()) for p in sorted(OUT.glob('*-command.json'))],
    logs=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for p in sorted(OUT.glob('*.log'))],
    goldenSha256=sha(ROOT/'Assets/_Project/Tests/EditMode/combat-c0-b1-golden.zip'),
    limits='Existing 65536-byte/2048-partyReplay/8192-aggregateReplay/1000000-combatWork qualification envelope unchanged. Ceilings are derived tighter test configurations.',
    historicalException='Earlier accepted auxiliary shader-analytics cache loss and five PR #242 screenshots remain absent in current baseline; no new exception in this review.',
    scope='Recorded original save/build and TestResults inventories; existing transient LocalLow logs/default test XML exclusion retained; no broader preservation claim.',
    extraValidation='No production runtime change: new PlayMode/player build/full-suite repetition not required. Original runtime build evidence remains applicable; no new platform qualification claimed.')
(DEST/'workload-review-results.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
with zipfile.ZipFile(DEST/'workload-review-reports.zip','w',zipfile.ZIP_DEFLATED) as z:
    items=set(OUT.glob('*.xml'))|set(OUT.glob('*-command.json'))|set(OUT.glob('applicability-*.json'))|set(OUT.glob('inputs-*.json'))
    for name in ['baseline.json','historical-evidence-before.json','historical-evidence-after.json','preservation-after.json','accepted-preservation-exceptions.json','substitutions-restored.json','review-adapter.json','product-isolation.json','fixture-substitutions.json','starter-substitution.json','review.py','collect_review.py']:
        items.add(OUT/name)
    for p in sorted(items): z.write(p,p.relative_to(OUT).as_posix())
print(json.dumps(dict(reports=[dict(file=r['file'],verdict=r['verdict']) for r in reports],preservation=preservation,measurements=len(measurements))))

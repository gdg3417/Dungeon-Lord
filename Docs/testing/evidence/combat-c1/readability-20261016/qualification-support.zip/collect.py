from pathlib import Path
import hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as E
ROOT=Path.cwd(); LOCAL=ROOT/'TestResults/combat-c1-readability'; OUT=ROOT/'Docs/testing/evidence/combat-c1/readability-20261016'; OUT.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v): (OUT/n).write_text(json.dumps(v,indent=2),encoding='utf-8')
def redact(s):
 s=re.sub(r'(?i)([-/][A-Za-z_-]*(?:token|password|serial)(?:\s+|=))(?:(?:"[^"]*")|(?:\S+))',r'\1[REDACTED]',s)
 s=re.sub(r'(?i)(Bearer\s+)[A-Za-z0-9._~-]+',r'\1[REDACTED]',s)
 return re.sub(r'(?i)((?:access token|Machine Id|Id):?\s+)[^\r\n]+',r'\1[REDACTED]',s)
reports=[]
with zipfile.ZipFile(OUT/'qualification-reports.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((ROOT/'TestResults').glob('combat-c1-readable-*.xml')):
  r=E.parse(p).getroot(); z.write(p,p.name)
  reports.append(dict(file=p.name,sha256=sha(p),attributes=r.attrib,failures=[dict(name=c.get('fullname'),message=c.findtext('failure/message'),stack=c.findtext('failure/stack-trace')) for c in r.iter('test-case') if c.get('result')=='Failed'],skips=[dict(name=c.get('fullname'),reason=c.findtext('reason/message')) for c in r.iter('test-case') if c.get('result') in ('Skipped','Inconclusive')]))
write('report-summary.json',reports)
edit=E.parse(ROOT/'TestResults/combat-c1-readable-editmode.xml').getroot()
final=E.parse(ROOT/'TestResults/combat-c1-readable-production-final.xml').getroot()
bounded=E.parse(ROOT/'TestResults/combat-c1-readable-playmode-final.xml').getroot()
core=[c for c in bounded.iter('test-case') if c.get('classname')!='DungeonBuilder.M0.Tests.PlayMode.PhaseSevenA4ProductionShellPlayModeTests']
if edit.get('failed')!='0' or final.get('failed')!='0' or len(core)!=157 or any(c.get('result')!='Passed' for c in core): raise ValueError('Unqualified results')
changed=subprocess.check_output(['git','diff','c75ddf4','HEAD','--name-only','--','Assets','Packages','ProjectSettings','ContentAuthoring'],text=True).splitlines()
if changed!=['Assets/_Project/Editor/DungeonSpatial/Tests/CombatC1ReplaySceneTests.cs']: raise ValueError('Unexpected post-EditMode source changes')
write('qualification-applicability.json',dict(editmode=dict(source='c75ddf43e45d77de28ac8c0099c3b6a9f39d7fa4',passed=228,failed=0,skipped=0),
 final_production_playmode=dict(source='742c45de6cd153aebeeb642183475b3129744075',passed=7,failed=0,skipped=0),
 bounded_playmode_core=dict(source='e61dece',passed=len(core),failed=0,cases=[c.get('fullname') for c in core]),
 explanation='Two bounded PlayMode attempts each passed 163/164; the sole failure was the strengthened floor readability fixture inheriting a 640x360 view and 77-pixel-high map. The final seven-scene production follow-up passes with the explicit recorded floor and supported portrait resolution. All runtime/config inputs are unchanged since the 228-case EditMode qualification. Only the C1 scene-test file changed afterward; core and prior full-suite evidence is not relabeled as rerun.',
 prior_full_suites='Parent directory retains their exact original source applicability. No new full suite or frozen B1 fixture regeneration.',windows_build_attempts=1))
with zipfile.ZipFile(OUT/'qualification-support.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(LOCAL.iterdir()):
  if p.is_file(): z.write(p,p.name)
 for p in sorted((ROOT/'Temp').glob('combat-c1-readable-*.log')): z.writestr('logs/'+p.name,redact(p.read_text(encoding='utf-8-sig',errors='replace')))
rows=json.loads((LOCAL/'preservation-after.json').read_text())
if any(not r['equal'] for r in rows): raise ValueError('Protected bytes changed')
write('preservation-summary.json',dict(files=len(rows),changed=0,saves_restored=False,owner_and_primary=[r for r in rows if Path(r['path']).name in ('save_primary.json','combat-c0-diagnostics-validation-20261015.json')],complete_inventory='qualification-support.zip: preservation-before.json and preservation-after.json'))
checks=[]
for p in sorted(LOCAL.glob('*-exact.json')):
 r=json.loads(p.read_text())
 if r['failures'] or r['unexpected']: raise ValueError('Input checkpoint mismatch')
 checks.append(dict(file=p.name,sha256=sha(p),expected=r['expected_count'],actual=r['actual_count'],failures=0))
write('input-checkpoints.json',checks)
screens=sorted((ROOT/'Temp/ui-composition-combat-c0-diagnostics-validation-r2/TestResults/phase7a4-screenshots').glob('composition-combat-c1-readable-*.png'))
with zipfile.ZipFile(OUT/'screenshots.zip','w',zipfile.ZIP_STORED) as z:
 for p in screens: z.write(p,p.name)
write('screenshots.json',[dict(file=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in screens])
build=ROOT/'Temp/ui-composition-combat-c0-diagnostics-validation-warm/Builds/Development/Windows-combat-c1-readability-20261016'
report=json.loads((build/'build-report.json').read_text()); namespace='combat-c0-diagnostics-validation-20261015.json'
if report['buildResult']!='Succeeded' or report['errorCount'] or not report['developmentBuild']: raise ValueError('Build failed')
if namespace.encode() not in (build/'Dungeon Lord_Data/sharedassets0.assets').read_bytes(): raise ValueError('Namespace missing')
art=(build/'packed-dungeon-art.txt').read_text().splitlines()
if len(art)!=52: raise ValueError('Packed artwork changed')
files=sorted(p for p in build.rglob('*') if p.is_file())
with zipfile.ZipFile(OUT/'build-reports-original.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ('build-report.json','build-messages.txt','packed-dungeon-art.txt','packed-source-assets.txt'): z.write(build/name,name)
write('windows-artifact-manifest.json',dict(report=report,executable=str(build/'Dungeon Lord.exe'),namespace=namespace,namespace_packed=True,packed_art_count=len(art),player_launched=False,files=len(files),bytes=sum(p.stat().st_size for p in files),inventory=[dict(path=p.relative_to(build).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files]))
write('source-identity.json',dict(branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),correction_baseline='a3dfea81d0dcde750a21168ac8454a3825c1ccf4',qualified_unity_source=subprocess.check_output(['git','log','-1','--format=%H','--','Assets','Packages','ProjectSettings','ContentAuthoring'],text=True).strip(),unity_input_trees={p:subprocess.check_output(['git','rev-parse','HEAD:'+p],text=True).strip() for p in ('Assets','Packages','ProjectSettings','ContentAuthoring')},b1_fixture_sha256=sha(ROOT/'Assets/_Project/Tests/EditMode/combat-c0-b1-golden.zip')))
names=subprocess.check_output(['git','diff','a3dfea8','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
write('changed-files.json',sorted(set(names)))
print(len(reports),'reports;',len(screens),'screenshots;',len(rows),'preserved files;',len(files),'build files')

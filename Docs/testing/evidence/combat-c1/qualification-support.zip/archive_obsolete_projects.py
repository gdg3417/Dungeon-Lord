"""Archive verified obsolete copied inputs and outputs, retaining complete hashes. No deletion."""
from pathlib import Path
import hashlib,json,sys,zipfile
ROOT=Path.cwd(); OUT=ROOT/'TestResults/combat-c1'; target=OUT/'retired-projects'; target.mkdir(exist_ok=True)
names=['ui-composition-combat-c0-access-validation','ui-composition-combat-c0-integration-validation','ui-composition-combat-c0-validation']
preflight={r['project']:r for r in json.loads((OUT/'cleanup-preflight.json').read_text())}
results=[]
for name in names:
 row=preflight[name]
 allowed=['Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Fallback.asset'] if name.endswith('integration-validation') else []
 if row['reparse_points'] or row['git_or_nested_work'] or row['possible_protected_files'] or [d['path'] for d in row['differences']]!=allowed: raise ValueError('Unverified project '+name)
 base=ROOT/'Temp'/name; archive=target/(name+'.zip'); inventory=[]
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=3) as saved:
  for file in row['noncache_files']:
   p=base/file['path']; data=p.read_bytes(); digest=hashlib.sha256(data).hexdigest()
   saved.writestr(file['path'],data); inventory.append(dict(path=file['path'],bytes=len(data),sha256=digest))
 with zipfile.ZipFile(archive) as saved:
  if saved.testzip() is not None: raise ValueError('Archive CRC failure')
  for r in inventory:
   if hashlib.sha256(saved.read(r['path'])).hexdigest()!=r['sha256']: raise ValueError('Archive SHA failure')
 result=dict(project=name,source_commit=row['source_commit'],archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
  archive_verified=True,excluded=['Library (disposable regenerated cache only)'],files=inventory,
  normalization='Historical committed inputs matched exactly; integration has only the existing generated TMP fallback asset difference, archived verbatim.',
  protected_save_files_present=False,removed=False)
 (target/(name+'-manifest.json')).write_text(json.dumps(result,indent=2))
 results.append({k:v for k,v in result.items() if k!='files'})
 print(name,len(inventory),'files archived and SHA-256 verified',flush=True)
(OUT/'cleanup-archives.json').write_text(json.dumps(results,indent=2))

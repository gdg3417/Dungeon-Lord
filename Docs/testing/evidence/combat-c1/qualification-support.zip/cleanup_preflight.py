"""Read-only preflight of explicitly named copied C0 projects; no deletion."""
from pathlib import Path
import hashlib, io, json, os, stat, subprocess, sys, tarfile
sys.path.insert(0, str(Path.cwd()/'Tools/Presentation'))
import qualification_inputs as q
ROOT=Path.cwd(); OUT=ROOT/'TestResults/combat-c1'
BASES={
 'ui-composition-combat-c0-access-validation':'e6bbd68f65d10a7e09cf0c2f6994cf23c30dd6da',
 'ui-composition-combat-c0-b1-baseline':'c0dba584f1d1b9f10ccc50bf51fc26c831c5f81e',
 'ui-composition-combat-c0-diagnostics-validation':'27dc09b991e6354ce64735ea3a47e11279c3cce5',
 'ui-composition-combat-c0-integration-validation':'d2e272f6dc5b12db26f1129c4c31faf295021ace',
 'ui-composition-combat-c0-validation':'a6c9d6e13013e9fa6993b2f4b094da6139a483e4',
}
rows=[]
for name,commit in BASES.items():
 p=q.target_path(ROOT,name)
 if not p.exists(): continue
 q.NAMESPACE=json.loads((p/q.CONFIG).read_text(encoding='utf-8-sig'))['save']['fileName']
 actual=q.target_inventory(p)
 data=subprocess.check_output(['git','archive',commit,*q.INPUT_ROOTS])
 with tarfile.open(fileobj=io.BytesIO(data)) as archive:
  expected={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
 differences=[]
 for path in sorted(actual|set(expected)):
  if path not in actual or path not in expected: differences.append(dict(path=path,kind='missing' if path not in actual else 'extra')); continue
  left=q.normalized(path,q.transformed(path,expected[path])); right=q.normalized(path,(p/path).read_bytes())
  if left!=right: differences.append(dict(path=path,kind='changed'))
 links=[]; protected=[]; files=[]; cache_files=0; cache_bytes=0
 for folder,dirs,names in os.walk(p,followlinks=False):
  for child in dirs+names:
   x=Path(folder)/child
   if x.is_symlink() or getattr(x.lstat(),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT: links.append(str(x.relative_to(p)))
  for child in names:
   x=Path(folder)/child; rel=x.relative_to(p)
   if rel.parts[0]=='Library': cache_files+=1; cache_bytes+=x.stat().st_size; continue
   files.append(dict(path=rel.as_posix(),bytes=x.stat().st_size))
   if child.endswith(('.bak','.backup','.sav','.save')) or ('save' in child.lower() and x.suffix=='.json' and rel.parts[0] not in q.INPUT_ROOTS): protected.append(rel.as_posix())
 row=dict(project=name,source_commit=commit,namespace=q.NAMESPACE,input_count=len(actual),differences=differences,reparse_points=links,
  git_or_nested_work=[str(x.relative_to(p)) for x in p.rglob('.git')],possible_protected_files=protected,
  noncache_files=files,cache_files=cache_files,cache_bytes=cache_bytes)
 rows.append(row)
 print(name,'source',commit[:8],'inputs',len(actual),'differences',differences,'links',links,'protected',protected,'noncache MB',round(sum(f['bytes'] for f in files)/1e6),flush=True)
(OUT/'cleanup-preflight.json').write_text(json.dumps(rows,indent=2))

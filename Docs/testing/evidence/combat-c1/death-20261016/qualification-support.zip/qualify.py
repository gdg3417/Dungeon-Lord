from pathlib import Path
import json,sys,zipfile
ROOT=Path.cwd(); sys.path.insert(0,str(ROOT/'Tools/Presentation'))
import qualify_visual_feedback as audit
OUT=ROOT/'TestResults/combat-c1-death'; OUT.mkdir(exist_ok=True)
AUTO='ui-composition-combat-c0-diagnostics-validation-r2'; OWNER='ui-composition-combat-c0-diagnostics-validation-warm'
def write(name,value): (OUT/name).write_text(json.dumps(value,indent=2))
mode=sys.argv[1]; owner=mode.startswith('owner'); audit.OUT=OUT; audit.NAME=OWNER if owner else AUTO
audit.inputs.NAMESPACE='combat-c0-diagnostics-validation-20261015.json' if owner else 'combat-c0-access-validation-20261015.json'
if mode=='snapshot':
 files={p for p in audit.SAVE.rglob('*') if p.is_file() and p.suffix not in ('.log','.xml')}
 for folder in ['Windows-combat-c0-final-20261015','Windows-combat-c1','Windows-combat-c1-readability-20261016','Windows-combat-c1-rpg-20261016','Windows-combat-c1-rpg-final-20261016']:
  files.update(p for p in (ROOT/'Temp'/OWNER/'Builds/Development'/folder).rglob('*') if p.is_file())
 path=OUT/'preservation-before.json'
 if path.exists(): raise ValueError('Never overwrite baseline')
 write(path.name,[dict(path=str(p),sha256=audit.sha(p)) for p in sorted(files)])
 print(len(files),'protected save/recovery and comparison-build files captured')
elif mode in ('prepare','owner-prepare'):
 result=audit.inputs.compare(ROOT,audit.NAME)
 if result['unexpected']: raise ValueError('Unexpected inputs')
 with zipfile.ZipFile(OUT/(mode+'-previous-inputs.zip'),'x',zipfile.ZIP_DEFLATED) as z:
  for row in result['files']:
   p=ROOT/'Temp'/audit.NAME/row['path']
   if not row['equal'] and p.exists(): z.write(p,row['path'])
 write(mode+'-before.json',result); write(mode+'-exact.json',audit.inputs.prepare(ROOT,audit.NAME)); print('Prepared',audit.NAME)
elif mode in ('refresh','owner-refresh'): write('refreshed-'+mode+'-'+sys.argv[2]+'.json',audit.inputs.prepare(ROOT,audit.NAME))
elif mode in ('checkpoint','owner-checkpoint'): audit.checkpoint(sys.argv[2])
elif mode=='audit':
 rows=json.loads((OUT/'preservation-before.json').read_text())
 for r in rows:
  p=Path(r['path']); r['after_sha256']=audit.sha(p) if p.exists() else None; r['equal']=r['sha256']==r['after_sha256']
 write('preservation-after.json',rows); bad=[r for r in rows if not r['equal']]
 print(len(rows),'protected files;',len(bad),'changed')
 for r in bad: print(r['path'])
 sys.exit(bool(bad))

from pathlib import Path
import hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as E
ROOT=Path.cwd(); LOCAL=ROOT/'TestResults/combat-c1-death'; OUT=ROOT/'Docs/testing/evidence/combat-c1/death-20261016'; OUT.mkdir(exist_ok=True)
SOURCE='8e9f63195af9df26dde180e318c21e2ea7c47b84'; BASE='ecc025d72ee8597ceb340850c5a1ad39b7d9ab9e'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a): return subprocess.check_output(['git',*a],text=True).strip()
def write(n,v): (OUT/n).write_text(json.dumps(v,indent=2),encoding='utf-8')
def redact(s):
 s=re.sub(r'(?i)([-/][A-Za-z_-]*(?:token|password|serial)(?:\s+|=))(?:(?:"[^"]*")|(?:\S+))',r'\1[REDACTED]',s)
 s=re.sub(r'(?i)(Bearer\s+)[A-Za-z0-9._~-]+',r'\1[REDACTED]',s)
 return re.sub(r'(?i)((?:access token|Machine Id|Id):?\s+)[^\r\n]+',r'\1[REDACTED]',s)
reports=[]
with zipfile.ZipFile(OUT/'qualification-reports.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((ROOT/'TestResults').glob('combat-c1-death-*.xml')):
  r=E.parse(p).getroot(); z.write(p,p.name)
  reports.append(dict(file=p.name,sha256=sha(p),attributes=r.attrib,failures=[dict(name=c.get('fullname'),message=c.findtext('failure/message'),stack=c.findtext('failure/stack-trace')) for c in r.iter('test-case') if c.get('result')=='Failed'],skips=[dict(name=c.get('fullname'),reason=c.findtext('reason/message')) for c in r.iter('test-case') if c.get('result') in ('Skipped','Inconclusive')]))
write('report-summary.json',reports)
final={}
for mode in ('editmode','playmode'):
 r=E.parse(ROOT/('TestResults/combat-c1-death-'+mode+'.xml')).getroot()
 if r.get('failed')!='0' or r.get('skipped')!='0': raise ValueError('Final affected set not green')
 final[mode]=dict(source=SOURCE,passed=int(r.get('passed')),failed=0,skipped=0,cases=[c.get('fullname') for c in r.iter('test-case')])
if git('diff',SOURCE,'HEAD','--name-only','--','Assets','Packages','ProjectSettings','ContentAuthoring'): raise ValueError('Unqualified Unity changes')
write('qualification-applicability.json',dict(final_affected=final,explanation='Final affected EditMode and PlayMode sets and the single replacement Windows build use identical frozen Unity input trees. Focused01 used identical runtime before the final extra camera/cleanup test assertions. Earlier full-suite and RPG correction reports retain their original source applicability; no unrelated full suite or unchanged C0 resolver suite was rerun.',windows_build_attempts=1))
rows=json.loads((LOCAL/'preservation-after.json').read_text())
if len(rows)!=1572 or any(not r['equal'] for r in rows): raise ValueError('Protected bytes changed')
write('preservation-summary.json',dict(files=len(rows),changed=0,saves_restored=False,owner_and_primary=[r for r in rows if Path(r['path']).name in ('save_primary.json','combat-c0-diagnostics-validation-20261015.json')],complete_inventory='qualification-support.zip: preservation-before.json and preservation-after.json'))
checks=[]
for p in sorted(LOCAL.glob('*-exact.json')):
 r=json.loads(p.read_text())
 if r['failures'] or r['unexpected']: raise ValueError('Unresolved input mismatch: '+p.name)
 checks.append(dict(file=p.name,sha256=sha(p),expected=r['expected_count'],actual=r['actual_count'],failures=0))
write('input-checkpoints.json',checks)
screens=sorted((ROOT/'Temp/ui-composition-combat-c0-diagnostics-validation-r2/TestResults/phase7a4-screenshots').glob('composition-combat-c1-death-*.png'))
with zipfile.ZipFile(OUT/'screenshots.zip','w',zipfile.ZIP_STORED) as z:
 for p in screens: z.write(p,p.name)
write('screenshots.json',[dict(file=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in screens])
for suffix in ('monster-defeat-720x1280.png','group-5-720x1280.png','group-5-1920x1080.png','corridor-trap-1920x1080.png','prior-floor-1920x1080.png','completed-720x1280.png'):
 matches=[p for p in screens if p.name=='composition-combat-c1-death-'+suffix]
 if len(matches)!=1: raise ValueError('Representative screenshot missing: '+suffix)
 (OUT/matches[0].name).write_bytes(matches[0].read_bytes())
build=ROOT/'Temp/ui-composition-combat-c0-diagnostics-validation-warm/Builds/Development/Windows-combat-c1-death-20261016'
report=json.loads((build/'build-report.json').read_text()); namespace='combat-c0-diagnostics-validation-20261015.json'
if report['buildResult']!='Succeeded' or report['errorCount'] or not report['developmentBuild']: raise ValueError('Build failed')
if namespace.encode() not in (build/'Dungeon Lord_Data/sharedassets0.assets').read_bytes(): raise ValueError('Namespace missing')
art=(build/'packed-dungeon-art.txt').read_text().splitlines()
if len(art)!=52: raise ValueError('Packed artwork changed')
files=sorted(p for p in build.rglob('*') if p.is_file())
with zipfile.ZipFile(OUT/'build-reports-original.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ('build-report.json','build-messages.txt','packed-dungeon-art.txt','packed-source-assets.txt'): z.write(build/name,name)
write('windows-artifact-manifest.json',dict(report=report,executable=str(build/'Dungeon Lord.exe'),namespace=namespace,namespace_packed=True,packed_art_count=len(art),player_launched=False,files=len(files),bytes=sum(p.stat().st_size for p in files),inventory=[dict(path=p.relative_to(build).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files]))
write('source-identity.json',dict(branch=git('branch','--show-current'),correction_baseline=BASE,qualified_unity_source=SOURCE,unity_input_trees={p:git('rev-parse',SOURCE+':'+p) for p in ('Assets','Packages','ProjectSettings','ContentAuthoring')},b1_fixture_sha256=sha(ROOT/'Assets/_Project/Tests/EditMode/combat-c0-b1-golden.zip')))
write('changed-files.json',git('diff',BASE,SOURCE,'--name-only').splitlines())
with zipfile.ZipFile(OUT/'qualification-support.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(LOCAL.iterdir()):
  if p.is_file(): z.write(p,p.name)
 for p in sorted((ROOT/'Temp').glob('combat-c1-death-*.log')): z.writestr('logs/'+p.name,redact(p.read_text(encoding='utf-8-sig',errors='replace')))
print(len(reports),'reports;',len(screens),'screenshots;',len(rows),'preserved files;',len(files),'build files')

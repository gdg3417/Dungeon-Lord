from pathlib import Path
import hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as E
ROOT=Path.cwd(); LOCAL=ROOT/'TestResults/combat-c1-rpg'; OUT=ROOT/'Docs/testing/evidence/combat-c1/rpg-20261016'; OUT.mkdir(exist_ok=True)
SOURCE='9edf3cf7d0db96e94c53e3e470809cad83d38b3a'
BASE='cce2e365ff47ece4f0db80330c2475174774d0b0'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a): return subprocess.check_output(['git',*a],text=True).strip()
def write(n,v): (OUT/n).write_text(json.dumps(v,indent=2),encoding='utf-8')
def redact(s):
 s=re.sub(r'(?i)([-/][A-Za-z_-]*(?:token|password|serial)(?:\s+|=))(?:(?:"[^"]*")|(?:\S+))',r'\1[REDACTED]',s)
 s=re.sub(r'(?i)(Bearer\s+)[A-Za-z0-9._~-]+',r'\1[REDACTED]',s)
 return re.sub(r'(?i)((?:access token|Machine Id|Id):?\s+)[^\r\n]+',r'\1[REDACTED]',s)
reports=[]
with zipfile.ZipFile(OUT/'qualification-reports.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((ROOT/'TestResults').glob('combat-c1-rpg-*.xml')):
  r=E.parse(p).getroot(); z.write(p,p.name)
  reports.append(dict(file=p.name,sha256=sha(p),attributes=r.attrib,failures=[dict(name=c.get('fullname'),message=c.findtext('failure/message'),stack=c.findtext('failure/stack-trace')) for c in r.iter('test-case') if c.get('result')=='Failed'],skips=[dict(name=c.get('fullname'),reason=c.findtext('reason/message')) for c in r.iter('test-case') if c.get('result') in ('Skipped','Inconclusive')]))
write('report-summary.json',reports)
final={}
for mode,name,source in [('editmode','editmode-final',SOURCE),('playmode','playmode-final',SOURCE)]:
 r=E.parse(ROOT/('TestResults/combat-c1-rpg-'+name+'.xml')).getroot()
 if r.get('failed')!='0' or r.get('skipped')!='0': raise ValueError('Final affected set not green')
 final[mode]=dict(source=source,passed=int(r.get('passed')),failed=0,skipped=0,cases=[c.get('fullname') for c in r.iter('test-case')])
if git('diff',SOURCE,'HEAD','--name-only','--','Assets','Packages','ProjectSettings','ContentAuthoring'): raise ValueError('Unqualified Unity changes')
write('qualification-applicability.json',dict(final_affected=final,explanation='Both final affected sets and final Windows build use the same frozen Unity inputs. The earlier 171-case attempt passed 170 and failed only a pooled-row visibility assertion; a nine-scene follow-up passed after a test-only correction. Later visual inspection exposed long-name HP clipping, requiring separate name/HP rendering, stronger visible-bounds tests and C0 trap class wording. Four focused scenes and both affected sets were rerun for that final runtime. The first successful RPG build at 5a5c7c3 became obsolete and remains preserved. Earlier full suites retain their original source applicability; failures remain preserved.',windows_build_attempts=2,superseded_build_source='5a5c7c30ca6b525b3fbad5db956c82bed47f497c'))
rows=json.loads((LOCAL/'preservation-after.json').read_text())
if len(rows)!=966 or any(not r['equal'] for r in rows): raise ValueError('Protected bytes changed')
write('preservation-summary.json',dict(files=len(rows),changed=0,saves_restored=False,owner_and_primary=[r for r in rows if Path(r['path']).name in ('save_primary.json','combat-c0-diagnostics-validation-20261015.json')],complete_inventory='qualification-support.zip: preservation-before.json and preservation-after.json'))
extra=json.loads((LOCAL/'superseded-build-after.json').read_text())
if any(not r['equal'] for r in extra): raise ValueError('Superseded build changed')
write('superseded-build-preservation.json',dict(source='5a5c7c30ca6b525b3fbad5db956c82bed47f497c',files=len(extra),changed=0,inventory=extra))
checks=[]
for p in sorted(LOCAL.glob('*-exact.json')):
 r=json.loads(p.read_text()); ok=not r['failures'] and not r['unexpected']
 if not ok and p.name!='inputs-focused04-exact.json': raise ValueError('Unresolved input mismatch: '+p.name)
 checks.append(dict(file=p.name,sha256=sha(p),expected=r['expected_count'],actual=r['actual_count'],failures=r['failures'],status='exact' if ok else 'superseded: final two source edits overlapped checkpoint; refreshed-final-source and final suites qualify the committed inputs'))
write('input-checkpoints.json',checks)
screens=sorted((ROOT/'Temp/ui-composition-combat-c0-diagnostics-validation-r2/TestResults/phase7a4-screenshots').glob('composition-combat-c1-rpg-*.png'))
with zipfile.ZipFile(OUT/'screenshots.zip','w',zipfile.ZIP_STORED) as z:
 for p in screens: z.write(p,p.name)
write('screenshots.json',[dict(file=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in screens])
for suffix in ('attack-Default-1920x1080.png','attack-Large-720x1280.png','corridor-1920x1080.png','monster-defeat-720x1280.png','localized-long-720x1280.png'):
 matches=[p for p in screens if p.name.endswith(suffix)]
 if len(matches)!=1: raise ValueError('Representative screenshot missing: '+suffix)
 (OUT/matches[0].name).write_bytes(matches[0].read_bytes())
build=ROOT/'Temp/ui-composition-combat-c0-diagnostics-validation-warm/Builds/Development/Windows-combat-c1-rpg-final-20261016'
report=json.loads((build/'build-report.json').read_text()); namespace='combat-c0-diagnostics-validation-20261015.json'
if report['buildResult']!='Succeeded' or report['errorCount'] or not report['developmentBuild']: raise ValueError('Build failed')
if namespace.encode() not in (build/'Dungeon Lord_Data/sharedassets0.assets').read_bytes(): raise ValueError('Namespace missing')
art=(build/'packed-dungeon-art.txt').read_text().splitlines()
if len(art)!=52: raise ValueError('Packed artwork changed')
files=sorted(p for p in build.rglob('*') if p.is_file())
with zipfile.ZipFile(OUT/'build-reports-original.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ('build-report.json','build-messages.txt','packed-dungeon-art.txt','packed-source-assets.txt'): z.write(build/name,name)
 old=build.parent/'Windows-combat-c1-rpg-20261016'
 for name in ('build-report.json','build-messages.txt','packed-dungeon-art.txt','packed-source-assets.txt'): z.write(old/name,'superseded/'+name)
write('windows-artifact-manifest.json',dict(report=report,executable=str(build/'Dungeon Lord.exe'),namespace=namespace,namespace_packed=True,packed_art_count=len(art),player_launched=False,files=len(files),bytes=sum(p.stat().st_size for p in files),inventory=[dict(path=p.relative_to(build).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files]))
write('source-identity.json',dict(branch=git('branch','--show-current'),correction_baseline=BASE,qualified_unity_source=SOURCE,unity_input_trees={p:git('rev-parse',SOURCE+':'+p) for p in ('Assets','Packages','ProjectSettings','ContentAuthoring')},b1_fixture_sha256=sha(ROOT/'Assets/_Project/Tests/EditMode/combat-c0-b1-golden.zip')))
write('changed-files.json',git('diff',BASE,SOURCE,'--name-only').splitlines())
with zipfile.ZipFile(OUT/'qualification-support.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(LOCAL.iterdir()):
  if p.is_file(): z.write(p,p.name)
 for p in sorted((ROOT/'Temp').glob('combat-c1-rpg-*.log')): z.writestr('logs/'+p.name,redact(p.read_text(encoding='utf-8-sig',errors='replace')))
print(len(reports),'reports;',len(screens),'screenshots;',len(rows),'preserved files;',len(files),'build files')

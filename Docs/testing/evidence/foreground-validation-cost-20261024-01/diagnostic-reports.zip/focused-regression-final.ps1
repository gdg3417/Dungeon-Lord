$twoFloorPrefix = 'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonTwoFloor.'
$twoFloorMethods = @(
 'AuthoredTimingAndFrozenEventIdentitiesRemainExplicit',
 'BlockReleaseAndTransferReplayRetainSourceUntilCompletionWithoutCombatWork',
 'LifetimeAssuranceUsesAuthenticExitOrDescentAndFitsAllPrefixes',
 'HistoricalGoldenRestoresAndReencodesExactPinnedBytes',
 'InspectionReusePreservesOriginalFoldAndCheckpointAtEveryPrefix',
 'SelfConsistentReleaseWithoutVacancyCannotPublishThroughSession',
 'EmptyProjectionAndStaleLineageCannotAuthorizeRelease',
 'CompletedForgedReleaseCannotRetireItsBlockerOrBypassVacancyPermit',
 'FailedReleaseTransactionPublishesNoSettlementOrTransferAndRetryIsExactlyOnce',
 'EqualTimeOrdinaryTransferAndBlockedReleaseRespectSequenceAndRecoveryPhases',
 'CorruptFormatThreeReturnsFailureWithoutThrowingOrPublishing',
 'TerminalPrefixOnlyFitsAnUnclosedV2Boundary',
 'OverlappingSnapshotsPreservePriorDamageAndPartialRecoveryAtBothSettlements',
 'UnprovenWaitingReleaseRollbackRequiresRecoveryWithoutPublishingEitherParty',
 'WaitingReleaseIsEquivalentAcrossForegroundPartitionsAndReopen',
 'OneBoundaryPumpsAndReopenMatchTheSameAcceptedTwoPartyHorizon',
 'ReopenOneUnitBeforeVacancyAndImmediatelyAfterReleasePreservesExactPrefixes',
 'HistoricalV1DrainsOnceAndUpgradesWithoutEligibility'
)
$writePrefix = 'DungeonBuilder.M0.Editor.Tests.PhaseFourWrites.'
$writeMethods = @(
 'SuccessfulWritePersistsExactCompleteBytesThenPublishesRuntime',
 'RecognizedStateOnlySaveKeepsCanonicalAndUnknownEvidence',
 'RecognizedStateSavePersistsExplicitNullableClearsAndReopensThemAsNull',
 'StaleSuppliedStateCannotOverrideSessionAuthority',
 'FailedStagingWriteLeavesDiskAndRuntimeUnpublished',
 'FailedReplaceOrDurabilityRestoresOldDiskAndPublishesNothing',
 'RestoreFailureReturnsRecoveryRequiredNotOrdinaryAtomicFailure'
)
$diagnosticFilters = @('DungeonBuilder.M0.Editor.Tests.ForegroundPerformance', 'DungeonBuilder.M0.Editor.Tests.PhaseFourSessions')
$diagnosticFilters += $twoFloorMethods | ForEach-Object { $twoFloorPrefix + $_ }
$diagnosticFilters += $writeMethods | ForEach-Object { $writePrefix + $_ }
$diagnosticFilter = $diagnosticFilters -join ';'
$diagnosticFilter | Set-Content -LiteralPath TestResults/foreground-validation-cost-20261024-01/focused-regression-filter.txt
& C:/Users/gdg34/AppData/Local/Unity/bin/unity.exe test C:/Dev/Dungeon-Lord --mode EditMode --filter $diagnosticFilter --output TestResults/foreground-validation-cost-20261024-01/focused-regression-final.xml --timeout 1800 --no-color -- -logFile TestResults/foreground-validation-cost-20261024-01/focused-regression-final.log
exit $LASTEXITCODE

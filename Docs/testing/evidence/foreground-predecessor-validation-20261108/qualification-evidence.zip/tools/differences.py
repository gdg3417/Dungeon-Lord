"""Enumerate exact synthetic seed/final-save differences without rewriting either artifact."""
import json
from pathlib import Path
import sys

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def differences(left, right, path='$'):
    if type(left) is not type(right): return [{'path': path, 'main': left, 'pr': right}]
    if isinstance(left, dict):
        result = []
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right: result.append({'path': path + '.' + key, 'main': left.get(key), 'pr': right.get(key)})
            else: result.extend(differences(left[key], right[key], path + '.' + key))
        return result
    if isinstance(left, list):
        if len(left) != len(right): return [{'path': path, 'main_length': len(left), 'pr_length': len(right)}]
        return [item for i, pair in enumerate(zip(left, right)) for item in differences(*pair, path + '[' + str(i) + ']')]
    return [] if left == right else [{'path': path, 'main': left, 'pr': right}]

if __name__ == '__main__':
    analysis = read(sys.argv[1]); output = Path(sys.argv[2]); assert not output.exists()
    result = {}
    for variant, data in analysis.items():
        a, b = Path(data['main']['path']), Path(data['pr']['path'])
        seed_a, = a.parent.glob(variant + '-*.save.json')
        seed_b, = b.parent.glob(variant + '-*.save.json')
        result[variant] = {'seed': differences(read(seed_a), read(seed_b)),
            'final_save': differences(read(data['comparability']['main_final_save_path']), read(data['comparability']['pr_final_save_path']))}
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

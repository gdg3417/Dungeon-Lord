"""Separate exact restoration for a normally FAILED, fully completed campaign."""
import json
from pathlib import Path
import sys

source, destination = map(Path, sys.argv[1:3])
assert not destination.exists()
data = json.loads(source.read_text())
names = ('restore-preflight', 'restore', 'preservation')
data['stages'] = [stage for stage in data['stages'] if stage['id'] in names]
assert [stage['id'] for stage in data['stages']] == list(names)
data['stages'][0]['depends'] = []
data['stages'][-1]['depends'] = list(names[:-1])
data['selections'] = {'preservation': list(names)}
data['approved_substitutions'].append('Separate preservation after the prior normally FAILED, verified-completed profile campaign. No Unity input changes occurred beyond the exact prepared settings. Original FAILED verdict and all failure artifacts remain unchanged; only archived settings are restored by the existing authority.')
destination.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

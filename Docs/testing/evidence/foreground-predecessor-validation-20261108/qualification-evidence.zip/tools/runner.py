"""Explicit focused fault/performance selections; unchanged qualification authorities."""
import argparse
import json
import os
from pathlib import Path
import sys
import zipfile

CONTROL = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(CONTROL / 'Tools/Presentation'))
import qualify_h1_f4 as q
import qualification_supervisor as supervisor

FAULT_FILTERS = (
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.ForegroundPredecessorValidation',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonB3B2.FailedTerminalPumpPublishesNothingAndProvenRollbackRetriesExactlyOnce',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonB3B2.RecoveryConditionChangesAreStagedBeforeAdmissionWhenDoubleWalletDebitRoundsAway',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonB3B2.UnprovenRollbackRequiresRecoveryAndDoesNotPublishTerminalEffects',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonTwoFloor.FailedReleaseTransactionPublishesNoSettlementOrTransferAndRetryIsExactlyOnce',
    'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.LivingDungeonTwoFloor.UnprovenWaitingReleaseRollbackRequiresRecoveryWithoutPublishingEitherParty',
    'DungeonBuilder.M0.EditorTools.Tests.H1F4RecoveryContract.CommittedSettlementWithInterruptedAcknowledgementResolvesWithoutAnotherGrant',
    'DungeonBuilder.M0.Editor.Tests.PhaseFourWrites.RollbackDeleteFailureAfterCandidateProofReturnsCandidateSuccessAndNextSaveSettlesEvidence',
)
PROFILE_FILTERS = tuple('DungeonBuilder.M0.Tests.LivingDungeonTwoFloorProductionProfileSceneTests.' + name for name in (
    'LivingDungeonSingleFloorFocusedFourRuns', 'LivingDungeonTwoFloorFocusedFourRuns'))

def prepare():
    q.win.assert_no_unity()
    if (PREP / 'inventory.json').exists() or SAVE.exists():
        raise ValueError('Require unused preparation/product/save identities')
    PREP.mkdir(exist_ok=True)
    q.write(PREP / 'protected.json', q.protected(SAVE))
    original = q.inventory(PROJECT)
    q.write(PREP / 'original-inputs.json', original)
    with zipfile.ZipFile(PREP / 'original-inputs.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name in original: archive.write(PROJECT / name, name)
    measured = 'Dungeon Lord B3B2 Smoke H1F4 20261027 ' + ATTEMPT
    path = PROJECT / q.SETTINGS[0]
    prepared = q.qualification_player_settings(path.read_bytes(), measured)
    old = ('  productName: ' + measured + '\n').encode()
    new = ('  productName: ' + PRODUCT + '\n').encode()
    if prepared.count(old) != 1: raise ValueError('Require exact product substitution')
    isolated = prepared.replace(old, new)
    if isolated.replace(new, old) != prepared: raise ValueError('Product substitution must be reversible')
    path.write_bytes(isolated)
    for name in q.SETTINGS[1:]:
        path = PROJECT / name
        path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n'))
    q.write(PREP / 'qualified-inputs.json', q.inventory(PROJECT))
    q.write(PREP / 'selection.json', {'filter': FILTER, 'expected_tests': COUNT, 'kind': KIND,
        'source_sha': supervisor.git(PROJECT, 'rev-parse', 'HEAD'),
        'completed_runs_per_profile': 4 if KIND == 'performance' else None})
    q.write(PREP / 'inventory.json', {'owner': 'Codex foreground predecessor validation task',
        'purpose': KIND, 'retention': 'preserve pending independent review', 'project': str(PROJECT),
        'preparation': str(PREP), 'product': PRODUCT, 'save': str(SAVE), 'build': None,
        'generated_project_paths': [str(PROJECT / name) for name in ('Library', 'Temp', 'Logs')],
        'generated_project_retention': 'Preserve; no cleanup or process termination authorized',
        'source_sha': supervisor.git(PROJECT, 'rev-parse', 'HEAD')})

def plan():
    q.plan(ATTEMPT)
    path = PREP / 'plan.json'
    data = json.loads(path.read_text())
    for stage in data['stages']:
        stage['id'] = stage['id'].replace('focused', 'living-regressions')
        stage['depends'] = [name.replace('focused', 'living-regressions') for name in stage['depends']]
        stage['command'][2] = str(Path(__file__).resolve())
        stage['command'] = [arg.replace('{campaign}/focused', '{campaign}/living-regressions') for arg in stage['command']]
        stage['command'] += ['--project', str(PROJECT), '--label', LABEL]
        if stage['role'] == 'test':
            stage['expected_tests'] = COUNT
            stage['timeout_seconds'] = 1800
            stage['artifacts'].append('fixture-inputs')
    data['selections'] = {KIND: [stage['id'] for stage in data['stages']]}
    data['tools'][str(Path(__file__).resolve())] = {'sha256': q.sha(__file__), 'version': 'Foreground predecessor explicit comparison adapter 1'}
    data['tools'][str(PREP / 'selection.json')] = {'sha256': q.sha(PREP / 'selection.json'), 'version': 'Explicit exact selection'}
    data['tools'][str(q.CLI)]['version'] = 'Unity CLI 1.0.0-beta.17 verified current'
    data['approved_substitutions'].append('Exact reversible short isolated product identity ' + PRODUCT + '. ' +
        ('27 directly affected cases only; no broad regression, player build or UAT.' if KIND == 'faults' else
         'Two explicit four-completion production scene profiles using identical diagnostic harness and fixed pre-ownership seed UTC. Existing 68-run defaults unchanged. No broad regression, Windows/player qualification or UAT.'))
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'plan': str(path), 'expected_tests': COUNT, 'source_sha': data['source_sha']}))

def run(stage):
    for name in ('DUNGEON_FOREGROUND_DIAGNOSTIC_OUTPUT_ROOT', 'DUNGEON_ADMISSION_BENCHMARK_ROOT'):
        if os.environ.get(name): raise ValueError('Optional exporter must be unset: ' + name)
    stage = Path(stage).resolve()
    command = [str(q.CLI), 'test', str(PROJECT), '--mode', 'EditMode', '--filter', FILTER,
        '--output', str(stage / 'results.xml'), '--timeout', '1700', '--no-color', '--', '-logFile', str(stage / 'unity.log')]
    return q.run_child(ATTEMPT, stage, command, 'living-regressions', 'cli-exit.json')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('prepare', 'plan', 'preflight', 'run-test', 'restore', 'finish'))
    parser.add_argument('--project', required=True)
    parser.add_argument('--label', required=True, choices=('faults', 'main', 'pr'))
    parser.add_argument('--attempt')
    parser.add_argument('--stage')
    args = parser.parse_args()
    PROJECT = Path(args.project).resolve()
    LABEL = args.label
    if not (PROJECT / 'AGENTS.md').is_file(): raise ValueError('Expected Dungeon Lord checkout')
    KIND = 'faults' if LABEL == 'faults' else 'performance'
    PREP = Path(__file__).resolve().parent / LABEL
    ATTEMPT = 'predecessor-' + LABEL + '-01'
    PRODUCT = 'Dungeon Lord B3B2 Smoke H1F4 FGP' + {'faults': 'F', 'main': 'M', 'pr': 'P'}[LABEL]
    SAVE = Path.home() / 'AppData/LocalLow/gdg3417' / PRODUCT
    FILTER = ';'.join(FAULT_FILTERS if KIND == 'faults' else PROFILE_FILTERS)
    COUNT = 27 if KIND == 'faults' else 2
    q.ROOT = PROJECT
    q.identities = lambda attempt: (PREP, PRODUCT, SAVE)
    if args.mode == 'prepare': prepare()
    elif args.mode == 'plan': plan()
    elif args.mode == 'preflight': q.preflight(ATTEMPT, args.stage)
    elif args.mode == 'run-test': sys.exit(run(args.stage))
    elif args.mode == 'restore': q.restore(ATTEMPT, args.stage)
    elif args.mode == 'finish': q.preflight(ATTEMPT, args.stage, restored=True)

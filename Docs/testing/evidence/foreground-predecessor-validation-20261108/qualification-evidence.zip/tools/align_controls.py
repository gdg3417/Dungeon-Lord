"""Align owned baseline checkout bytes to PR controls; preserve originals and require EOL-only differences."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path('C:/Dev/Dungeon-Lord')
BASE = Path('C:/Users/gdg34/.codex/worktrees/fgpv-main/Dungeon-Lord')
CONTROL = ROOT / 'TestResults/foreground-predecessor-comparison-20261108'
sys.path.insert(0, str(ROOT / 'Tools/Presentation'))
import qualify_h1_f4 as q

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(data): return hashlib.sha256(data).hexdigest()

q.win.assert_no_unity()
original = read(CONTROL / 'main2/original-inputs.json')
target = read(CONTROL / 'pr/original-inputs.json')
assert q.inventory(BASE) == original, 'Exact restored baseline required'
names = sorted(name for name in original if name.startswith(('Assets/_Project/Data/', 'Assets/_Project/Resources/', 'Packages/', 'ContentAuthoring/'))
    and original[name] != target.get(name))
assert len(names) == 10, names
report = CONTROL / 'raw-control-alignment.json'
archive = CONTROL / 'raw-control-alignment-before.zip'
assert not report.exists() and not archive.exists()
rows = []
for name in names:
    before, after = (BASE / name).read_bytes(), (ROOT / name).read_bytes()
    assert sha(before) == original[name] and sha(after) == target[name]
    assert before.replace(b'\r\n', b'\n') == after.replace(b'\r\n', b'\n'), 'Only preflight-proven CRLF/LF differences allowed'
    rows.append({'path': name, 'before_sha256': sha(before), 'after_sha256': sha(after), 'change': 'exact PR checkout bytes; only CRLF/LF differences, including its preserved terminal CRLF; parsed values unchanged'})
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as saved:
    for name in names: saved.write(BASE / name, name)
for name in names: (BASE / name).write_bytes((ROOT / name).read_bytes())
expected = dict(original)
for name in names: expected[name] = target[name]
assert q.inventory(BASE) == expected
report.write_text(json.dumps({'owner': 'Codex foreground predecessor task', 'project': str(BASE), 'source': str(ROOT),
    'purpose': 'Exact raw control-input alignment before matched baseline qualification', 'retention': 'Preserve all old campaigns, inputs and this archive',
    'before_archive': str(archive), 'paths': rows, 'only_changes_are_the_ten_verified_EOL_differences': True}, indent=2) + '\n')
print(json.dumps({'aligned': len(rows), 'report': str(report), 'archive': str(archive)}))

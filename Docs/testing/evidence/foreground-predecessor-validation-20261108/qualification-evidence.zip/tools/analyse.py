"""Offline analysis only; preserve raw profiles and compare every frame without alignment."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dist(values):
    values = sorted(values)
    return {'mean': statistics.mean(values), 'p95': values[int((len(values)-1)*.95)], 'max': values[-1]}

def summarize(path):
    data = read(path)
    assert data['Passed'] and data['CompletedRuns'] == 4, str(path)
    frames = data['Frames']
    groups = {'all': frames, 'work': [f for f in frames if f['Category'] in ('admission', 'event', 'settlement', 'passive')]}
    groups.update({k: [f for f in frames if f['Category'] == k] for k in sorted({f['Category'] for f in frames})})
    thread = data['ThreadAllocationCounterAvailable']
    allocation = data['FrameAllocationCounterAvailable'] and any(f['FrameAllocatedBytes'] > 0 for f in frames)
    result = {'path': str(path), 'sha256': sha(path), 'completed': data['CompletedRuns'], 'frames': len(frames),
        'dimensions': [data['ScreenWidth'], data['ScreenHeight'], data['TextSize']],
        'prior_validation_calls': data['PriorValidationCalls'], 'complete_validation_calls': data['CompleteValidationCalls'],
        'durable_semantic_readback_calls': data['SemanticReadbackCalls'],
        'areas': {name: {'calls': sum(f['Calls'][i] for f in frames),
            'inclusive_ms': sum(f['Ticks'][i] for f in frames) * 1000 / data['StopwatchFrequency']}
            for i, name in enumerate(data['Areas'])},
        'thread_allocation_supported': thread, 'frame_allocation_responsive': allocation,
        'natural_gc_increments': sum(max(0, b['Collections']-a['Collections']) for a, b in zip(frames, frames[1:])),
        'managed_heap_peak_bytes': max(f['ManagedBytes'] for f in frames), 'categories': {}}
    for key, rows in groups.items():
        if rows:
            result['categories'][key] = {'count': len(rows), 'frame_ms': dist([r['FrameMs'] for r in rows]),
                'update_ms': dist([r['UpdateMs'] for r in rows]),
                'frame_allocated_bytes': dist([r['FrameAllocatedBytes'] for r in rows]) if allocation else None,
                'update_allocated_bytes': dist([r['Allocated'] for r in rows]) if thread else None}
    return data, result

def compare(main, pr, variant):
    a, left = summarize(main)
    b, right = summarize(pr)
    keys = ('Frame', 'Sequence', 'Ordinal', 'Category', 'PartyCount', 'CheckpointBytes')
    signatures = lambda data: [tuple(frame[key] for key in keys) for frame in data['Frames']]
    sa, sb = signatures(a), signatures(b)
    seed_a = list(main.parent.glob(variant + '-*.save.json'))
    seed_b = list(pr.parent.glob(variant + '-*.save.json'))
    assert len(seed_a) == len(seed_b) == 1
    assert read(seed_a[0])['primary']['lastSavedUtcUnix'] == 1794000000
    assert read(seed_b[0])['primary']['lastSavedUtcUnix'] == 1794000000
    save_a, save_b = Path(a['SavePath']), Path(b['SavePath'])
    mismatches = [{'index': i, 'main': x, 'pr': y} for i, (x, y) in enumerate(zip(sa, sb)) if x != y]
    result = {'main': left, 'pr': right, 'comparability': {
        'signature_keys': keys, 'exact_entire_frame_workload_equal': sa == sb,
        'mismatches': len(mismatches), 'first_mismatches': mismatches[:5],
        'main_seed_sha256': sha(seed_a[0]), 'pr_seed_sha256': sha(seed_b[0]),
        'exact_seed_bytes_equal': seed_a[0].read_bytes() == seed_b[0].read_bytes(),
        'same_dimensions': left['dimensions'] == right['dimensions'], 'same_area_order': a['Areas'] == b['Areas'],
        'main_final_save_path': str(save_a), 'pr_final_save_path': str(save_b),
        'main_final_save_sha256': sha(save_a), 'pr_final_save_sha256': sha(save_b),
        'exact_final_save_bytes_equal': save_a.read_bytes() == save_b.read_bytes(),
        'same_stage_count': left['areas']['Stage']['calls'] == right['areas']['Stage']['calls'],
        'same_write_count': left['areas']['AtomicWrite']['calls'] == right['areas']['AtomicWrite']['calls'],
        'same_readback_count': left['durable_semantic_readback_calls'] == right['durable_semantic_readback_calls']},
        'limitations': ['Four completions per profile, one ordered campaign per source on the same host; no statistical or platform qualification.',
            'Full Editor frame includes UI/render/scheduling. Inclusive Stage/Prepare/AtomicWrite scopes overlap and are not summed.',
            'Natural GC and frame allocations are whole-Editor observations. The existing frame recorder has no isolated live-allocation calibration.',
            'Thread allocation must pass its live calibration; unsupported is not zero. Global managed heap is not an isolated retained-state budget.']}
    return result

if __name__ == '__main__':
    main, pr, destination = map(Path, sys.argv[1:4])
    assert not destination.exists(), 'Preserve previous analysis'
    result = {}
    for variant in ('owner-inactive', 'two-floor'):
        left = list(main.glob('living-regressions/fixture-inputs/two-floor/*/editor-' + variant + '.profile.json'))
        right = list(pr.glob('living-regressions/fixture-inputs/two-floor/*/editor-' + variant + '.profile.json'))
        assert len(left) == len(right) == 1, (variant, left, right)
        result[variant] = compare(left[0], right[0], variant)
    destination.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: {'comparability': v['comparability'], 'main_work_frame_ms': v['main']['categories']['work']['frame_ms'],
        'pr_work_frame_ms': v['pr']['categories']['work']['frame_ms']} for k, v in result.items()}, indent=2))

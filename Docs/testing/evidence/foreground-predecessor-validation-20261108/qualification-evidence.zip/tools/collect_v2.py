"""Retain sanitized receipts and synthetic profile evidence, never raw Unity/auth logs."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('C:/Dev/Dungeon-Lord')
CONTROL = ROOT / 'TestResults/foreground-predecessor-comparison-20261108'
LONG = Path('C:/Users/gdg34/.codex/worktrees/foreground-predecessor-baseline/Dungeon-Lord')
SHORT = Path('C:/Users/gdg34/.codex/worktrees/fgpv-main/Dungeon-Lord')
OUT = ROOT / 'Docs/testing/evidence/foreground-predecessor-validation-20261108'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def collect(focused, pr, matched):
    assert not OUT.exists(), 'Preserve existing evidence'
    campaigns = {
        'initial-15': ROOT / 'TestResults/qualification-supervisor/b0312f18e857458e87593dbe62b4919c',
        'faults-27': ROOT / 'TestResults/qualification-supervisor/5fa7899129d34d8e8671827236ccfe85',
        'failed-baseline-path-limit': LONG / 'TestResults/qualification-supervisor/1ab9bbdba8a7485eb4246a9df23617bd',
        'failed-baseline-exact-restoration': LONG / 'TestResults/qualification-supervisor/60352a706881473b81bdff2b20ba846c',
        'baseline-with-EOL-mismatch': SHORT / 'TestResults/qualification-supervisor/353693297e044a439f6f1499cf19f64a',
        'baseline-performance': matched,
        'final-focused': focused, 'pr-performance': pr,
    }
    summaries = {}
    unique = set()
    for name, path in campaigns.items():
        state = read(path / 'campaign.json')
        expected = 'FAILED' if name == 'failed-baseline-path-limit' else 'PASSED'
        assert state['status'] == expected, (name, state['status'])
        xml_path = path / 'living-regressions/results.xml'
        cases = []
        if xml_path.exists():
            xml = ET.parse(xml_path).getroot()
            cases = [{'name': node.get('fullname'), 'result': node.get('result'), 'duration': float(node.get('duration', 0))}
                for node in xml.iter('test-case')]
            if name in ('initial-15', 'faults-27', 'final-focused'): unique.update(c['name'] for c in cases)
        summaries[name] = {'campaign': str(path), 'id': path.name, 'recorded_status': state['status'],
            'source_sha': state['source_sha'], 'cases': cases, 'case_count': len(cases),
            'xml_sha256': sha(xml_path) if xml_path.exists() else None,
            'preservation_receipt': str(path / 'preservation/preservation.json') if expected == 'PASSED' else None}
    assert len(unique) == 31
    OUT.mkdir(parents=True)
    with zipfile.ZipFile(OUT / 'qualification-evidence.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name, path in campaigns.items():
            archive.write(path / 'campaign.json', name + '/campaign.json')
            for stage in read(path / 'campaign.json')['selected']:
                for filename in ('result.json', 'preservation.json', 'restoration.json', 'results.xml'):
                    source = path / stage / filename
                    if source.exists(): archive.write(source, name + '/' + stage + '/' + filename)
        for source in (CONTROL / 'runner.py', CONTROL / 'runner_v2.py', CONTROL / 'runner_v3.py',
            CONTROL / 'align_controls.py', CONTROL / 'align_controls_attempt1.py', CONTROL / 'restore_plan.py',
            CONTROL / 'analyse.py', CONTROL / 'differences.py', Path(__file__),
            ROOT / 'TestResults/foreground-predecessor-20261108-01/campaign.py'):
            archive.write(source, 'tools/' + source.name)
    with zipfile.ZipFile(OUT / 'raw-profiles.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for label, path in (('main-with-EOL-mismatch', campaigns['baseline-with-EOL-mismatch']),
            ('main', campaigns['baseline-performance']), ('pr', pr)):
            for profile in sorted(path.glob('living-regressions/fixture-inputs/two-floor/*/*.profile.json')):
                data = read(profile)
                variant = 'owner-inactive' if profile.name == 'editor-owner-inactive.profile.json' else 'two-floor'
                archive.write(profile, label + '/' + variant + '/profile.json')
                for seed in profile.parent.glob(variant + '-*.save.json'):
                    archive.write(seed, label + '/' + variant + '/seed.json')
                archive.write(Path(data['SavePath']), label + '/' + variant + '/final-save.json')
    shutil.copyfile(CONTROL / 'matched-comparison.json', OUT / 'comparison.json')
    shutil.copyfile(CONTROL / 'comparison.json', OUT / 'unmatched-comparison.json')
    shutil.copyfile(CONTROL / 'save-differences.json', OUT / 'unmatched-save-differences.json')
    shutil.copyfile(CONTROL / 'raw-control-alignment.json', OUT / 'raw-control-alignment.json')
    main_inputs = read(CONTROL / 'main3/original-inputs.json')
    pr_inputs = read(CONTROL / 'pr/original-inputs.json')
    harness = ('Assets/_Project/Scripts/Core/GameRoot.ForegroundProfile.cs',
        'Assets/_Project/Tests/EditMode/LivingDungeonTwoFloorTests.cs',
        'Assets/_Project/Editor/DungeonSpatial/Tests/LivingDungeonTwoFloorProductionProfileSceneTests.cs')
    controls = sorted(name for name in main_inputs if name.startswith(('Assets/_Project/Data/', 'Assets/_Project/Resources/', 'Packages/', 'ContentAuthoring/'))
        or name in harness)
    assert all(main_inputs[name] == pr_inputs.get(name) for name in controls)
    scene = 'Assets/_Project/Scenes/Bootstrap.unity'
    a, b = (SHORT / scene).read_bytes(), (ROOT / scene).read_bytes()
    assert hashlib.sha256(a).hexdigest() == main_inputs[scene] and hashlib.sha256(b).hexdigest() == pr_inputs[scene]
    assert a.replace(b'\r\n', b'\n') == b.replace(b'\r\n', b'\n')
    scene_blob_a = subprocess.check_output(['git', 'show', summaries['baseline-performance']['source_sha'] + ':' + scene], cwd=ROOT)
    scene_blob_b = subprocess.check_output(['git', 'show', summaries['pr-performance']['source_sha'] + ':' + scene], cwd=ROOT)
    assert scene_blob_a == scene_blob_b
    scene_proof = {'path': scene, 'main_raw_sha256': main_inputs[scene], 'pr_raw_sha256': pr_inputs[scene],
        'raw_bytes_equal': a == b, 'only_CRLF_LF_checkout_difference': True,
        'identical_git_blob_sha256': hashlib.sha256(scene_blob_a).hexdigest(),
        'explanation': 'Scene YAML has an explicitly retained checkout line-ending difference. Its Git blob and serialized values are unchanged. No raw profile, save, timestamp or gameplay field is normalized.'}
    ledger = []
    for name, path in campaigns.items():
        ledger.append({'path': str(path), 'owner': 'Qualification supervisor / Codex foreground predecessor task',
            'purpose': name, 'retention': 'preserve evidence and failure state; no cleanup eligible'})
    for label in ('faults', 'main', 'faults2', 'main2', 'main3', 'pr'):
        inventory = read(CONTROL / label / 'inventory.json')
        for key in ('preparation', 'save'):
            ledger.append({'path': inventory[key], 'owner': inventory['owner'], 'purpose': label + ' ' + key,
                'retention': 'preserve pending independent review'})
    ledger.extend({'path': str(path), 'owner': 'Codex foreground predecessor task', 'purpose': purpose,
        'retention': 'preserve; evidence/review dependency'} for path, purpose in (
            (LONG, 'Restored failed path-length reproduction'), (SHORT, 'Qualified bounded baseline checkout'),
            (ROOT / 'TestResults/foreground-predecessor-20261108-01', 'Initial preparation, original inputs and tool'),
            (Path('C:/Users/gdg34/AppData/LocalLow/gdg3417/Dungeon Lord B3B2 Smoke H1F4 20261027 foreground-predecessor-01'), 'Initial isolated test namespace'),
            (CONTROL, 'Local adapters, original input archives, reports and analysis'),
            (CONTROL / 'partial-evidence', 'Preserved first collector output before explicit scene EOL proof'), (OUT, 'Sanitized retained evidence')))
    report = {'baseline_main': '01ff418143c0400d8e6fafba7a260f399bcdb2aa', 'pr': 'https://github.com/gdg3417/Dungeon-Lord/pull/261',
        'campaigns': summaries, 'unique_focused_test_cases': len(unique),
        'identical_control_input_count': len(controls), 'identical_control_inputs': {name: main_inputs[name] for name in controls},
        'bootstrap_scene_checkout_proof': scene_proof,
        'artifacts': {name: {'sha256': sha(OUT / name), 'bytes': (OUT / name).stat().st_size}
            for name in ('qualification-evidence.zip', 'raw-profiles.zip', 'comparison.json',
                'unmatched-comparison.json', 'unmatched-save-differences.json', 'raw-control-alignment.json')},
        'artifact_ledger': ledger,
        'scope': 'Focused Unit/SIT and bounded Editor frame comparison only. No broad suites, Windows player qualification, UAT or merge.',
        'historical_preservation': 'PR #260 and its original ledgers, commits, failed campaigns and worktrees are unchanged. No owner save, build or unrelated process was changed/deleted/terminated.'}
    (OUT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'output': str(OUT), 'unique_focused_cases': len(unique), 'matched_controls': len(controls)}))

if __name__ == '__main__': collect(*map(Path, sys.argv[1:4]))

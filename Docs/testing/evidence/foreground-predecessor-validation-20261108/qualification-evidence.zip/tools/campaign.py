"""Focused predecessor validation gate using unchanged H1-F4 preservation authorities."""
import argparse
import json
import os
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'Tools/Presentation'))
import qualify_h1_f4 as q
import qualification_supervisor as supervisor

PREP = Path(__file__).resolve().parent
ATTEMPT = 'foreground-predecessor-01'
PRODUCT = 'Dungeon Lord B3B2 Smoke H1F4 20261027 ' + ATTEMPT
SAVE = Path.home() / 'AppData/LocalLow/gdg3417' / PRODUCT
q.identities = lambda attempt: (PREP, PRODUCT, SAVE)
FILTER = 'DungeonBuilder.M0.EditorTools.DungeonSpatial.Tests.ForegroundPredecessorValidation'

def prepare():
    q.win.assert_no_unity()
    if (PREP / 'inventory.json').exists() or SAVE.exists():
        raise ValueError('Unused preparation and product/save identities required')
    q.write(PREP / 'protected.json', q.protected(SAVE))
    original = q.inventory(ROOT)
    q.write(PREP / 'original-inputs.json', original)
    with zipfile.ZipFile(PREP / 'original-inputs.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
        for name in original:
            archive.write(ROOT / name, name)
    path = ROOT / q.SETTINGS[0]
    path.write_bytes(q.qualification_player_settings(path.read_bytes(), PRODUCT))
    for name in q.SETTINGS[1:]:
        path = ROOT / name
        path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n'))
    q.write(PREP / 'qualified-inputs.json', q.inventory(ROOT))
    q.write(PREP / 'inventory.json', {
        'owner': 'Codex foreground predecessor validation task', 'retention': 'preserve',
        'purpose': '15 focused exact-byte, validation-count and negative cases; no broad/platform qualification',
        'project': str(ROOT), 'preparation': str(PREP), 'product': PRODUCT, 'save': str(SAVE),
        'build': None, 'generated_project_paths': [str(ROOT / name) for name in ('Library', 'Temp', 'Logs')],
        'generated_project_retention': 'Preserve existing and generated state; no cleanup authorized',
        'source_sha': supervisor.git(ROOT, 'rev-parse', 'HEAD')})

def plan():
    q.plan(ATTEMPT)
    path = PREP / 'plan.json'
    data = json.loads(path.read_text())
    for stage in data['stages']:
        stage['id'] = stage['id'].replace('focused', 'living-regressions')
        stage['depends'] = [name.replace('focused', 'living-regressions') for name in stage['depends']]
        stage['command'][2] = str(Path(__file__).resolve())
        stage['command'] = [arg.replace('{campaign}/focused', '{campaign}/living-regressions') for arg in stage['command']]
        if stage['role'] == 'test':
            stage['expected_tests'] = 15
            stage['command'][3] = 'run-test'
            stage['artifacts'].append('fixture-inputs')
    data['selections'] = {'focused': [stage['id'] for stage in data['stages']]}
    data['tools'][str(Path(__file__).resolve())] = {'sha256': q.sha(__file__), 'version': 'Foreground predecessor focused adapter 1'}
    data['tools'][str(q.CLI)]['version'] = 'Unity CLI 1.0.0-beta.17 verified current'
    data['approved_substitutions'].append('Reuse current clean checkout with exact reversible settings preparation; 15 new focused cases only, isolated product/save and existing fixture exports. No historical adapter edits, worker, sustained profile, build or UAT.')
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'plan': str(path), 'tests': 15, 'filter': FILTER}))

def run(stage):
    for name in ('DUNGEON_FOREGROUND_DIAGNOSTIC_OUTPUT_ROOT', 'DUNGEON_ADMISSION_BENCHMARK_ROOT'):
        if os.environ.get(name):
            raise ValueError('Optional exporter must be unset: ' + name)
    stage = Path(stage).resolve()
    command = [str(q.CLI), 'test', str(ROOT), '--mode', 'EditMode', '--filter', FILTER,
        '--output', str(stage / 'results.xml'), '--timeout', '900', '--no-color', '--', '-logFile', str(stage / 'unity.log')]
    return q.run_child(ATTEMPT, stage, command, 'living-regressions', 'cli-exit.json')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('prepare', 'plan', 'preflight', 'run-test', 'restore', 'finish'))
    parser.add_argument('--attempt', default=ATTEMPT)
    parser.add_argument('--stage')
    args = parser.parse_args()
    if args.mode == 'prepare': prepare()
    elif args.mode == 'plan': plan()
    elif args.mode == 'preflight': q.preflight(ATTEMPT, args.stage)
    elif args.mode == 'run-test': sys.exit(run(args.stage))
    elif args.mode == 'restore': q.restore(ATTEMPT, args.stage)
    elif args.mode == 'finish': q.preflight(ATTEMPT, args.stage, restored=True)

"""This closeout only: read-only recovery search and before/after runner audit."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'Tools/Presentation'))
import qualify_b3a as q
import b3a_preservation_preflight as gate

OUT = Path(__file__).resolve().parent
def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024*1024): value.update(chunk)
    return value.hexdigest()
def write(name, value):
    with (OUT/name).open('x', encoding='utf-8') as stream: json.dump(value, stream, indent=2)
def command(args, **kwargs):
    run = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, encoding='utf-8', errors='replace', **kwargs)
    return dict(command=args, exitCode=run.returncode, stdout=run.stdout, stderr=run.stderr)
def snapshot():
    paths = set(ROOT/n for n in q.inputs.target_inventory(ROOT))
    for base in [ROOT/'TestResults', ROOT/'Builds', q.SAVE]:
        paths.update(p for p in base.rglob('*') if p.is_file() and OUT not in p.parents)
    return {str(p): sha(p) for p in sorted(paths)}

if sys.argv[1] == 'negative':
    before = snapshot()
    # Trace records executed PowerShell statements; the Unity invocation must
    # never appear as an executed statement, even if no Editor was running.
    shell = 'C:/Users/gdg34/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
    result = command([shell, '-NoProfile', '-Command',
        "Set-PSDebug -Trace 1; & Tools/Presentation/run_b3a_qualification.ps1 -Stage focused -Attempt safety-closeout-unused"])
    after = snapshot()
    new = sorted(after.keys()-before.keys())
    missing = sorted(before.keys()-after.keys())
    changed = [p for p in before.keys() & after.keys() if before[p] != after[p]]
    trace = result['stdout']+result['stderr']
    result.update(filesAudited=len(before), newFiles=new, removedFiles=missing, changedFiles=changed,
                  unityInvocationExecuted=('try { & $unity @cliArgs' in trace or '>>> & $unity' in trace),
                  actionableRejection='Isolation was restored/inactive' in trace)
    write('negative-runner.json', result)
    assert result['exitCode'] != 0 and result['actionableRejection']
    assert not new and not missing and not changed and not result['unityInvocationExecuted']
    print(json.dumps({k:v for k,v in result.items() if k not in ['stdout','stderr','command']}))
elif sys.argv[1] == 'tests':
    result = command([sys.executable, '-B', 'Tools/Presentation/test_b3a_preservation_preflight.py'])
    write('tooling-tests.json', result)
    print(result['stdout']+result['stderr'])
    sys.exit(result['exitCode'])
elif sys.argv[1] == 'audit':
    sources, baselines = gate.anchors(ROOT)
    assert all((q.OUT/n).read_bytes() == data for n,data in baselines.items())
    result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), baselineBytesMatchReviewedArchive=True)
    for key, rows in [('protected',json.loads(baselines['baseline.json'])['protected']),
                      ('historical',json.loads(baselines['historical-evidence-before.json']))]:
        checked = [dict(path=r['path'], expected=r['sha256'], actual=sha(Path(r['path'])) if Path(r['path']).is_file() else None) for r in rows]
        result[key] = dict(total=len(checked), equal=sum(r['expected']==r['actual'] for r in checked),
                           mismatches=[r for r in checked if r['expected']!=r['actual']])
    result['unityInputs'] = dict(total=len(sources), mismatches=[n for n,h in sources.items() if sha(ROOT/n)!=h])
    result['committedUnityDiffFromQualified'] = command(['git','diff','--name-only',gate.QUALIFIED,'HEAD','--',*q.inputs.INPUT_ROOTS])
    result['workingRuntimeTestsDiffFromQualified'] = command(['git','diff','--name-only',gate.QUALIFIED,'--',
        'Assets/_Project/Scripts','Assets/_Project/Tests','Assets/_Project/Editor','Packages','ContentAuthoring'])
    result['incidentArtifacts'] = [dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for p in
        [q.OUT/'historical-evidence-after-incident.zip',*(q.OUT/'overwritten-captures-before-repair').glob('*')]]
    write('preservation-audit.json',result)
    print(json.dumps({key:value for key,value in result.items() if key!='incidentArtifacts'}))
elif sys.argv[1] == 'search':
    missing = json.loads((q.OUT/'missing-original-screenshots.json').read_text())
    wanted = {r['sha256'] for r in missing}
    locations = [ROOT/'Docs',ROOT/'TestResults',Path('C:/Dev/Dungeon-Lord-Backups'),
        Path('M:/pre-PR223 Dungeon Lord'),Path('C:/Users/gdg34/Documents/Dungeon-Lord-Manual-UAT'),
        Path('C:/Users/gdg34/Dungeon Lord'),Path('C:/Users/gdg34/OneDrive/Documents/GitHub/Dungeon-Lord')]
    result = dict(locations=[],matches=[],unsupportedArchives=[],errors=[],pngFiles=0,zipFiles=0,archivedPngFiles=0,
                  restoreWrites=0,missingOriginals=missing,
                  windowsVersionHistory='Win32_ShadowCopy unavailable: CIM initialization failure even with approved read-only escalation; FileHistory configuration directory not present. No snapshots mounted or modified.')
    for base in locations:
        info = dict(path=str(base),exists=base.exists(),filesConsidered=0)
        result['locations'].append(info)
        for folder, dirs, files in os.walk(base, followlinks=False, onerror=lambda error:result['errors'].append(str(error))):
            dirs[:] = [n for n in dirs if n not in ['Library','.git','.vs','obj','node_modules'] and not (Path(folder)/n).is_symlink()]
            for name in files:
                path = Path(folder)/name
                if path == OUT/'recovery-search.json': continue
                suffix = path.suffix.lower()
                if suffix not in ['.png','.zip','.7z','.rar']: continue
                info['filesConsidered'] += 1
                try:
                    if path.is_symlink(): continue
                    # Do not hydrate offline cloud placeholders.
                    if getattr(path.stat(),'st_file_attributes',0) & 0x1000:
                        result['errors'].append('Offline placeholder not read: '+str(path)); continue
                    if suffix == '.png':
                        result['pngFiles'] += 1
                        digest = sha(path)
                        if digest in wanted: result['matches'].append(dict(source=str(path),sha256=digest))
                    elif suffix == '.zip':
                        result['zipFiles'] += 1
                        with zipfile.ZipFile(path) as archive:
                            for item in archive.infolist():
                                if not item.filename.lower().endswith('.png'): continue
                                result['archivedPngFiles'] += 1
                                with archive.open(item) as stream:
                                    value=hashlib.sha256()
                                    while chunk:=stream.read(1024*1024): value.update(chunk)
                                digest=value.hexdigest()
                                if digest in wanted: result['matches'].append(dict(source=str(path)+'#'+item.filename,sha256=digest))
                    else: result['unsupportedArchives'].append(str(path))
                except (OSError,zipfile.BadZipFile,RuntimeError) as error:
                    result['errors'].append(str(path)+': '+str(error))
    write('recovery-search.json',result)
    print(json.dumps(result))
else: raise ValueError(sys.argv[1])

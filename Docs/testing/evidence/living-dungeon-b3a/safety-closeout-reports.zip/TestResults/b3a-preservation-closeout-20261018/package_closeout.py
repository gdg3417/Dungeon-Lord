from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DEST = ROOT/'Docs/testing/evidence/living-dungeon-b3a'
QUALIFIED = 'b5502291e9da3d229bbcc3d152f8bd56954d84eb'
REVIEWED = '36da2f80ef31febbd01e63d8ee5c5ffa2fd38532'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((OUT/name).read_text())
def write(path, data):
    with path.open('x',encoding='utf-8') as stream: json.dump(data,stream,indent=2)

audit=read('preservation-audit.json'); negative=read('negative-runner.json'); tests=read('tooling-tests.json'); search=read('recovery-search.json')
assert negative['exitCode']==1 and negative['actionableRejection'] and not negative['unityInvocationExecuted']
assert not negative['newFiles'] and not negative['removedFiles'] and not negative['changedFiles']
assert tests['exitCode']==0 and 'Ran 24 tests' in tests['stderr'] and tests['stderr'].strip().endswith('OK')
assert audit['protected']['equal']==6839 and audit['historical']['equal']==1986
assert not audit['unityInputs']['mismatches'] and not audit['committedUnityDiffFromQualified']['stdout'] and not audit['workingRuntimeTestsDiffFromQualified']['stdout']
assert not search['matches'] and search['restoreWrites']==0
previous=json.loads((ROOT/'TestResults/living-dungeon-b3a-20261017/screenshot-repair.json').read_text())
restored=[]
for row in previous:
    if row['restored']:
        current=sha(Path(row['path'])); independent=sha(Path(row['source']))
        assert current==independent==row['sha256']
        restored.append(dict(**row,currentSha256=current,independentCopySha256=independent,reverified=True,newRestoration=False))
if (OUT/'previous-restorations-reverified.json').exists():
    assert read('previous-restorations-reverified.json')==restored
else: write(OUT/'previous-restorations-reverified.json',restored)
preserved=[]
for name in ['qualification-reports.zip','report-summary.json','commands.json','source-applicability.json','qualification-status.json']:
    original=subprocess.check_output(['git','show',REVIEWED+':Docs/testing/evidence/living-dungeon-b3a/'+name],cwd=ROOT)
    path=DEST/name
    clean=subprocess.check_output(['git','hash-object','--path',str(path.relative_to(ROOT)),str(path)],cwd=ROOT,text=True).strip()
    committed=subprocess.check_output(['git','rev-parse',REVIEWED+':'+str(path.relative_to(ROOT)).replace('\\','/')],cwd=ROOT,text=True).strip()
    assert clean==committed
    preserved.append(dict(path=name,workingSha256=sha(path),gitBlobSha256=hashlib.sha256(original).hexdigest(),
                          matchesReviewedGitBlobWithCheckoutFilters=True))
write(OUT/'original-qualification-records-unchanged.json',preserved)
zip_path=DEST/'safety-closeout-reports.zip'
with zipfile.ZipFile(zip_path,'x',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(OUT.glob('*')):
        if path.is_file(): archive.write(path,path.relative_to(ROOT).as_posix())
status=dict(complete=False,prRemainsDraft=True,reviewedHead=REVIEWED,qualifiedRuntimeCommit=QUALIFIED,
            toolingTests=dict(passed=24,failed=0,exitCode=0,unityLaunched=False,fixtures='disposable synthetic text files only'),
            inactiveRunner=dict(exitCode=negative['exitCode'],filesAudited=negative['filesAudited'],newFiles=0,removedFiles=0,changedFiles=0,
                                unityInvocationExecuted=False,actionableRejection=True),
            protected=audit['protected'],historical=audit['historical'],unityInputs=audit['unityInputs'],
            runtimeTestsApplicable=True,recoveredThisFollowup=0,priorExactRestorationsReverified=len(restored),
            missingOriginals=search['missingOriginals'],
            search=dict(pngFiles=search['pngFiles'],zipFiles=search['zipFiles'],archivedPngFiles=search['archivedPngFiles'],
                        matches=0,restorationWrites=0,errors=search['errors'],unsupportedArchives=search['unsupportedArchives']),
            graphicalFailuresPreserved=['RoomContentMouseTouchPreviewAndResumeKeepCanonicalIsolated',
                                       'TransactionalRoomConstructionLayoutsLocalizationAndResume'],
            fullEditModeRemainsNonGreen=True,ownerExceptionGranted=False,
            reportsZip=dict(path=zip_path.name,sha256=sha(zip_path)),originalQualificationRecords=preserved,
            initialToolingEnvironmentFailure='Sandbox denied temporary fixture directory: 22 tests, 44 setup/cleanup errors, exit 1. Approved retry passed 22; final expanded run passed 24.',
            limitations=['Five exact screenshot originals remain missing; no regeneration or manifest amendment',
                         'Windows shadow-copy metadata unavailable (CIM initialization failure); no FileHistory configuration found',
                         'Future execution requires separately reviewed fresh campaign; current namespaces are closed/consumed'])
write(DEST/'safety-closeout.json',status)
print(json.dumps(dict(complete=False,protected=audit['protected']['equal'],historical=audit['historical']['equal'],tests=24,zipSha256=sha(zip_path))))
